<?php
defined('BASEPATH') OR exit('No direct script access allowed');

$config['protocol']		= 'smtp';
$config['smtp_host']	= 'mx.scs-vkool.com';
$config['smtp_user']	= 'vos.honda@scs-vkool.com';
$config['smtp_pass']	= 'scs-vk00L';
$config['smtp_crypto']	= 'tls';
$config['smtp_port']	= '587';
$config['wordwrap']		= TRUE;
$config['priority']		= '3';
$config['mailtype']		= 'html';

// $this->email->initialize($config);
