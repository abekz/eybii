<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title'] 			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle'] 		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "about";
			$this->load->view('layout/template',$data);
		}
	}
}
