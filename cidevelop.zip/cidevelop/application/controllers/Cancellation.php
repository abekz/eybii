<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Cancellation extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->vkp = $this->load->database('vkoolpusat', TRUE);
		$this->load->model('listvkoolpusat');
		$this->load->model('listvoucher');
		$this->load->model('listcancellation');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$session = $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function insertcancellation(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			################################## START INFO ::: INSERT KE TABLE CANCELLATION ##################################
			$serial 				= get_serial('addcancellationmemo');
			$data 					= array (
												'serial'					=> $serial,
												'created_by'				=> $this->session->userdata('serial'),
												'cancellation_memo_no'		=> $this->input->post('cancellation_no'),
												'date'						=> get_null_if_empty($this->input->post('date')),
												'chassis_serial'			=> $this->input->post('chassis_serial'),
												'note'						=> get_null_if_empty($this->input->post('note')),
												'status'					=> '1',
												'sales_order_no_car'		=> get_null_if_empty($this->input->post('soserial')),
											);
			$this->listvoucher->insertvoucher('vos_cancellation_memo',$data);
			################################### END INFO ::: INSERT KE TABLE CANCELLATION ###################################
			#################################### START INFO ::: MEMBATALKAN STATUS DI SO ####################################
			$datasoserial			= array (
												'status'			=> '3',
												'last_updated_by'	=> $this->session->userdata('serial'),
												'last_updated_date'	=> date("Y-m-d H:i:s"),
											);
			$wheresoserial			= array ('serial'	=> $this->input->post('soserial'));
			$this->listvoucher->updatedata($wheresoserial,$datasoserial,'sales');
			##################################### END INFO ::: MEMBATALKAN STATUS DI SO #####################################
			#################################### START INFO ::: MEMBATALKAN STATUS DI SI ####################################
			$datasiserial			= array (
												'status'			=> '3',
												'last_updated_by'	=> $this->session->userdata('serial'),
												'last_updated_date'	=> date("Y-m-d H:i:s"),
											);
			$wheresiserial			= array ('serial'	=> $this->input->post('siserial'));
			$this->listvoucher->updatedata($wheresiserial,$datasiserial,'sales');
			##################################### END INFO ::: MEMBATALKAN STATUS DI SI #####################################
			$validfromdate 			= $this->input->post('tanggal_terbit_voucher');
			$chassisserial			= $this->input->post('chassis_serial');
			if($validfromdate >= "2017-07-01"){
				$totday				= date("t");
				$serialsobaru		= get_serial('addsalesordernocar');
				$serialsibaru		= get_serial('addsalesinvoicenocar');
				$soyglamatambaha	= f_v_i_e($this->input->post('sono'),$this->listquerytable->getsalesorderwitha($chassisserial));
				$spknobarutambaha	= str_replace("SOC", "SPK", $soyglamatambaha);
				$invoicenotambaha	= str_replace("SOC", "SCS", $soyglamatambaha);
				$spknotanpaa		= str_replace("SOC", "SPK", $this->input->post('sono'));
				$duedate			= date("Y-m-d", strtotime("".$validfromdate." +".$totday." days"));

				############################ START INFO ::: MENAMBAH A PADA Sales Order YG LAMA #############################
				$dataso				= array (
												'sales_order_no_car'	=> $soyglamatambaha."A",
												'spk_no'				=> $spknobarutambaha."A",
												'last_updated_by'		=> $this->session->userdata('serial'),
												'last_updated_date'		=> date("Y-m-d H:i:s"),
											);
				$whereso			= array ('serial'	=> $this->input->post('soserial'));
				$this->listvoucher->updatedata($whereso,$dataso,'sales');
				############################# END INFO ::: MENAMBAH A PADA Sales Order YG LAMA ##############################

				################################### START INFO ::: INSERT KE TABLE SO BARU ##################################
				if($this->input->post('pajak_company_serial') == "02.417.173.8-048.000"){
					$installationcategory1 	= "f9ef3d29aebe37f053c45a7464597350";
					$dealerluarkotaserial	= NULL ;
					if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6"){
						$totalbonus			= "205000";
					} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
						$totalbonus			= "130000";
					} else {
						$totalbonus			= "155000";
					}
					$locationtype 			= "1";
				} else if($this->input->post('pajak_company_serial') == "2"){
					$installationcategory1 	= "58f8818d89fafed83578e672331142a2";
					$dealerluarkotaserial 	= $this->input->post('dealer_luarkota_serial');
					$totalbonus 			= "336000";
					$locationtype 			= "2";
				} else {
					$installationcategory1 	= "47aa83eb925785efeed5ffd970e5b49a";
					$dealerluarkotaserial 	= $this->input->post('dealer_luarkota_serial');
					$totalbonus 			= "343636";
					$locationtype 			= "2";
				}
				$datasobaru			= array (
												'serial'					=> $serialsobaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_order_no_car'		=> $this->input->post('sono'),
												'spk_no'					=> $spknotanpaa,
												'sales_type'				=> '1',
												'status'					=> '4',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'window_film_desc'			=> 'V-KOOL VRX60, V-KOOL BX15',
												'note'						=> 'PAKET VOUCHER',
												'order_date'				=> $validfromdate,
												'installation_date'			=> $validfromdate,
												'total_bonus'				=> $totalbonus,
												'due_date'					=> $duedate,
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('dealer_serial'),
												'bill_to_type_1'			=> '4',
												'bill_to_serial_1'			=> 'a8a5ff95854851fc9a0927b34fd9de35',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
											);
				$this->listvoucher->insertvoucher('sales',$datasobaru);

				for($dso=1;$dso<=3;$dso++){
					$serialdetail				= get_serial('adddetailondavoucher');
					if($dso == "1"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial 	= "c949e16e7231f4718ab4e819606ec2de";
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventory_serial 	= "c949e16e7231f4718ab4e819606ec2de";
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a"){
							$inventoryserial 	= "d55324f54719c06b83ddb73bb2e22931";
						} else {
							$inventoryserial 	= "a972a4c217c47249527404d002b4259a";
						}
					} else if($dso == "2"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else {
							$inventoryserial	= "e0a5fb955e9ceee0bdca4d41958c24c9" ;
						}
					} else if($dso == "3"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else {
							$inventoryserial	= "0f19ae1e7e383e39cdde0bda6c44d527" ;
						}
					}
					$datadsodetail[$dso]		= array (
															'serial'					=> $serialdetail,
															'created_date'				=> date("Y-m-d H:i:s"),
															'created_by'				=> $this->session->userdata('serial'),
															'sales_serial'				=> $serialsobaru,
															'inventory_category'		=> '1',
															'item_group'				=> '1',
															'inventory_serial'			=> $inventoryserial,
															'window_position' 			=> $dso,
															'window_position_detail' 	=> '1',
															'qty'						=> '1',
															'status'					=> '1',
															'print_garansi'				=> '1',
														);
				}
				$this->listvoucher->insertvoucherdetail('sales_detail',$datadsodetail);
				#################################### END INFO ::: INSERT KE TABLE SO BARU ###################################

				################################### START INFO ::: INSERT KE TABLE SI BARU ##################################
				if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "1d99320e9239393b4a59ef6d2ce03303" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$dpp_material	= "4300000" ; 
					$sub_total	= "4500000" ; 
					$amount_1	= "4675000" ; 
					$balance	= "4675000" ; 
					$total	= "4675000" ; 
					$total_price_nett	= "4675000" ; 
					$total_before_pph	= "4671000" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "1d99320e9239393b4a59ef6d2ce03303" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$dpp_material	= "4300000" ; 
					$sub_total	= "4500000" ; 
					$amount_1	= "4675000" ; 
					$balance	= "4675000" ; 
					$total	= "4675000" ; 
					$total_price_nett	= "4675000" ; 
					$total_before_pph	= "4671000" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b8e28aaac6ae61a5f4f7c0e7e772cdb7" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$amount_1	= "3850000" ; 
					$dpp_material	= "3550000" ; 
					$sub_total	= "3750000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "3850000" ; 
					$total_price_list	= "0" ; 
					$total	= "3850000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "3850000" ; 
					$total_before_pph	= "3810000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4400000" ; 
					$sub_total	= "4600000" ; 
					$amount_1	= "4785000" ; 
					$balance	= "4785000" ; 
					$total	= "4785000" ; 
					$total_price_nett	= "4785000" ; 
					$total_before_pph	= "4781000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "231ef900eebb5740b587ffbffbb816b8" ; 
					$pay_commission_to_type	= "4" ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$dpp_material	= "4000000" ; 
					$sub_total	= "4200000" ; 
					$amount_1	= "4345000" ; 
					$balance	= "4345000" ; 
					$total	= "4345000" ; 
					$total_price_nett	= "4345000" ; 
					$total_before_pph	= "4341000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "231ef900eebb5740b587ffbffbb816b8" ; 
					$pay_commission_to_type	= "4" ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$dpp_material	= "4300000" ; 
					$sub_total	= "4500000" ; 
					$amount_1	= "4620000" ; 
					$balance	= "4620000" ; 
					$total	= "4620000" ; 
					$total_price_nett	= "4200000" ; 
					$total_before_pph	= "4196000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "86676f7b2dd815979a0c52f6298a9771" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$dpp_material	= "4450000" ; 
					$sub_total	= "4650000" ; 
					$amount_1	= "4840000" ; 
					$balance	= "4840000" ; 
					$total	= "4840000" ; 
					$total_price_nett	= "4840000" ; 
					$total_before_pph	= "4836000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71"){ ## ALL NEW CIVIC ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$car_type_serial	= "2c30d759c6f390344de6e5f7d681cb71" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "ae2c63284b1bf186ed0e250d75f9c83c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$dpp_material	= "4100000" ; 
					$sub_total	= "4300000" ; 
					$amount_1	= "4455000" ; 
					$balance	= "4455000" ; 
					$total	= "4455000" ; 
					$total_price_nett	= "4455000" ; 
					$total_before_pph	= "4451000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") { ## ODYSSEY 2010 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "4881ae066e74157735cb00ace9a97448" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "5280000" ; 
					$dpp_material	= "4850000" ; 
					$sub_total	= "5050000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "5280000" ; 
					$total_price_list	= "0" ; 
					$total	= "5280000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "5280000" ; 
					$total_before_pph	= "5276000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") { ## ODYSSEY 2014 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "4881ae066e74157735cb00ace9a97448" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "5280000" ; 
					$dpp_material	= "4850000" ; 
					$sub_total	= "5050000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "5280000" ; 
					$total_price_list	= "0" ; 
					$total	= "5280000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "5280000" ; 
					$total_before_pph	= "5276000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") { ## HRV 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "4050000" ; 
					$dpp_material	= "3925000" ; 
					$sub_total	= "4125000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "4125000" ; 
					$total_price_list	= "0" ; 
					$total	= "4125000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "3750000" ; 
					$total_before_pph	= "3746000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "4840000" ; 
					$dpp_material	= "4500000" ; 
					$sub_total	= "4700000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "4700000" ; 
					$total_price_list	= "0" ; 
					$total	= "4700000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "4400000" ; 
					$total_before_pph	= "4396000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "4785000" ; 
					$dpp_material	= "4450000" ; 
					$sub_total	= "4650000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "4785000" ; 
					$total_price_list	= "0" ; 
					$total	= "4785000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "4350000" ; 
					$total_before_pph	= "4346000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "5280000" ; 
					$dpp_material	= "4900000" ; 
					$sub_total	= "5100000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "5280000" ; 
					$total_price_list	= "0" ; 
					$total	= "5280000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "4800000" ; 
					$total_before_pph	= "4796000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "6105000" ; 
					$dpp_material	= "5650000" ; 
					$sub_total	= "5850000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "6105000" ; 
					$total_price_list	= "0" ; 
					$total	= "6105000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "5550000" ; 
					$total_before_pph	= "5546000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "5060000" ; 
					$dpp_material	= "4700000" ; 
					$sub_total	= "4900000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "5060000" ; 
					$total_price_list	= "0" ; 
					$total	= "5060000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "4600000" ; 
					$total_before_pph	= "4596000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CRZ 2015 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "b6702b80aeb482d224bee07484ce7383" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= NULL ; 
					$commission_type	= NULL ; 
					$total_commission	= NULL ; 
					$amount_1	= "4235000" ; 
					$dpp_material	= "3950000" ; 
					$sub_total	= "4150000" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$balance	= "4235000" ; 
					$total_price_list	= "0" ; 
					$total	= "4235000" ; 
					$total_hpp	= "0" ; 
					$total_price_nett	= "3850000" ; 
					$total_before_pph	= "3846000" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") { ## NEW ACCORD 2011 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4400000" ; 
					$sub_total	= "4600000" ; 
					$amount_1	= "4785000" ; 
					$balance	= "4785000" ; 
					$total	= "4785000" ; 
					$total_price_nett	= "4785000" ; 
					$total_before_pph	= "4781000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HRV 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4300000" ; 
					$sub_total	= "4500000" ; 
					$amount_1	= "4950000" ; 
					$balance	= "4950000" ; 
					$total	= "4950000" ; 
					$total_price_nett	= "4950000" ; 
					$total_before_pph	= "4946000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BRV 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4350000" ; 
					$sub_total	= "4550000" ; 
					$amount_1	= "5005000" ; 
					$balance	= "5005000" ; 
					$total	= "5005000" ; 
					$total_price_nett	= "5005000" ; 
					$total_before_pph	= "5001000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "5000000" ; 
					$sub_total	= "5200000" ; 
					$amount_1	= "5390000" ; 
					$balance	= "5390000" ; 
					$total	= "5390000" ; 
					$total_price_nett	= "4900000" ; 
					$total_before_pph	= "4896000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CRV 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4800000" ; 
					$sub_total	= "5000000" ; 
					$amount_1	= "5500000" ; 
					$balance	= "5500000" ; 
					$total	= "5500000" ; 
					$total_price_nett	= "5500000" ; 
					$total_before_pph	= "5496000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "5000000" ; 
					$sub_total	= "5200000" ; 
					$amount_1	= "5720000" ; 
					$balance	= "5720000" ; 
					$total	= "5720000" ; 
					$total_price_nett	= "5720000" ; 
					$total_before_pph	= "5716000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "5400000" ; 
					$sub_total	= "5600000" ; 
					$amount_1	= "6160000" ; 
					$balance	= "6160000" ; 
					$total	= "6160000" ; 
					$total_price_nett	= "6160000" ; 
					$total_before_pph	= "6156000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "6150000" ; 
					$sub_total	= "6350000" ; 
					$amount_1	= "6655000" ; 
					$balance	= "6655000" ; 
					$total	= "6655000" ; 
					$total_price_nett	= "6655000" ; 
					$total_before_pph	= "6651000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "5200000" ; 
					$sub_total	= "5400000" ; 
					$amount_1	= "5610000" ; 
					$balance	= "5610000" ; 
					$total	= "5610000" ; 
					$total_price_nett	= "5610000" ; 
					$total_before_pph	= "5606000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CRZ 2016 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4400000" ; 
					$sub_total	= "4600000" ; 
					$amount_1	= "4730000" ; 
					$balance	= "4730000" ; 
					$total	= "4730000" ; 
					$total_price_nett	= "4730000" ; 
					$total_before_pph	= "4726000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3600000" ; 
					$sub_total	= "3800000" ; 
					$amount_1	= "4180000" ; 
					$balance	= "4180000" ; 
					$total	= "4180000" ; 
					$total_price_nett	= "4180000" ; 
					$total_before_pph	= "4176000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3400000" ; 
					$sub_total	= "3600000" ; 
					$amount_1	= "3960000" ; 
					$balance	= "3960000" ; 
					$total	= "3960000" ; 
					$total_price_nett	= "3960000" ; 
					$total_before_pph	= "3956000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3040000" ; 
					$sub_total	= "3240000" ; 
					$amount_1	= "3564000" ; 
					$balance	= "3564000" ; 
					$total	= "3564000" ; 
					$total_price_nett	= "3564000" ; 
					$total_before_pph	= "3560000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3720000" ; 
					$sub_total	= "3920000" ; 
					$amount_1	= "4312000" ; 
					$balance	= "4312000" ; 
					$total	= "4312000" ; 
					$total_price_nett	= "4312000" ; 
					$total_before_pph	= "4308000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3410000" ; 
					$sub_total	= "3610000" ; 
					$amount_1	= "3971000" ; 
					$balance	= "3971000" ; 
					$total	= "3971000" ; 
					$total_price_nett	= "3971000" ; 
					$total_before_pph	= "3967000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3750000" ; 
					$sub_total	= "3950000" ; 
					$amount_1	= "4345000" ; 
					$balance	= "4345000" ; 
					$total	= "4345000" ; 
					$total_price_nett	= "4345000" ; 
					$total_before_pph	= "4341000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4270000" ; 
					$sub_total	= "4470000" ; 
					$amount_1	= "4917000" ; 
					$balance	= "4917000" ; 
					$total	= "4917000" ; 
					$total_price_nett	= "4917000" ; 
					$total_before_pph	= "4913000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3700000" ; 
					$sub_total	= "3800000" ; 
					$amount_1	= "4180000" ; 
					$balance	= "4180000" ; 
					$total	= "4180000" ; 
					$total_price_nett	= "4180000" ; 
					$total_before_pph	= "4176000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017 ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "3720000" ; 
					$sub_total	= "3920000" ; 
					$amount_1	= "4312000" ; 
					$balance	= "4312000" ; 
					$total	= "4312000" ; 
					$total_price_nett	= "4312000" ; 
					$total_before_pph	= "4308000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R ##		
					$bill_to_type_1	= "4" ; 
					$bill_to_serial_1	= "a8a5ff95854851fc9a0927b34fd9de35" ; 
					$used_price_type	= "2" ; 
					$nett_price_serial	= "dde0d8cd479ca622855d4a5aca47172c" ; 
					$pay_commission_to_type	= NULL ; 
					$pay_commission_to_serial	= NULL ; 
					$commission	= "0" ; 
					$commission_type	= "2" ; 
					$total_commission	= "0" ; 
					$discount	= "0" ; 
					$discount_type	= "1" ; 
					$freight	= "0" ; 
					$ppn	= "10" ; 
					$down_payment	= "0" ; 
					$dpp_material	= "4700000" ; 
					$sub_total	= "4900000" ; 
					$amount_1	= "5390000" ; 
					$balance	= "5390000" ; 
					$total	= "5390000" ; 
					$total_price_nett	= "5390000" ; 
					$total_before_pph	= "5386000" ; 
					$total_price_list	= "0" ; 
					$total_hpp	= "0" ; 
					$other	= "0" ; 
					$other_2	= "0" ; 
					$other_desc	= NULL ; 
					$other_desc_2	= NULL ; 
					$ppn_other	= "0" ; 
				}
	
				$datasibaru			= array (
												'serial'					=> $serialsibaru,
												'sales_order_no'			=> $serialsobaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_invoice_no_car'		=> $this->input->post('sino'),
												'spk_no'					=> NULL,
												'sales_type'				=> '2',
												'status'					=> '4',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'window_film_desc'			=> 'V-KOOL VRX60, V-KOOL BX15',
												'note'						=> 'PAKET VOUCHER',
												'order_date'				=> $validfromdate,
												'installation_date'			=> $validfromdate,
												'total_bonus'				=> $totalbonus,
												'due_date'					=> $duedate,
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('dealer_serial'),
												'installation_category_1'	=> '47aa83eb925785efeed5ffd970e5b49a',
												'bill_to_type_1'			=> $bill_to_type_1 ,
												'bill_to_serial_1'			=> $bill_to_serial_1 ,
												'used_price_type'			=> $used_price_type ,
												'nett_price_serial'			=> $nett_price_serial ,
												'pay_commission_to_type'	=> $pay_commission_to_type ,
												'pay_commission_to_serial'	=> $pay_commission_to_serial ,
												'commission'				=> $commission ,
												'commission_type'			=> $commission_type ,
												'total_commission'			=> $total_commission ,
												'discount'					=> $discount ,
												'discount_type'				=> $discount_type ,
												'freight'					=> $freight ,
												'ppn'						=> $ppn ,
												'down_payment'				=> $down_payment ,
												'total_price_list'			=> $total_price_list ,
												'dpp_material'				=> $dpp_material ,
												'sub_total'					=> $sub_total ,
												'amount_1'					=> $amount_1 ,
												'balance'					=> $balance ,
												'total'						=> $total ,
												'total_price_nett'			=> $total_price_nett ,
												'total_before_pph'			=> $total_price_nett ,
												'total_hpp'					=> $total_hpp ,
												'other'						=> $other ,
												'other_2'					=> $other_2 ,
												'other_desc'				=> $other_desc ,
												'other_desc_2'				=> $other_desc_2 ,
												'ppn_other'					=> $ppn_other ,
												'jasa_pemasangan'			=> '200000',
												'pph_value'					=> '4000',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
											);
				$this->listvoucher->insertvoucher('sales',$datasibaru);

				for($dsi=1;$dsi<=3;$dsi++){
					$serialsidetail				= get_serial('adddetailondavoucher');
					if($dsi == "1"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial 	= "c949e16e7231f4718ab4e819606ec2de";
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventory_serial 	= "c949e16e7231f4718ab4e819606ec2de";
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a"){
							$inventoryserial 	= "d55324f54719c06b83ddb73bb2e22931";
						} else {
							$inventoryserial 	= "a972a4c217c47249527404d002b4259a";
						}
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "1916755" ;
							$total		= "1916755" ;
							$price_list	= "1916755" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "1916755" ;
							$total		= "1916755" ;
							$price_list	= "1916755" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1842446" ;
							$total		= "1842446" ;
							$price_list	= "1842446" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "1811839" ;
							$total		= "1811839" ;
							$price_list	= "1811839" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "1908465" ;
							$total		= "1908465" ;
							$price_list	= "1908465" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
							$price		= "2088550" ;
							$total		= "2088550" ;
							$price_list	= "2088550" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "2059577" ;
							$total		= "2059577" ;
							$price_list	= "2059577" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1804473" ;
							$total		= "1804473" ;
							$price_list	= "1804473" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "2026022" ;
							$total		= "2026022" ;
							$price_list	= "2026022" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "2026022" ;
							$total		= "2026022" ;
							$price_list	= "2026022" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1842446" ;
							$total		= "1842446" ;
							$price_list	= "1842446" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "1852264" ;
							$total		= "1852264" ;
							$price_list	= "1852264" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "2231505" ;
							$total		= "2231505" ;
							$price_list	= "2231505" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "2215168" ;
							$total		= "2215168" ;
							$price_list	= "2215168" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "2421184" ;
							$total		= "2421184" ;
							$price_list	= "2421184" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "2158778" ;
							$total		= "2158778" ;
							$price_list	= "2158778" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "2096883" ;
							$total		= "2096883" ;
							$price_list	= "2096883" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "2115107" ;
							$total		= "2115107" ;
							$price_list	= "2115107" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "2050781" ;
							$total		= "2050781" ;
							$price_list	= "2050781" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "2200969" ;
							$total		= "2200969" ;
							$price_list	= "2200969" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "2403800" ;
							$total		= "2403800" ;
							$price_list	= "2403800" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "2430000" ;
							$total		= "2430000" ;
							$price_list	= "2430000" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "2644894" ;
							$total		= "2644894" ;
							$price_list	= "2644894" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "2377465" ;
							$total		= "2377465" ;
							$price_list	= "2377465" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "2332394" ;
							$total		= "2332394" ;
							$price_list	= "2332394" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "2335165" ;
							$total		= "2335165" ;
							$price_list	= "2335165" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "2327352" ;
							$total		= "2327352" ;
							$price_list	= "2327352" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "1680480" ;
							$total		= "1680480" ;
							$price_list	= "1680480" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "1609938" ;
							$total		= "1609938" ;
							$price_list	= "1609938" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "1443303" ;
							$total		= "1443303" ;
							$price_list	= "1443303" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "1592677" ;
							$total		= "1592677" ;
							$price_list	= "1592677" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "1536517" ;
							$total		= "1536517" ;
							$price_list	= "1536517" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "1643920" ;
							$total		= "1643920" ;
							$price_list	= "1643920" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "1772790" ;
							$total		= "1772790" ;
							$price_list	= "1772790" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "1680480" ;
							$total		= "1680480" ;
							$price_list	= "1680480" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "1592677" ;
							$total		= "1592677" ;
							$price_list	= "1592677" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "2286315" ;
							$total		= "2286315" ;
							$price_list	= "2286315" ;
						}
					} else if($dsi == "2"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else {
							$inventoryserial	= "e0a5fb955e9ceee0bdca4d41958c24c9" ;
						}
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "1723754" ;
							$total		= "1723754" ;
							$price_list	= "1723754" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "1723754" ;
							$total		= "1723754" ;
							$price_list	= "1723754" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1737695" ;
							$total		= "1737695" ;
							$price_list	= "1737695" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "1058668" ;
							$total		= "1058668" ;
							$price_list	= "1058668" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "1504233" ;
							$total		= "1504233" ;
							$price_list	= "1504233" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
							$price		= "1762478" ;
							$total		= "1762478" ;
							$price_list	= "1762478" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "1718011" ;
							$total		= "1718011" ;
							$price_list	= "1718011" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1472196" ;
							$total		= "1472196" ;
							$price_list	= "1472196" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "2235757" ;
							$total		= "2235757" ;
							$price_list	= "2235757" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "2235757" ;
							$total		= "2235757" ;
							$price_list	= "2235757" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1737695" ;
							$total		= "1737695" ;
							$price_list	= "1737695" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "1512740" ;
							$total		= "1512740" ;
							$price_list	= "1512740" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "1140173" ;
							$total		= "1140173" ;
							$price_list	= "1140173" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "1975396" ;
							$total		= "1975396" ;
							$price_list	= "1975396" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "2704000" ;
							$total		= "2704000" ;
							$price_list	= "2704000" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "2035206" ;
							$total		= "2035206" ;
							$price_list	= "2035206" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "1753123" ;
							$total		= "1753123" ;
							$price_list	= "1753123" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "1670886" ;
							$total		= "1670886" ;
							$price_list	= "1670886" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "1750000" ;
							$total		= "1750000" ;
							$price_list	= "1750000" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "1547215" ;
							$total		= "1547215" ;
							$price_list	= "1547215" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "1278385" ;
							$total		= "1278385" ;
							$price_list	= "1278385" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "2104898" ;
							$total		= "2104898" ;
							$price_list	= "2104898" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "2819716" ;
							$total		= "2819716" ;
							$price_list	= "2819716" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "2163380" ;
							$total		= "2163380" ;
							$price_list	= "2163380" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "1904225" ;
							$total		= "1904225" ;
							$price_list	= "1904225" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "1928571" ;
							$total		= "1928571" ;
							$price_list	= "1928571" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "1810162" ;
							$total		= "1810162" ;
							$price_list	= "1810162" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "1286557" ;
							$total		= "1286557" ;
							$price_list	= "1286557" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "1412422" ;
							$total		= "1412422" ;
							$price_list	= "1412422" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "1228211" ;
							$total		= "1228211" ;
							$price_list	= "1228211" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "1658792" ;
							$total		= "1658792" ;
							$price_list	= "1658792" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "1330090" ;
							$total		= "1330090" ;
							$price_list	= "1330090" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "1416650" ;
							$total		= "1416650" ;
							$price_list	= "1416650" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "2006190" ;
							$total		= "2006190" ;
							$price_list	= "2006190" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "1286557" ;
							$total		= "1286557" ;
							$price_list	= "1286557" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "1658792" ;
							$total		= "1658792" ;
							$price_list	= "1658792" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "1647414" ;
							$total		= "1647414" ;
							$price_list	= "1647414" ;
						}
					} else if($dsi == "3"){
						if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
							$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495" ;
						} else {
							$inventoryserial	= "0f19ae1e7e383e39cdde0bda6c44d527" ;
						}
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "859491" ;
							$total		= "859491" ;
							$price_list	= "859491" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "859491" ;
							$total		= "859491" ;
							$price_list	= "859491" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1019859" ;
							$total		= "1019859" ;
							$price_list	= "1019859" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "879493" ;
							$total		= "879493" ;
							$price_list	= "879493" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "787302" ;
							$total		= "787302" ;
							$price_list	= "787302" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV ##
							$price		= "648972" ;
							$total		= "648972" ;
							$price_list	= "648972" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "872412" ;
							$total		= "872412" ;
							$price_list	= "872412" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1023331" ;
							$total		= "1023331" ;
							$price_list	= "1023331" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "788221" ;
							$total		= "788221" ;
							$price_list	= "788221" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "788221" ;
							$total		= "788221" ;
							$price_list	= "788221" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1019859" ;
							$total		= "1019859" ;
							$price_list	= "1019859" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "684996" ;
							$total		= "684996" ;
							$price_list	= "684996" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "778322" ;
							$total		= "778322" ;
							$price_list	= "778322" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "709436" ;
							$total		= "709436" ;
							$price_list	= "709436" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "724816" ;
							$total		= "724816" ;
							$price_list	= "724816" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "906016" ;
							$total		= "906016" ;
							$price_list	= "906016" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "799994" ;
							$total		= "799994" ;
							$price_list	= "799994" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "914007" ;
							$total		= "914007" ;
							$price_list	= "914007" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "749219" ;
							$total		= "749219" ;
							$price_list	= "749219" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "751816" ;
							$total		= "751816" ;
							$price_list	= "751816" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "917815" ;
							$total		= "917815" ;
							$price_list	= "917815" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "865102" ;
							$total		= "865102" ;
							$price_list	= "865102" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "885390" ;
							$total		= "885390" ;
							$price_list	= "885390" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "1059155" ;
							$total		= "1059155" ;
							$price_list	= "1059155" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "963381" ;
							$total		= "963381" ;
							$price_list	= "963381" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "736264" ;
							$total		= "736264" ;
							$price_list	= "736264" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "1062486" ;
							$total		= "1062486" ;
							$price_list	= "1062486" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "832963" ;
							$total		= "832963" ;
							$price_list	= "832963" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "577640" ;
							$total		= "577640" ;
							$price_list	= "577640" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "568486" ;
							$total		= "568486" ;
							$price_list	= "568486" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "668531" ;
							$total		= "668531" ;
							$price_list	= "668531" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "743393" ;
							$total		= "743393" ;
							$price_list	= "743393" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "889430" ;
							$total		= "889430" ;
							$price_list	= "889430" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "691020" ;
							$total		= "691020" ;
							$price_list	= "691020" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "832963" ;
							$total		= "832963" ;
							$price_list	= "832963" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "668531" ;
							$total		= "668531" ;
							$price_list	= "668531" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "966271" ;
							$total		= "966271" ;
							$price_list	= "966271" ;
						}
					}
					$datadsidetail[$dsi]		= array	(
															'serial'					=> $serialsidetail,
															'created_date'				=> date("Y-m-d H:i:s"),
															'created_by'				=> $this->session->userdata('serial'),
															'sales_serial'				=> $serialsibaru,
															'inventory_category'		=> '1',
															'item_group'				=> '1',
															'inventory_serial'			=> $inventoryserial,
															'window_position' 			=> $dsi,
															'window_position_detail' 	=> '1',
															'qty'						=> '1',
															'status'					=> '1',
															'print_garansi'				=> '1',
															'price'						=> $price,
															'total'						=> $total,
															'price_list'				=> $price_list,
														);
				}
				$this->listvoucher->insertvoucherdetail('sales_detail',$datadsidetail);
				#################################### END INFO ::: INSERT KE TABLE SI BARU ###################################

				########################### START INFO ::: MENAMBAH A PADA Sales Invoice YG LAMA ############################
				$datasi 			= array (
												'sales_invoice_no_car'	=> $invoicenotambaha."A",
												'last_updated_by'		=> $this->session->userdata('serial'),
												'last_updated_date'		=> date("Y-m-d H:i:s"),
											);
				$wheresi			= array ('serial'	=> $this->input->post('siserial'));
				$this->listvoucher->updatedata($wheresi,$datasi,'sales');
				############################ END INFO ::: MENAMBAH A PADA Sales Invoice YG LAMA #############################
			}
			####################################### START INFO ::: REACTIVATED CHASSIS ######################################
			$data 					= array (
												'status'				=> '4',
												'last_updated_by'		=> $this->session->userdata('serial'),
												'last_updated_date'		=> date("Y-m-d H:i:s"),
												'sales_order_no_car'	=> get_null_if_empty($serialsobaru),
												'sales_invoice_no_car'	=> get_null_if_empty($serialsibaru),
											);
			$where					= array ('serial'	=> $this->input->post('chassis_serial'));
			$this->listvoucher->updatedata($where,$data,'vos_master_chassis');
			######################################## END INFO ::: REACTIVATED CHASSIS #######################################
			######################################## START INFO :: UPDATE VOS VOUCHER #######################################
			$data 					= array (
												'status'					=> '3',
												'approval_status'			=> '3',
												'tanggal_pasang_voucher'	=> NULL,
												'sales_order_no_car'		=> get_null_if_empty($this->input->post('soserial')),
												'sales_invoice_no_car'		=> get_null_if_empty($this->input->post('siserial')),
												'last_updated_by'			=> $this->session->userdata('serial'),
												'last_updated_date'			=> date("Y-m-d H:i:s"),
											);
			$where					= array (
												'serial'					=> $this->input->post('voucher_serial'),
											);
			$this->listvoucher->updatedata($where,$data,'vos_voucher');
			#################################### END INFO :: UPDATE VOS MASTER CHASSIS ######################################
			############################## START INFO :: GANTI STATUS DELETED KE VKOOL PUSAT ################################
			if(!(strpos($this->input->post('warranty_no'),'NV')===false)) {
				$totday							= date("t");
				$duedatetek						= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdate					= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
				$resdetail		= $this->listvoucher->getdetaillist($this->input->post('voucher_serial'));
				for ($jv=0;$jv<count($resdetail);$jv++) {
					$serialtablegaransi			= get_serial('adddetailvkooldb');
					$kacafilmtipex				= $this->listquerytable->getfieldfromtable("inventory","inventory_name","serial",$resdetail[$jv]->inventory_serial,"");
					if($kacafilmtipex == "V-KOOL BLACK LABEL (X5)"){
						$kacafilmtipe			= "V-KOOL X05";
					} else if($kacafilmtipex == "V-KOOL 15"){
						$kacafilmtipe			= "V-KOOL X15";
					} else if($kacafilmtipex == "V-KOOL GPS"){
						$kacafilmtipe			= "V-KOOL J60E";
					} else {
						$kacafilmtipe			= $kacafilmtipex ;
					}
					$datavkp[$jv]				= array (
													'serial'					=> $serialtablegaransi,
													'created_date'				=> date("Y-m-d H:i:s"),
													'garansi_code'				=> get_null_if_empty($this->input->post('warranty_no')),
													'car_brand'					=> 'HONDA',
													'car_type'					=> $this->input->post('car_model'),
													'car_no_rangka'				=> strtoupper($this->input->post('chassis_no')),
													'car_no_mesin'				=> get_null_if_empty($this->input->post('machine_no')),
													'car_warna'					=> strtoupper($this->input->post('car_color')),
													'car_tahun'					=> f_v_i_e(date("Y"),$this->input->post('car_year')),
													'car_no_polisi'				=> strtoupper($this->input->post('police_no')),
													'kaca_film_brand'			=> 'V-KOOL',
													'kaca_film_tipe'			=> $kacafilmtipe,
													'kaca_film_posisi'			=> window_position($resdetail[$jv]->window_position),
													'poin_customer'				=> $this->input->post('poin_customer'),
													'poin_sales'				=> $this->input->post('poin_sales'),
													'master_roll'				=> $this->input->post('master_roll'),
													'note'						=> 'PAKET HONDA',
													'customer_nama'				=> get_null_if_empty($this->input->post('nama_pemilik')),
													'customer_id'				=> get_null_if_empty($this->input->post('customer_id')),
													'customer_alamat'			=> get_null_if_empty($this->input->post('alamat_pemilik')),
													'customer_kota'				=> f_v_i_e("JAKARTA",strtoupper($this->input->post('city'))),
													'customer_kodepos'			=> get_null_if_empty($this->input->post('zip')),
													'customer_email'			=> get_null_if_empty($this->input->post('email')),
													'customer_hp'				=> get_null_if_empty($this->input->post('no_handphone')),
													'sales_nama'				=> get_null_if_empty($this->input->post('sales_nama')),
													'sales_id'					=> get_null_if_empty($this->input->post('sales_id')),
													'sales_alamat'				=> get_null_if_empty($this->input->post('sales_alamat')),
													'sales_kota'				=> get_null_if_empty($this->input->post('sales_kota')),
													'sales_kodepos'				=> get_null_if_empty($this->input->post('sales_kodepos')),
													'sales_email'				=> get_null_if_empty($this->input->post('sales_email')),
													'sales_hp'					=> get_null_if_empty($this->input->post('sales_hp')),
													'invoice'					=> get_null_if_empty($this->input->post('sono')),
													'showroom_nama'				=> get_null_if_empty($this->input->post('dealer_name')),
													'showroom_alamat'			=> get_null_if_empty($this->input->post('showroom_alamat')),
													'showroom_kota'				=> get_null_if_empty($this->input->post('showroom_kota')),
													'showroom_kodepos'			=> get_null_if_empty($this->input->post('showroom_kodepos')),
													'showroom_telp'				=> get_null_if_empty($this->input->post('showroom_telp')),
													'showroom_pic'				=> get_null_if_empty($this->input->post('showroom_pic')),
													'tgl_pasang'				=> $pairingdate,
													'tgl_expired'				=> $duedatetek,
													'teknisi'					=> get_null_if_empty($this->input->post('teknisi')),
													'no_garansi_scs'			=> get_null_if_empty($this->input->post('no_garansi_scs')),
													'status'					=> 'DELETED OR CANCELLED',
													'tipe_garansi'				=> 'AUTOMOTIVE',
													'posisi_detail'				=> window_position_detail($resdetail[$jv]->window_position,$resdetail[$jv]->window_position_detail),
												);
				}
				$this->listvkoolpusat->insertvoucherdetail('tabel_garansi',$datavkp);
			}
			############################### END INFO :: GANTI STATUS DELETED KE VKOOL PUSAT #################################
			redirect(base_url().'cancellation/listcancellation');
		}
	}

	function listcancellation(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();

			$datefrom					= date("Y-m-d", strtotime("".date("Y-m-d")." -7 days")) ;
			$dateto						= date("Y-m-d") ;

			$jumlah_data				= $this->listcancellation->jumlah_data('','','',$datefrom,$dateto);
			$this->load->library('pagination');
			$config['base_url']			= base_url().'cancellation/listcancellation/';
			$config['total_rows']		= $jumlah_data;
			$config['per_page']			= 15;
			$from						= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']	= "<ul class='pagination'>";
			$config['full_tag_close']	= "</ul>";
			$config['num_tag_open']		= '<li>';
			$config['num_tag_close']	= '</li>';
			$config['cur_tag_open']		= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']	= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']	= "<li>";
			$config['next_tagl_close']	= "</li>";
			$config['prev_tag_open']	= "<li>";
			$config['prev_tagl_close']	= "</li>";
			$config['first_tag_open']	= "<li>";
			$config['first_tagl_close']	= "</li>";
			$config['last_tag_open']	= "<li>";
			$config['last_tagl_close']	= "</li>";

			$config['first_link']		= '< First Page ';
			$config['last_link']		= 'Last Page > ';
			$config['next_link']		= '> ';
			$config['prev_link']		= '< ';

			$this->pagination->initialize($config);

			$data['totaldata']			= $jumlah_data;
			$data['batalan']			= $this->listcancellation->showlistcancellation($config['per_page'],$from,'','','',$datefrom,$dateto);
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "cancellation/listcancellation.php";
			$this->load->view('layout/template',$data);
		}
	}

	function getlistvoucherchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$keyword	= $this->uri->segment(3);
			$data		= $this->listquerytable->getchassisforcancellation($keyword);
			echo json_encode($data);
		}
	}

	function addcancellation(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['prefixno']		= $this->listquerytable->getnextprefixno("MBTH-".date("y")."/","vos_cancellation_memo","cancellation_memo_no");
			$data['inventoryname']	= $this->listquerytable->getinventoryarray();
			$data['carmodel']		= $this->listquerytable->getcarmodelarray();
			$data['cartype']		= $this->listquerytable->getcartypearray();
			$data['dealervkool']	= $this->listquerytable->getuserarray('4','full_name');
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "cancellation/addcancellation.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatecancellation(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial					= $this->input->post('serial');
			$data = array(
				'note'				=> $this->input->post('note'),
				'status'			=> $this->input->post('status'),
				'last_updated_by'	=> $this->session->userdata('serial'),
				'last_updated_date'	=> date("Y-m-d H:i:s"),
			);

			$where = array(
				'serial'	=> $serial
			);

			$this->listvoucher->updatedata($where,$data,'vos_cancellation_memo');
			redirect(base_url().'cancellation/listcancellation');
		}
	}

	function detailcancellation($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']		= $this->listcancellation->showdetailcancellation($id);
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "cancellation/detailcancellation.php";
			$this->load->view('layout/template',$data);
		}
	}
}

