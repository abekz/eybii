<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Chassis extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvoucher');
		$this->load->model('listchassis');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$session = $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function showresultsearcchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$fieldsearch				= $_POST['fieldsearch'];
			$stringvalue1				= $_POST['stringvalue1'];
			$stringvalue2				= $_POST['stringvalue2'];
			$validdatefrom				= $_POST['validdatefrom'];
			$validdateto				= $_POST['validdateto'];

			$data['resultquery']		= $this->listchassis->showlistchassis($fieldsearch,$stringvalue1,$stringvalue2,$validdatefrom,$validdateto);
			$this->load->view('chassis/showresultsearch',$data);
		}
	}

	function listchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();

			$fieldsearch				= f_v_i_e("",$this->input->post('fieldsearch'));
			$stringvalue1				= f_v_i_e("",$this->input->post('stringvalue1'));
			$stringvalue2				= f_v_i_e("",$this->input->post('stringvalue2'));
			$validdatefrom				= f_v_i_e(date("Y-m-d"),$this->input->post('validdatefrom'));
			$validdateto				= f_v_i_e(date("Y-m-d"),$this->input->post('validdateto'));

			$data['postvaliddatefrom']	= $validdatefrom;
			$data['postvaliddateto']	= $validdateto;
//			$data['chassis']			= $this->listchassis->showlistchassis($fieldsearch,$stringvalue1,$stringvalue2,$validdatefrom,$validdateto);
			$data['carmodel']			= $this->listquerytable->getcarmodelarray();
			$data['cartype']			= $this->listquerytable->getcartypearray();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "chassis/listchassis.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			############################ untuk menentukan prefix baru pada sales order no car ############################
			$new_prefix_sr	= $this->listquerytable->getnextprefixno("SOCH-".date("y")."/","sales","sales_order_no_car");
			$next_val		= substr($new_prefix_sr, -7) - 1;
			$new_val 		= "SOCH-".date("y")."/".sprintf("%07d", $next_val);
			##############################################################################################################
			for($d=0;$d<$this->input->post('num_loop_0');$d++){
				$serial_master_chassis	= get_serial("master_chassis");
				$serial_sales			= get_serial("add_sales");
				$serial_sales_inv		= get_serial("add_sales");
				if($this->input->post('duplicate_chassis_'.$d) == "0"){
					$datax[$d]			= array (
											'serial'				=> $serial_master_chassis,
											'created_date'			=> date("Y-m-d H:i:s"),
											'created_by'			=> $this->session->userdata('serial'),
											'voucher_no'			=> $this->input->post('voucher_no_'.$d),
											'chassis_no'			=> $this->input->post('chassis_no_'.$d),
											'machine_no'			=> $this->input->post('machine_no_'.$d),
											'car_type_serial'		=> $this->input->post('car_type_serial_'.$d),
											'valid_from_date'		=> $this->input->post('valid_from_date_'.$d),
											'valid_to_date'			=> $this->input->post('valid_to_date_'.$d),
											'status'				=> f_v_i_e('1',$this->input->post('status_'.$d)),
											'chassis_no_trigger'	=> $this->input->post('chassis_no_trigger_'.$d),
											'car_model_serial'		=> $this->input->post('car_model_serial_'.$d),
											'note'					=> $this->input->post('note_'.$d),
											'dealer_serial'			=> $this->input->post('dealer_serial_'.$d),
											'dealer_type'			=> $this->input->post('dealer_type_'.$d),
											'car_color'				=> $this->input->post('car_color_'.$d),
											'status_chassis'		=> $this->input->post('status_chassis'),
											'sales_order_no_car'	=> $serial_sales,
											'sales_invoice_no_car'	=> $serial_sales_inv,
										);

					########## untuk menentukan prefix baru pada detail teknisi untuk staff receiveable ##########
					$next_val			= substr($new_val, -7) + 1;
					$new_val			= "SOCH-".date("y")."/".sprintf("%07d", $next_val);
					$spkbyorder			= str_replace("SOC","SPK",$new_val);
					$invoicebyorder		= str_replace("SOC","SCS",$new_val);
					##############################################################################################
					if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
						$totalbonus 	= "205000" ;
					} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
						$totalbonus 	= "130000" ;
					} else {
						$totalbonus 	= "155000" ;
					}
					$datasox[$d]		= array (
											'serial'					=> $serial_sales,
											'created_date'				=> date("Y-m-d H:i:s"),
											'created_by'				=> $this->session->userdata('serial'),
											'sales_order_no_car'		=> $new_val,
											'spk_no'					=> $spkbyorder,
											'total_bonus'				=> $totalbonus,
											'sales_type'				=> '1',
											'spk_has_returned'			=> '2',
											'customer_type'				=> '2',
											'order_from_type'			=> '4',
											'location_type'				=> '2',
											'is_holiday'				=> '2',
											'sudah_dijurnal'			=> '2',
											'bill_to_type_1'			=> '4',
											'installation_type'			=> '01',
											'branch_company'			=> '10',
											'jasa_pemasangan'			=> '200000',
											'dpp_material'				=> '0',
											'pph_value'					=> '4000',
											'window_film_desc'			=> 'V-KOOL 70, V-KOOL VIP, V-KOOL 15',
											'note'						=> 'PAKET VOUCHER',
											'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
											'installation_category_1'	=> '47aa83eb925785efeed5ffd970e5b49a',
											'is_real_tax'				=> '1',
											'status'					=> '4',
											'commission_paid_status'	=> '2',
											'so_has_print'				=> '3',
											'bisa_print'				=> '3',
											'filter_by'					=> '2',
											'car_year'					=> date("Y"),
											'order_date'				=> $this->input->post('valid_from_date_'.$d),
											'installation_date'			=> $this->input->post('valid_from_date_'.$d),
											'due_date'					=> date("Y-m-d", strtotime("".$this->input->post('valid_from_date_'.$d)." +30 days")),
											'update_warranty_date'		=> $this->input->post('valid_from_date_'.$d),
											'car_type_serial'			=> $this->input->post('car_model_serial_'.$d),
											'car_color'					=> $this->input->post('car_color_'.$d),
											'chassis_no'				=> $this->input->post('chassis_no_'.$d),
											'showroom_serial'			=> $this->input->post('dealer_serial_'.$d),
											'bill_to_serial_1'			=> $this->input->post('bill_to_serial_1_'.$d),
										);
					for ($sod=1;$sod<=3;$sod++) {
						$serialsodetail				= get_serial("add_salesdetail");
						if($sod == "1"){
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "c949e16e7231f4718ab4e819606ec2de";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "c949e16e7231f4718ab4e819606ec2de";
							} else {
								$inventoryserial	= "a972a4c217c47249527404d002b4259a";
							}
						} else if($sod == "2"){
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else {
								$inventoryserial	= "e0a5fb955e9ceee0bdca4d41958c24c9";
							}
						} else {
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else {
								$inventoryserial	= "0f19ae1e7e383e39cdde0bda6c44d527";
							}
						}
						$detailloopso[$sod]			= array (
														'serial'					=> $serialsodetail,
														'created_date'				=> date("Y-m-d H:i:s"),
														'created_by'				=> $this->session->userdata('serial'),
														'sales_serial'				=> $serial_sales,
														'inventory_category'		=> '1',
														'item_group'				=> '1',
														'window_position_detail'	=> '1',
														'status'					=> '1',
														'window_position'			=> $sod,
														'inventory_serial'			=> $inventoryserial,
													);
						$this->listvoucher->insertvoucher('sales_detail',$detailloopso[$sod]);
					}
					if($this->input->post('car_model_serial_'.$d) == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
						$dpp_material				= "4300000" ; 
						$sub_total					= "4500000" ; 
						$amount_1					= "4675000" ; 
						$balance					= "4675000" ; 
						$total						= "4675000" ; 
						$total_price_nett			= "4675000" ; 
						$total_before_pph			= "4671000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##		
						$dpp_material				= "4300000" ; 
						$sub_total					= "4500000" ; 
						$amount_1					= "4675000" ; 
						$balance					= "4675000" ; 
						$total						= "4675000" ; 
						$total_price_nett			= "4675000" ; 
						$total_before_pph			= "4671000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##		
						$amount_1					= "3850000" ; 
						$dpp_material				= "3550000" ; 
						$sub_total					= "3750000" ; 
						$balance					= "3850000" ; 
						$total						= "3850000" ; 
						$total_price_nett			= "3850000" ; 
						$total_before_pph			= "3810000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##		
						$dpp_material				= "4400000" ; 
						$sub_total					= "4600000" ; 
						$amount_1					= "4785000" ; 
						$balance					= "4785000" ; 
						$total						= "4785000" ; 
						$total_price_nett			= "4785000" ; 
						$total_before_pph			= "4781000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##		
						$dpp_material				= "4000000" ; 
						$sub_total					= "4200000" ; 
						$amount_1					= "4345000" ; 
						$balance					= "4345000" ; 
						$total						= "4345000" ; 
						$total_price_nett			= "4345000" ; 
						$total_before_pph			= "4341000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##		
						$dpp_material				= "4300000" ; 
						$sub_total					= "4500000" ; 
						$amount_1					= "4620000" ; 
						$balance					= "4620000" ; 
						$total						= "4620000" ; 
						$total_price_nett			= "4200000" ; 
						$total_before_pph			= "4196000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##		
						$dpp_material				= "4450000" ; 
						$sub_total					= "4650000" ; 
						$amount_1					= "4840000" ; 
						$balance					= "4840000" ; 
						$total						= "4840000" ; 
						$total_price_nett			= "4840000" ; 
						$total_before_pph			= "4836000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "2c30d759c6f390344de6e5f7d681cb71"){ ## ALL NEW CIVIC ##		
						$dpp_material				= "4100000" ; 
						$sub_total					= "4300000" ; 
						$amount_1					= "4455000" ; 
						$balance					= "4455000" ; 
						$total						= "4455000" ; 
						$total_price_nett			= "4455000" ; 
						$total_before_pph			= "4451000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a") { ## ODYSSEY 2010 ##		
						$amount_1					= "5280000" ; 
						$dpp_material				= "4850000" ; 
						$sub_total					= "5050000" ; 
						$balance					= "5280000" ; 
						$total						= "5280000" ; 
						$total_price_nett			= "5280000" ; 
						$total_before_pph			= "5276000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6") { ## ODYSSEY 2014 ##		
						$amount_1					= "5280000" ; 
						$dpp_material				= "4850000" ; 
						$sub_total					= "5050000" ; 
						$balance					= "5280000" ; 
						$total						= "5280000" ; 
						$total_price_nett			= "5280000" ; 
						$total_before_pph			= "5276000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "be9014f91589840220549316954ec138") { ## HRV 2015 ##		
						$amount_1					= "4050000" ; 
						$dpp_material				= "3925000" ; 
						$sub_total					= "4125000" ; 
						$balance					= "4125000" ; 
						$total						= "4125000" ; 
						$total_price_nett			= "3750000" ; 
						$total_before_pph			= "3746000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015 ##		
						$amount_1					= "4840000" ; 
						$dpp_material				= "4500000" ; 
						$sub_total					= "4700000" ; 
						$balance					= "4700000" ; 
						$total						= "4700000" ; 
						$total_price_nett			= "4400000" ; 
						$total_before_pph			= "4396000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015 ##		
						$amount_1					= "4785000" ; 
						$dpp_material				= "4450000" ; 
						$sub_total					= "4650000" ; 
						$balance					= "4785000" ; 
						$total						= "4785000" ; 
						$total_price_nett			= "4350000" ; 
						$total_before_pph			= "4346000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015 ##		
						$amount_1					= "5280000" ; 
						$dpp_material				= "4900000" ; 
						$sub_total					= "5100000" ; 
						$balance					= "5280000" ; 
						$total						= "5280000" ; 
						$total_price_nett			= "4800000" ; 
						$total_before_pph			= "4796000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015 ##		
						$amount_1					= "6105000" ; 
						$dpp_material				= "5650000" ; 
						$sub_total					= "5850000" ; 
						$balance					= "6105000" ; 
						$total						= "6105000" ; 
						$total_price_nett			= "5550000" ; 
						$total_before_pph			= "5546000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015 ##		
						$amount_1					= "5060000" ; 
						$dpp_material				= "4700000" ; 
						$sub_total					= "4900000" ; 
						$balance					= "5060000" ; 
						$total						= "5060000" ; 
						$total_price_nett			= "4600000" ; 
						$total_before_pph			= "4596000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "36acdd702c319f4b632d49d33ccd2977") { ## CRZ 2015 ##		
						$amount_1					= "4235000" ; 
						$dpp_material				= "3950000" ; 
						$sub_total					= "4150000" ; 
						$balance					= "4235000" ; 
						$total						= "4235000" ; 
						$total_price_nett			= "3850000" ; 
						$total_before_pph			= "3846000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7") { ## NEW ACCORD 2011 ##		
						$dpp_material				= "4400000" ; 
						$sub_total					= "4600000" ; 
						$amount_1					= "4785000" ; 
						$balance					= "4785000" ; 
						$total						= "4785000" ; 
						$total_price_nett			= "4785000" ; 
						$total_before_pph			= "4781000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HRV 2016 ##		
						$dpp_material				= "4300000" ; 
						$sub_total					= "4500000" ; 
						$amount_1					= "4950000" ; 
						$balance					= "4950000" ; 
						$total						= "4950000" ; 
						$total_price_nett			= "4950000" ; 
						$total_before_pph			= "4946000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "19379113f9e4f562ba60ecfe5223538d") { ## BRV 2016 ##		
						$dpp_material				= "4350000" ; 
						$sub_total					= "4550000" ; 
						$amount_1					= "5005000" ; 
						$balance					= "5005000" ; 
						$total						= "5005000" ; 
						$total_price_nett			= "5005000" ; 
						$total_before_pph			= "5001000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016 ##		
						$dpp_material				= "5000000" ; 
						$sub_total					= "5200000" ; 
						$amount_1					= "5390000" ; 
						$balance					= "5390000" ; 
						$total						= "5390000" ; 
						$total_price_nett			= "4900000" ; 
						$total_before_pph			= "4896000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "4c0420adb0b9a152c748d1ebfb097118") { ## CRV 2016 ##		
						$dpp_material				= "4800000" ; 
						$sub_total					= "5000000" ; 
						$amount_1					= "5500000" ; 
						$balance					= "5500000" ; 
						$total						= "5500000" ; 
						$total_price_nett			= "5500000" ; 
						$total_before_pph			= "5496000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016 ##		
						$dpp_material				= "5000000" ; 
						$sub_total					= "5200000" ; 
						$amount_1					= "5720000" ; 
						$balance					= "5720000" ; 
						$total						= "5720000" ; 
						$total_price_nett			= "5720000" ; 
						$total_before_pph			= "5716000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016 ##		
						$dpp_material				= "5400000" ; 
						$sub_total					= "5600000" ; 
						$amount_1					= "6160000" ; 
						$balance					= "6160000" ; 
						$total						= "6160000" ; 
						$total_price_nett			= "6160000" ; 
						$total_before_pph			= "6156000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016 ##		
						$dpp_material				= "6150000" ; 
						$sub_total					= "6350000" ; 
						$amount_1					= "6655000" ; 
						$balance					= "6655000" ; 
						$total						= "6655000" ; 
						$total_price_nett			= "6655000" ; 
						$total_before_pph			= "6651000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "f465040cb37375ed513263b596613bb7") { ## FREED 2016 ##		
						$dpp_material				= "5200000" ; 
						$sub_total					= "5400000" ; 
						$amount_1					= "5610000" ; 
						$balance					= "5610000" ; 
						$total						= "5610000" ; 
						$total_price_nett			= "5610000" ; 
						$total_before_pph			= "5606000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CRZ 2016 ##		
						$dpp_material				= "4400000" ; 
						$sub_total					= "4600000" ; 
						$amount_1					= "4730000" ; 
						$balance					= "4730000" ; 
						$total						= "4730000" ; 
						$total_price_nett			= "4730000" ; 
						$total_before_pph			= "4726000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017 ##		
						$dpp_material				= "3600000" ; 
						$sub_total					= "3800000" ; 
						$amount_1					= "4180000" ; 
						$balance					= "4180000" ; 
						$total						= "4180000" ; 
						$total_price_nett			= "4180000" ; 
						$total_before_pph			= "4176000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017 ##		
						$dpp_material				= "3400000" ; 
						$sub_total					= "3600000" ; 
						$amount_1					= "3960000" ; 
						$balance					= "3960000" ; 
						$total						= "3960000" ; 
						$total_price_nett			= "3960000" ; 
						$total_before_pph			= "3956000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017 ##		
						$dpp_material				= "3040000" ; 
						$sub_total					= "3240000" ; 
						$amount_1					= "3564000" ; 
						$balance					= "3564000" ; 
						$total						= "3564000" ; 
						$total_price_nett			= "3564000" ; 
						$total_before_pph			= "3560000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017 ##		
						$dpp_material				= "3720000" ; 
						$sub_total					= "3920000" ; 
						$amount_1					= "4312000" ; 
						$balance					= "4312000" ; 
						$total						= "4312000" ; 
						$total_price_nett			= "4312000" ; 
						$total_before_pph			= "4308000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017 ##		
						$dpp_material				= "3410000" ; 
						$sub_total					= "3610000" ; 
						$amount_1					= "3971000" ; 
						$balance					= "3971000" ; 
						$total						= "3971000" ; 
						$total_price_nett			= "3971000" ; 
						$total_before_pph			= "3967000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017 ##		
						$dpp_material				= "3750000" ; 
						$sub_total					= "3950000" ; 
						$amount_1					= "4345000" ; 
						$balance					= "4345000" ; 
						$total						= "4345000" ; 
						$total_price_nett			= "4345000" ; 
						$total_before_pph			= "4341000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017 ##		
						$dpp_material				= "4270000" ; 
						$sub_total					= "4470000" ; 
						$amount_1					= "4917000" ; 
						$balance					= "4917000" ; 
						$total						= "4917000" ; 
						$total_price_nett			= "4917000" ; 
						$total_before_pph			= "4913000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017 ##		
						$dpp_material				= "3700000" ; 
						$sub_total					= "3800000" ; 
						$amount_1					= "4180000" ; 
						$balance					= "4180000" ; 
						$total						= "4180000" ; 
						$total_price_nett			= "4180000" ; 
						$total_before_pph			= "4176000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017 ##		
						$dpp_material				= "3720000" ; 
						$sub_total					= "3920000" ; 
						$amount_1					= "4312000" ; 
						$balance					= "4312000" ; 
						$total						= "4312000" ; 
						$total_price_nett			= "4312000" ; 
						$total_before_pph			= "4308000" ; 
					} else if($this->input->post('car_model_serial_'.$d) == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R ##		
						$dpp_material				= "4700000" ; 
						$sub_total					= "4900000" ; 
						$amount_1					= "5390000" ; 
						$balance					= "5390000" ; 
						$total						= "5390000" ; 
						$total_price_nett			= "5390000" ; 
						$total_before_pph			= "5386000" ; 
					}
					if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
						$totalbonus					= "205000";
					} else {
						if(!(strpos($windowfilmdesc,'RX')===false)) {
							$totalbonus				= "130000";
						} else {
							$totalbonus				= "155000";
						}
					}
					$datasix[$d]					= array (
														'serial'					=> $serial_sales_inv,
														'created_date'				=> date("Y-m-d H:i:s"),
														'created_by'				=> $this->session->userdata('serial'),
														'sales_invoice_no_car'		=> $invoicebyorder,
														'sales_type'				=> '2',
														'so_has_print'				=> '3',
														'pay_bonus_to_type'			=> '3',
														'bisa_print'				=> '2',
														'filter_by'					=> '2',
														'spk_has_returned'			=> '2',
														'customer_type'				=> '2',
														'exchange_rate_currency'	=> '2',
														'exchange_rate_kurs'		=> '9500',
														'is_real_tax'				=> '1',
														'status'					=> '4',
														'order_from_type'			=> '4',
														'branch_company'			=> '10',
														'installation_category_1'	=> '47aa83eb925785efeed5ffd970e5b49a',
														'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
														'used_price_type'			=> '2',
														'nett_price_serial'			=> 'dde0d8cd479ca622855d4a5aca47172c',
														'order_date'				=> $this->input->post('valid_from_date_'.$d),
														'installation_date'			=> $this->input->post('valid_from_date_'.$d),
														'due_date'					=> date("Y-m-d", strtotime("".$this->input->post('valid_from_date_'.$d)." +30 days")),
														'update_warranty_date'		=> $this->input->post('valid_from_date_'.$d),
														'car_type_serial'			=> $this->input->post('car_model_serial_'.$d),
														'car_year'					=> date("Y"),
														'car_color'					=> $this->input->post('car_color_'.$d),
														'chassis_no'				=> $this->input->post('chassis_no_'.$d),
														'showroom_serial'			=> $this->input->post('dealer_serial_'.$d),
														'bill_to_type_1'			=> '4',
														'bill_to_serial_1'			=> $this->input->post('bill_to_serial_1_'.$d),
														'total_bonus'				=> $totalbonus,
														'dpp_material'				=> $dpp_material ,
														'sub_total'					=> $sub_total ,
														'amount_1'					=> $amount_1 ,
														'balance'					=> $balance ,
														'total'						=> $total ,
														'total_price_nett'			=> $total_price_nett ,
														'total_before_pph'			=> $total_before_pph ,
														'pay_commission_to_type'	=> NULL ,
														'pay_commission_to_serial'	=> NULL ,
														'commission'				=> '0' ,
														'commission_type'			=> '2' ,
														'total_commission'			=> '0' ,
														'discount'					=> '0' ,
														'discount_type'				=> '1' ,
														'freight'					=> '0' ,
														'ppn'						=> '10' ,
														'down_payment'				=> '0' ,
														'total_price_list'			=> '0' ,
														'total_hpp'					=> '0' ,
														'other'						=> '0' ,
														'other_2'					=> '0' ,
														'other_desc'				=> NULL ,
														'other_desc_2'				=> NULL ,
														'ppn_other'					=> '0' ,
														'jasa_pemasangan'			=> '200000',
														'pph_value'					=> '4000',
														'location_type'				=> '2',
														'is_holiday'				=> '2',
														'note'						=> 'PAKET VOUCHER',
														'window_film_desc'			=> 'V-KOOL 70, V-KOOL VIP, V-KOOL 15',
														'installation_type'			=> '01',
														'sudah_dijurnal'			=> '2',
														'sales_order_no'			=> $serial_sales,
														'paid_status_amount_1'		=> '2',
														'paid_status_amount_2'		=> '1',
														'paid_status_amount_3'		=> '1',
														'commission_paid_status'	=> '2',
													);
					for ($sid=1;$sid<=3;$sid++) {
						$serialsidetail				= get_serial("add_salesdetail");
						if($sid == "1"){
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "c949e16e7231f4718ab4e819606ec2de";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "c949e16e7231f4718ab4e819606ec2de";
							} else {
								$inventoryserial	= "a972a4c217c47249527404d002b4259a";
							}
							if($this->input->post('car_model_serial_'.$d) == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
								$price		= "1916755" ;
								$total		= "1916755" ;
								$price_list	= "1916755" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
								$price		= "1916755" ;
								$total		= "1916755" ;
								$price_list	= "1916755" ;
							} else if($this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
								$price		= "1842446" ;
								$total		= "1842446" ;
								$price_list	= "1842446" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
								$price		= "1811839" ;
								$total		= "1811839" ;
								$price_list	= "1811839" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
								$price		= "1908465" ;
								$total		= "1908465" ;
								$price_list	= "1908465" ;
							} else if($this->input->post('car_model_serial_'.$d) == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
								$price		= "2088550" ;
								$total		= "2088550" ;
								$price_list	= "2088550" ;
							} else if($this->input->post('car_model_serial_'.$d) == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
								$price		= "2059577" ;
								$total		= "2059577" ;
								$price_list	= "2059577" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial_'.$d) == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
								$price		= "1804473" ;
								$total		= "1804473" ;
								$price_list	= "1804473" ;
							} else if($this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a") {
								$price		= "2026022" ;
								$total		= "2026022" ;
								$price_list	= "2026022" ;
							} else if($this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6") {
								$price		= "2026022" ;
								$total		= "2026022" ;
								$price_list	= "2026022" ;
							} else if($this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7") {
								$price		= "1842446" ;
								$total		= "1842446" ;
								$price_list	= "1842446" ;
							} else if($this->input->post('car_model_serial_'.$d) == "be9014f91589840220549316954ec138") {
								$price		= "1852264" ;
								$total		= "1852264" ;
								$price_list	= "1852264" ;
							} else if($this->input->post('car_model_serial_'.$d) == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
								$price		= "2231505" ;
								$total		= "2231505" ;
								$price_list	= "2231505" ;
							} else if($this->input->post('car_model_serial_'.$d) == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
								$price		= "2215168" ;
								$total		= "2215168" ;
								$price_list	= "2215168" ;
							} else if($this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
								$price		= "2421184" ;
								$total		= "2421184" ;
								$price_list	= "2421184" ;
							} else if($this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
								$price		= "2158778" ;
								$total		= "2158778" ;
								$price_list	= "2158778" ;
							} else if($this->input->post('car_model_serial_'.$d) == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
								$price		= "2096883" ;
								$total		= "2096883" ;
								$price_list	= "2096883" ;
							} else if($this->input->post('car_model_serial_'.$d) == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
								$price		= "2115107" ;
								$total		= "2115107" ;
								$price_list	= "2115107" ;
							} else if($this->input->post('car_model_serial_'.$d) == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
								$price		= "2050781" ;
								$total		= "2050781" ;
								$price_list	= "2050781" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
								$price		= "2200969" ;
								$total		= "2200969" ;
								$price_list	= "2200969" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
								$price		= "2403800" ;
								$total		= "2403800" ;
								$price_list	= "2403800" ;
							} else if($this->input->post('car_model_serial_'.$d) == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
								$price		= "2430000" ;
								$total		= "2430000" ;
								$price_list	= "2430000" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
								$price		= "2644894" ;
								$total		= "2644894" ;
								$price_list	= "2644894" ;
							} else if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
								$price		= "2377465" ;
								$total		= "2377465" ;
								$price_list	= "2377465" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
								$price		= "2332394" ;
								$total		= "2332394" ;
								$price_list	= "2332394" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
								$price		= "2335165" ;
								$total		= "2335165" ;
								$price_list	= "2335165" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
								$price		= "2327352" ;
								$total		= "2327352" ;
								$price_list	= "2327352" ;
							} else if($this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
								$price		= "1680480" ;
								$total		= "1680480" ;
								$price_list	= "1680480" ;
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
								$price		= "1609938" ;
								$total		= "1609938" ;
								$price_list	= "1609938" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
								$price		= "1443303" ;
								$total		= "1443303" ;
								$price_list	= "1443303" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
								$price		= "1592677" ;
								$total		= "1592677" ;
								$price_list	= "1592677" ;
							} else if($this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
								$price		= "1536517" ;
								$total		= "1536517" ;
								$price_list	= "1536517" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
								$price		= "1643920" ;
								$total		= "1643920" ;
								$price_list	= "1643920" ;
							} else if($this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
								$price		= "1772790" ;
								$total		= "1772790" ;
								$price_list	= "1772790" ;
							} else if($this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
								$price		= "1680480" ;
								$total		= "1680480" ;
								$price_list	= "1680480" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
								$price		= "1592677" ;
								$total		= "1592677" ;
								$price_list	= "1592677" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
								$price		= "2286315" ;
								$total		= "2286315" ;
								$price_list	= "2286315" ;
							}
						} else if($sid == "2"){
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else {
								$inventoryserial	= "e0a5fb955e9ceee0bdca4d41958c24c9";
							}
							if($this->input->post('car_model_serial_'.$d) == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
								$price		= "1723754" ;
								$total		= "1723754" ;
								$price_list	= "1723754" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
								$price		= "1723754" ;
								$total		= "1723754" ;
								$price_list	= "1723754" ;
							} else if($this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
								$price		= "1737695" ;
								$total		= "1737695" ;
								$price_list	= "1737695" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
								$price		= "1058668" ;
								$total		= "1058668" ;
								$price_list	= "1058668" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
								$price		= "1504233" ;
								$total		= "1504233" ;
								$price_list	= "1504233" ;
							} else if($this->input->post('car_model_serial_'.$d) == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
								$price		= "1762478" ;
								$total		= "1762478" ;
								$price_list	= "1762478" ;
							} else if($this->input->post('car_model_serial_'.$d) == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
								$price		= "1718011" ;
								$total		= "1718011" ;
								$price_list	= "1718011" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial_'.$d) == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
								$price		= "1472196" ;
								$total		= "1472196" ;
								$price_list	= "1472196" ;
							} else if($this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a") {
								$price		= "2235757" ;
								$total		= "2235757" ;
								$price_list	= "2235757" ;
							} else if($this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6") {
								$price		= "2235757" ;
								$total		= "2235757" ;
								$price_list	= "2235757" ;
							} else if($this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7") {
								$price		= "1737695" ;
								$total		= "1737695" ;
								$price_list	= "1737695" ;
							} else if($this->input->post('car_model_serial_'.$d) == "be9014f91589840220549316954ec138") {
								$price		= "1512740" ;
								$total		= "1512740" ;
								$price_list	= "1512740" ;
							} else if($this->input->post('car_model_serial_'.$d) == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
								$price		= "1140173" ;
								$total		= "1140173" ;
								$price_list	= "1140173" ;
							} else if($this->input->post('car_model_serial_'.$d) == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
								$price		= "1975396" ;
								$total		= "1975396" ;
								$price_list	= "1975396" ;
							} else if($this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
								$price		= "2704000" ;
								$total		= "2704000" ;
								$price_list	= "2704000" ;
							} else if($this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
								$price		= "2035206" ;
								$total		= "2035206" ;
								$price_list	= "2035206" ;
							} else if($this->input->post('car_model_serial_'.$d) == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
								$price		= "1753123" ;
								$total		= "1753123" ;
								$price_list	= "1753123" ;
							} else if($this->input->post('car_model_serial_'.$d) == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
								$price		= "1670886" ;
								$total		= "1670886" ;
								$price_list	= "1670886" ;
							} else if($this->input->post('car_model_serial_'.$d) == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
								$price		= "1750000" ;
								$total		= "1750000" ;
								$price_list	= "1750000" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
								$price		= "1547215" ;
								$total		= "1547215" ;
								$price_list	= "1547215" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
								$price		= "1278385" ;
								$total		= "1278385" ;
								$price_list	= "1278385" ;
							} else if($this->input->post('car_model_serial_'.$d) == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
								$price		= "2104898" ;
								$total		= "2104898" ;
								$price_list	= "2104898" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
								$price		= "2819716" ;
								$total		= "2819716" ;
								$price_list	= "2819716" ;
							} else if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
								$price		= "2163380" ;
								$total		= "2163380" ;
								$price_list	= "2163380" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
								$price		= "1904225" ;
								$total		= "1904225" ;
								$price_list	= "1904225" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
								$price		= "1928571" ;
								$total		= "1928571" ;
								$price_list	= "1928571" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
								$price		= "1810162" ;
								$total		= "1810162" ;
								$price_list	= "1810162" ;
							} else if($this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
								$price		= "1286557" ;
								$total		= "1286557" ;
								$price_list	= "1286557" ;
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
								$price		= "1412422" ;
								$total		= "1412422" ;
								$price_list	= "1412422" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
								$price		= "1228211" ;
								$total		= "1228211" ;
								$price_list	= "1228211" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
								$price		= "1658792" ;
								$total		= "1658792" ;
								$price_list	= "1658792" ;
							} else if($this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
								$price		= "1330090" ;
								$total		= "1330090" ;
								$price_list	= "1330090" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
								$price		= "1416650" ;
								$total		= "1416650" ;
								$price_list	= "1416650" ;
							} else if($this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
								$price		= "2006190" ;
								$total		= "2006190" ;
								$price_list	= "2006190" ;
							} else if($this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
								$price		= "1286557" ;
								$total		= "1286557" ;
								$price_list	= "1286557" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
								$price		= "1658792" ;
								$total		= "1658792" ;
								$price_list	= "1658792" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
								$price		= "1647414" ;
								$total		= "1647414" ;
								$price_list	= "1647414" ;
							}
						} else {
							if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848" || $this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524"){
								$inventoryserial	= "ee4c12ff2fa69dac1fd060902f3e8495";
							} else {
								$inventoryserial	= "0f19ae1e7e383e39cdde0bda6c44d527";
							}
							if($this->input->post('car_model_serial_'.$d) == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
								$price		= "859491" ;
								$total		= "859491" ;
								$price_list	= "859491" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
								$price		= "859491" ;
								$total		= "859491" ;
								$price_list	= "859491" ;
							} else if($this->input->post('car_model_serial_'.$d) == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
								$price		= "1019859" ;
								$total		= "1019859" ;
								$price_list	= "1019859" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
								$price		= "879493" ;
								$total		= "879493" ;
								$price_list	= "879493" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
								$price		= "787302" ;
								$total		= "787302" ;
								$price_list	= "787302" ;
							} else if($this->input->post('car_model_serial_'.$d) == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV ##
								$price		= "648972" ;
								$total		= "648972" ;
								$price_list	= "648972" ;
							} else if($this->input->post('car_model_serial_'.$d) == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
								$price		= "872412" ;
								$total		= "872412" ;
								$price_list	= "872412" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial_'.$d) == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
								$price		= "1023331" ;
								$total		= "1023331" ;
								$price_list	= "1023331" ;
							} else if($this->input->post('car_model_serial_'.$d) == "64448c77b37debe50be9cf810f92dc4a") {
								$price		= "788221" ;
								$total		= "788221" ;
								$price_list	= "788221" ;
							} else if($this->input->post('car_model_serial_'.$d) == "3496aa3e3762f62043aa8692c6c9bef6") {
								$price		= "788221" ;
								$total		= "788221" ;
								$price_list	= "788221" ;
							} else if($this->input->post('car_model_serial_'.$d) == "512076efc637f9704b05257fb17cabd7") {
								$price		= "1019859" ;
								$total		= "1019859" ;
								$price_list	= "1019859" ;
							} else if($this->input->post('car_model_serial_'.$d) == "be9014f91589840220549316954ec138") {
								$price		= "684996" ;
								$total		= "684996" ;
								$price_list	= "684996" ;
							} else if($this->input->post('car_model_serial_'.$d) == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
								$price		= "778322" ;
								$total		= "778322" ;
								$price_list	= "778322" ;
							} else if($this->input->post('car_model_serial_'.$d) == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
								$price		= "709436" ;
								$total		= "709436" ;
								$price_list	= "709436" ;
							} else if($this->input->post('car_model_serial_'.$d) == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
								$price		= "724816" ;
								$total		= "724816" ;
								$price_list	= "724816" ;
							} else if($this->input->post('car_model_serial_'.$d) == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
								$price		= "906016" ;
								$total		= "906016" ;
								$price_list	= "906016" ;
							} else if($this->input->post('car_model_serial_'.$d) == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
								$price		= "799994" ;
								$total		= "799994" ;
								$price_list	= "799994" ;
							} else if($this->input->post('car_model_serial_'.$d) == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
								$price		= "914007" ;
								$total		= "914007" ;
								$price_list	= "914007" ;
							} else if($this->input->post('car_model_serial_'.$d) == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
								$price		= "749219" ;
								$total		= "749219" ;
								$price_list	= "749219" ;
							} else if($this->input->post('car_model_serial_'.$d) == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
								$price		= "751816" ;
								$total		= "751816" ;
								$price_list	= "751816" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
								$price		= "917815" ;
								$total		= "917815" ;
								$price_list	= "917815" ;
							} else if($this->input->post('car_model_serial_'.$d) == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
								$price		= "865102" ;
								$total		= "865102" ;
								$price_list	= "865102" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
								$price		= "885390" ;
								$total		= "885390" ;
								$price_list	= "885390" ;
							} else if($this->input->post('car_model_serial_'.$d) == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
								$price		= "1059155" ;
								$total		= "1059155" ;
								$price_list	= "1059155" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
								$price		= "963381" ;
								$total		= "963381" ;
								$price_list	= "963381" ;
							} else if($this->input->post('car_model_serial_'.$d) == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
								$price		= "736264" ;
								$total		= "736264" ;
								$price_list	= "736264" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
								$price		= "1062486" ;
								$total		= "1062486" ;
								$price_list	= "1062486" ;
							} else if($this->input->post('car_model_serial_'.$d) == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
								$price		= "832963" ;
								$total		= "832963" ;
								$price_list	= "832963" ;
							} else if($this->input->post('car_model_serial_'.$d) == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
								$price		= "577640" ;
								$total		= "577640" ;
								$price_list	= "577640" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
								$price		= "568486" ;
								$total		= "568486" ;
								$price_list	= "568486" ;
							} else if($this->input->post('car_model_serial_'.$d) == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
								$price		= "668531" ;
								$total		= "668531" ;
								$price_list	= "668531" ;
							} else if($this->input->post('car_model_serial_'.$d) == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
								$price		= "743393" ;
								$total		= "743393" ;
								$price_list	= "743393" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
								$price		= "889430" ;
								$total		= "889430" ;
								$price_list	= "889430" ;
							} else if($this->input->post('car_model_serial_'.$d) == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
								$price		= "691020" ;
								$total		= "691020" ;
								$price_list	= "691020" ;
							} else if($this->input->post('car_model_serial_'.$d) == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
								$price		= "832963" ;
								$total		= "832963" ;
								$price_list	= "832963" ;
							} else if($this->input->post('car_model_serial_'.$d) == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
								$price		= "668531" ;
								$total		= "668531" ;
								$price_list	= "668531" ;
							} else if($this->input->post('car_model_serial_'.$d) == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
								$price		= "966271" ;
								$total		= "966271" ;
								$price_list	= "966271" ;
							}
						}
						$detailloopsi[$sid]			= array (
														'serial'					=> $serialsidetail,
														'created_date'				=> date("Y-m-d H:i:s"),
														'created_by'				=> $this->session->userdata('serial'),
														'sales_serial'				=> $serial_sales_inv,
														'inventory_serial'			=> $inventoryserial,
														'inventory_category'		=> '1',
														'item_group'				=> '1',
														'status'					=> '1',
														'window_position'			=> $sid,
														'window_position_detail'	=> '1',
														'print_garansi'				=> '1',
														'price'						=> $price,
														'total'						=> $total,
														'price_list'				=> $price_list,
													);
						$this->listvoucher->insertvoucher('sales_detail',$detailloopsi[$sid]);
					}
				}
			}
			if($datax){
				$this->listvoucher->insertvoucherdetail('vos_master_chassis',$datax);
				$this->listvoucher->insertvoucherdetail('sales',$datasox);
				$this->listvoucher->insertvoucherdetail('sales',$datasix);
			}
			################################ START INFO ::: HAPUS TABLE vos_upload_chassis BERDASARKAN SESSION ################################
			$wherechassisupload				= array ('session_serial'	=> $this->session->userdata('serial'));
			$this->listvoucher->deletedata($wherechassisupload,'vos_upload_chassis');
			################################# END INFO ::: HAPUS TABLE vos_upload_chassis BERDASARKAN SESSION #################################
			redirect(base_url().'chassis/listchassis/');
		}
	}

	function addchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$prefixuserid				= "HVK-".date('y')."/";
			$data['prefixno']			= $this->listquerytable->getnextprefixno($prefixuserid,'vos_master_chassis','voucher_no');
			$data['companyserial']		= $this->listquerytable->getuserarray('4','full_name');
			$data['maindealer']			= $this->listquerytable->getuserarray('3','full_name');
			$data['dealer']				= $this->listquerytable->getuserarray('X','full_name');
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "chassis/addchassis.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatechassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial						= $this->input->post('serial');
			$data 						= array (
											'chassis_no'				=> $this->input->post('chassis_no'),
											'chassis_no_trigger'		=> get_null_if_empty($this->input->post('chassis_no_trigger')),
											'car_type_serial'			=> get_null_if_empty($this->input->post('car_type_serial')),
											'valid_to_date'				=> f_v_i_e(date("Y-m-d"),$this->input->post('valid_to_date')),
											'car_model_serial'			=> get_null_if_empty($this->input->post('car_model_serial')),
											'car_model_serial_trigger'	=> get_null_if_empty($this->input->post('car_model_serial')),
											'note'						=> get_null_if_empty($this->input->post('note')),
											'dealer_serial'				=> f_v_i_e($this->session->userdata('dealer_serial'),$this->input->post('dealer_serial')),
											'car_color'					=> get_null_if_empty($this->input->post('car_color')),
											'status'					=> f_v_i_e("1",$this->input->post('status')),
											'last_updated_by'			=> $this->session->userdata('serial'),
											'last_updated_date'			=> date("Y-m-d H:i:s"),
										);
			$where						= array (
											'serial'					=> $serial,
										);
			$this->listvoucher->updatedata($where,$data,'vos_master_chassis');
			redirect(base_url().'chassis/listchassis');
		}
	}

	function detailchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$id							= $this->uri->segment('3');
			$data['voucher']			= $this->listchassis->showdetailchassis($id);
			$data['carmodel']			= $this->listquerytable->getcarmodelarray();
			$data['cartype']			= $this->listquerytable->getcartypearray();
			$data['dealer']				= $this->listquerytable->getuserarray('X','full_name');
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "chassis/detailchassis.php";
			$this->load->view('layout/template',$data);
		}
	}

	function uploadchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			################################ START INFO ::: HAPUS TABLE vos_upload_chassis BERDASARKAN SESSION ################################
			$wherechassisupload				= array ('session_serial'	=> $this->session->userdata('serial'));
			$this->listvoucher->deletedata($wherechassisupload,'vos_upload_chassis');
			################################# END INFO ::: HAPUS TABLE vos_upload_chassis BERDASARKAN SESSION #################################

			############################## START INFO ::: LOAD FILE EXCEL DAN INSERT KE TABLE vos_upload_chassis ##############################
			$validfromdate					= f_v_i_e(date("Y-m-d"),$_POST['validfromdate']);
			$fileName						= f_v_i_e('blank.xls',$_POST['filename']);
			$inputFileName					= $_SERVER["DOCUMENT_ROOT"].'/assets/uploadnew/uploads/'.$fileName;
			try {
				$inputFileType				= IOFactory::identify($inputFileName);
				$objReader					= IOFactory::createReader($inputFileType);
				$objPHPExcel				= $objReader->load($inputFileName);
			} catch(Exception $e) {
				die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
			}
			$sheet 							= $objPHPExcel->getSheet(0);
			$highestRow 					= $sheet->getHighestRow();
			$highestColumn 					= $sheet->getHighestColumn();
			for($row=2;$row<=$highestRow;$row++){
				$rowData					= $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row, NULL, TRUE, FALSE);
				$statusdouble				= $this->listquerytable->getchassisno($rowData[0][2]);
				$serialwarranty				= get_serial("addchassisupload");
				$data[$row]					= array(
												'serial'			=> $serialwarranty,
												'session_serial'	=> $this->session->userdata('serial'),
												'car_model_serial'	=> get_null_if_empty($this->listquerytable->getfieldfromtable("vos_car_model","serial","car_model",$rowData[0][0],"1")),
												'car_type_serial'	=> get_null_if_empty($this->listquerytable->getfieldfromtable("vos_car_type","serial","car_type",$rowData[0][1],"1")),
												'chassis_no'		=> get_null_if_empty($rowData[0][2]),
												'dealer_serial'		=> f_v_i_e($this->listquerytable->getserialforfullname("vos_users","serial","full_name",$rowData[0][3],"3"),$this->listquerytable->getserialforfullname("vos_users","serial","full_name",$rowData[0][3],"X")),
												'car_color'			=> get_null_if_empty($rowData[0][4]),
												'valid_from_date'	=> f_v_i_e(date("Y-m-d"),$validfromdate),
												'status'			=> $statusdouble,
											);
			}
			$this->listvoucher->insertvoucherdetail('vos_upload_chassis',$data);
			############################### END INFO ::: LOAD FILE EXCEL DAN INSERT KE TABLE vos_upload_chassis ###############################
			$data['resultquery']			= $this->listchassis->showlistuploadchassis($this->session->userdata('serial'),'');
			$this->load->view('chassis/showresultupload',$data);
		}
	}

	function exporttoexcel(){
		$excel = new PHPExcel();
		// Settingan awal fil excel
		$excel->getProperties()->setCreator($this->session->userdata('full_name'))
								->setLastModifiedBy($this->session->userdata('full_name'))
								->setTitle("Double Chassis")
								->setSubject("List of Chassis")
								->setDescription("Show All Double Chassis")
								->setKeywords("chassis");

		// Buat sebuah variabel untuk menampung pengaturan style dari header tabel
		$style_col = array(
			'font'		=> array('bold' => true), // Set font nya jadi bold
			'alignment'	=> array(
				'horizontal'	=> PHPExcel_Style_Alignment::HORIZONTAL_CENTER, // Set text jadi ditengah secara horizontal (center)
				'vertical'		=> PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
			),
			'borders'	=> array(
				'top'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom'	=> array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			)
		);

		// Buat sebuah variabel untuk menampung pengaturan style dari isi tabel
		$style_row = array(
			'alignment'	=> array(
				'vertical'	=> PHPExcel_Style_Alignment::VERTICAL_CENTER // Set text jadi di tengah secara vertical (middle)
			),
			'borders'	=> array(
				'top'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border top dengan garis tipis
				'right'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN),  // Set border right dengan garis tipis
				'bottom'	=> array('style'  => PHPExcel_Style_Border::BORDER_THIN), // Set border bottom dengan garis tipis
				'left'		=> array('style'  => PHPExcel_Style_Border::BORDER_THIN) // Set border left dengan garis tipis
			)
		);

		$excel->setActiveSheetIndex(0)->setCellValue('A1', "DOUBLE CHASSIS"); // Set kolom A1 dengan tulisan "DATA SISWA"
		$excel->getActiveSheet()->mergeCells('A1:E1'); // Set Merge Cell pada kolom A1 sampai E1
		$excel->getActiveSheet()->getStyle('A1')->getFont()->setBold(TRUE); // Set bold kolom A1
		$excel->getActiveSheet()->getStyle('A1')->getFont()->setSize(15); // Set font size 15 untuk kolom A1
		$excel->getActiveSheet()->getStyle('A1')->getAlignment()->setHorizontal(PHPExcel_Style_Alignment::HORIZONTAL_CENTER); // Set text center untuk kolom A1

		// Buat header tabel nya pada baris ke 3
		$excel->setActiveSheetIndex(0)->setCellValue('A3', "CAR MODEL"); // Set kolom A3 dengan tulisan "NO"
		$excel->setActiveSheetIndex(0)->setCellValue('B3', "CAR TYPE"); // Set kolom B3 dengan tulisan "NIS"
		$excel->setActiveSheetIndex(0)->setCellValue('C3', "CHASSIS NO"); // Set kolom C3 dengan tulisan "NAMA"
		$excel->setActiveSheetIndex(0)->setCellValue('D3', "DEALER NAME"); // Set kolom D3 dengan tulisan "JENIS KELAMIN"
		$excel->setActiveSheetIndex(0)->setCellValue('E3', "CAR COLOR"); // Set kolom E3 dengan tulisan "ALAMAT"

		// Apply style header yang telah kita buat tadi ke masing-masing kolom header
		$excel->getActiveSheet()->getStyle('A3')->applyFromArray($style_col);
		$excel->getActiveSheet()->getStyle('B3')->applyFromArray($style_col);
		$excel->getActiveSheet()->getStyle('C3')->applyFromArray($style_col);
		$excel->getActiveSheet()->getStyle('D3')->applyFromArray($style_col);
		$excel->getActiveSheet()->getStyle('E3')->applyFromArray($style_col);

		// menampilkan semua data chassis
		$chassis 	= $this->listchassis->showlistuploadchassis($this->session->userdata('serial'),'2');

		$no 	= 1; // Untuk penomoran tabel, di awal set dengan 1
		$numrow	= 4; // Set baris pertama untuk isi tabel adalah baris ke 4
		foreach($chassis as $data){ // Lakukan looping pada variabel chassis
			$excel->setActiveSheetIndex(0)->setCellValue('A'.$numrow, $data->car_model_);
			$excel->setActiveSheetIndex(0)->setCellValue('B'.$numrow, $data->car_type_);
			$excel->setActiveSheetIndex(0)->setCellValue('C'.$numrow, $data->chassis_no);
			$excel->setActiveSheetIndex(0)->setCellValue('D'.$numrow, $data->full_name_);
			$excel->setActiveSheetIndex(0)->setCellValue('E'.$numrow, $data->car_color);
			// Apply style row yang telah kita buat tadi ke masing-masing baris (isi tabel)
			$excel->getActiveSheet()->getStyle('A'.$numrow)->applyFromArray($style_row);
			$excel->getActiveSheet()->getStyle('B'.$numrow)->applyFromArray($style_row);
			$excel->getActiveSheet()->getStyle('C'.$numrow)->applyFromArray($style_row);
			$excel->getActiveSheet()->getStyle('D'.$numrow)->applyFromArray($style_row);
			$excel->getActiveSheet()->getStyle('E'.$numrow)->applyFromArray($style_row);
			$no++; // Tambah 1 setiap kali looping
			$numrow++; // Tambah 1 setiap kali looping
		}

		// Set width kolom
		$excel->getActiveSheet()->getColumnDimension('A')->setWidth(20); // Set width kolom A
		$excel->getActiveSheet()->getColumnDimension('B')->setWidth(10); // Set width kolom B
		$excel->getActiveSheet()->getColumnDimension('C')->setWidth(20); // Set width kolom C
		$excel->getActiveSheet()->getColumnDimension('D')->setWidth(40); // Set width kolom D
		$excel->getActiveSheet()->getColumnDimension('E')->setWidth(25); // Set width kolom E
		// Set height semua kolom menjadi auto (mengikuti height isi dari kolommnya, jadi otomatis)
		$excel->getActiveSheet()->getDefaultRowDimension()->setRowHeight(-1);
		// Set orientasi kertas jadi LANDSCAPE
		$excel->getActiveSheet()->getPageSetup()->setOrientation(PHPExcel_Worksheet_PageSetup::ORIENTATION_LANDSCAPE);
		// Set judul file excel nya
		$excel->getActiveSheet(0)->setTitle("Double Chassis");
		$excel->setActiveSheetIndex(0);
		// Proses file excel
		header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
		header('Content-Disposition: attachment; filename="DoubleChassis.xls"'); // Set nama file excel nya
		header('Cache-Control: max-age=0');
		$write = IOFactory::createWriter($excel, 'Excel5');
		$write->save('php://output');
	}
}
