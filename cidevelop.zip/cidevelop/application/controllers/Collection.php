<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Collection extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvoucher');
		$this->load->model('listchassis');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$session = $this->session->userdata('login'); 
	}

	public function index()
	{
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function insertcollection(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial_statement			= get_serial("add_statement");
		}
	}

	function addcollection(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$prefixbilling				= "CBIH-".date('y')."/";
			$prefixreceipt				= "KCTH-".date('y')."/";
			$data['billingno']			= $this->listquerytable->getnextprefixno($prefixbilling,'vos_billing_process','billing_statement_no');
			$data['receiptno']			= $this->listquerytable->getnextprefixno($prefixreceipt,'vos_billing_process','receipt_statement_no');
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "statementcollection/addcollection.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatecollection(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial						= $this->input->post('serial');
			$data 						= array (
											'billing_statement_no'		=> $this->input->post('billing_statement_no'),
											'receipt_statement_no'		=> $this->input->post('receipt_statement_no'),
											'status'					=> f_v_i_e("1",$this->input->post('status')),
											'last_updated_by'			=> $this->session->userdata('serial'),
											'last_updated_date'			=> date("Y-m-d H:i:s"),
										);
			$where						= array (
											'serial'					=> $serial,
										);
			$this->listvoucher->updatedata($where,$data,'vos_billing_process');
			redirect(base_url().'statementcollection/listcollection');
		}
	}

	function detailcollection(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$id							= $this->uri->segment('3');
			$data['voucher']			= $this->listchassis->showdetailcollection($id);
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "statementcollection/addcollection.php";
			$this->load->view('layout/template',$data);
		}
	}
}
