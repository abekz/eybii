<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hondavoucher extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvoucher');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$session = $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function insertvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial 				= get_serial('addhondavoucher');
			$upgradefilm 			= $this->input->post('upgrade_kacafilm');
			############################################### START :: INSERT DETAIL ###############################################
			$invname 				= "";
			for($d=0;$d<$this->input->post('num_loop_0');$d++){
				$serialdetail		= get_serial('adddetailondavoucher');
					$datax[$d]		= array 	(
													'serial'					=> $serialdetail,
													'created_date'				=> date("Y-m-d H:i:s"),
													'created_by'				=> $this->session->userdata('serial'),
													'sales_serial'				=> $serial,
													'inventory_category'		=> '1',
													'item_group'				=> '1',
													'inventory_serial'			=> f_v_i_e($this->input->post('inventory_serial_'.$d),$this->input->post('inventory_serialx_'.$d)),
													'window_position' 			=> f_v_i_e($this->input->post('window_position_'.$d),$this->input->post('window_positionx_'.$d)),
													'window_position_detail' 	=> f_v_i_e($this->input->post('window_position_detail_'.$d),$this->input->post('window_position_detailx_'.$d)),
													'width'						=> NULL,
													'length_'					=> NULL,
													'qty'						=> '1',
													'price'						=> NULL,
													'discount'					=> NULL,
													'discount_type'				=> NULL,
													'total'						=> NULL,
													'hpp'						=> NULL,
													'price_list'				=> NULL,
													'status'					=> '1',
													'last_updated_by'			=> NULL,
													'last_updated_date'			=> NULL,
													'print_garansi'				=> '1',
												);
				/*
				if($upgradefilm == "1"){
				} else {
					$datax[$d] 		= array 	(
													'serial'					=> $serialdetail,
													'created_date'				=> date("Y-m-d H:i:s"),
													'created_by'				=> $this->session->userdata('serial'),
													'sales_serial'				=> $serial,
													'inventory_category'		=> '1',
													'item_group'				=> '1',
													'inventory_serial'			=> $this->input->post('inventory_serial_'.$d),
													'window_position' 			=> $this->input->post('window_position_'.$d),
													'window_position_detail' 	=> $this->input->post('window_position_detail_'.$d),
													'width'						=> NULL,
													'length_'					=> NULL,
													'qty'						=> '1',
													'price'						=> NULL,
													'discount'					=> NULL,
													'discount_type'				=> NULL,
													'total'						=> NULL,
													'hpp'						=> NULL,
													'price_list'				=> NULL,
													'status'					=> '1',
													'last_updated_by'			=> NULL,
													'last_updated_date'			=> NULL,
													'print_garansi'				=> '1',
												);
				}
				*/
				$invname 	.= $this->listquerytable->getinventoryname($datax[$d]['inventory_serial']).",";
			}
			$this->listvoucher->insertvoucherdetail('vos_voucher_detail',$datax);
			############################################### END :: INSERT DETAIL ###############################################

			############################################## START :: INSERT HEADER ##############################################
			$windowfilmdesc 		= substr($invname, 0, -1);
			if($upgradefilm == "1"){
				$billtotype2 		= $this->input->post('bill_to_type_2');
				$billtoserial2 		= $this->input->post('bill_to_serial_2');
			} else {
				$billtotype2 		= NULL;
				$billtoserial2 		= NULL;
			}
			$data 					= array (
												'serial'						=> $serial,
												'created_date'					=> date("Y-m-d H:i:s"),
												'created_by'					=> $this->session->userdata('serial'),
												'voucher_no'					=> $this->input->post('voucher_no'),
												'showroom_serial'				=> $this->input->post('showroom_serial'),
												'car_type_serial'				=> $this->input->post('car_type_serial'),
												'chassis_serial'				=> $this->input->post('chassis_serial'),
												'nama_pemilik'					=> $this->input->post('nama_pemilik'),
												'alamat_pemilik'				=> get_null_if_empty($this->input->post('alamat_pemilik')),
												'no_handphone'					=> get_null_if_empty($this->input->post('no_handphone')),
												'no_telepon'					=> get_null_if_empty($this->input->post('no_telepon')),
												'tanggal_terbit_voucher'		=> $this->input->post('tanggal_terbit_voucher'),
												'tanggal_pasang_voucher'		=> NULL,
												'updated_tanggal_pasang_by'		=> NULL,
												'updated_tanggal_pasang_date'	=> NULL,
												'last_updated_by'				=> NULL,
												'last_updated_date'				=> NULL,
												'status'						=> '1',
												'status_pasang_voucher'			=> '1',
												'tempat_pasang_voucher'			=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'car_model_serial'				=> get_null_if_empty($this->input->post('car_model_serial')),
												'tanggal_order_voucher'			=> get_null_if_empty($this->input->post('tanggal_order_voucher')),
												'approval_status'				=> '1',
												'approval_date'					=> NULL,
												'approval_by'					=> NULL,
												'sales_invoice_no_car'			=> get_null_if_empty($this->input->post('sales_invoice_no_car')),
												'sales_order_no_car'			=> get_null_if_empty($this->input->post('sales_order_no_car')),
												'car_color'						=> get_null_if_empty($this->input->post('car_color')),
												'bill_to_type_2'				=> $billtotype2,
												'bill_to_serial_2'				=> $billtoserial2,
												'window_film_desc'				=> $windowfilmdesc,
												'dealer_luarkota_serial'		=> get_null_if_empty($this->input->post('dealer_luarkota_serial')),
												'upgrade_kacafilm'				=> get_null_if_empty($this->input->post('upgrade_kacafilm')),
												'approval_date_system'			=> NULL,
												'tanggal_berlaku_warranty'		=> NULL,
												'warranty_no'					=> get_null_if_empty($this->input->post('warranty_no')),
												'sync_warranty_date'			=> NULL,
												'spk_has_updated'				=> NULL,
												'upload_garansi_vkool'			=> NULL,
											);
			$this->listvoucher->insertvoucher('vos_voucher',$data);
			############################################## END :: INSERT HEADER ##############################################
			####################################### START :: UPDATE VOS MASTER CHASSIS #######################################
			$data 					= array (
												'status'	=> '3',
											);
			$where					= array(
												'serial'	=> $this->input->post('chassis_serial'),
											);
			$this->listvoucher->updatedata($where,$data,'vos_master_chassis');
			######################################## END :: UPDATE VOS MASTER CHASSIS ########################################
			redirect(base_url().'hondavoucher/listvoucher');
		}
	}

	function addvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			if ($this->agent->is_browser()) {
				$agent 	= $this->agent->browser().' '.$this->agent->version();
			} elseif ($this->agent->is_robot()) {
				$agent 	= $this->agent->robot();
			} elseif ($this->agent->is_mobile()) {
				$agent 	= $this->agent->mobile();
			} else {
				$agent 	= 'Unidentified User Agent';
			}

			$data['agent']			= $agent;
			$data['agentx']			= $this->agent->platform();
			$data['ipaddress']		= $this->input->ip_address();
			$data['inventoryname']	= $this->listquerytable->getinventoryarray();
			$data['carmodel']		= $this->listquerytable->getcarmodelarray();
			$data['cartype']		= $this->listquerytable->getcartypearray();
			$data['dealervkool']	= $this->listquerytable->getuserarray('4','full_name');
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "hondavoucher/addvoucher.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatevoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial			 		= $this->input->post('serial');
			$upgradefilm 			= $this->input->post('upgrade_kacafilm');
			if($upgradefilm == "1"){
				$billtotype2 		= $this->input->post('bill_to_type_2');
				$billtoserial2 		= $this->input->post('bill_to_serial_2');
			} else {
				$billtotype2 		= NULL;
				$billtoserial2 		= NULL;
			}
			$data = array(
				'dealer_luarkota_serial'	=> $this->input->post('dealer_luarkota_serial'),
				'nama_pemilik'				=> $this->input->post('nama_pemilik'),
				'alamat_pemilik'			=> $this->input->post('alamat_pemilik'),
				'no_telepon'				=> $this->input->post('no_telepon'),
				'no_handphone'				=> $this->input->post('no_handphone'),
				'tempat_pasang_voucher'		=> $this->input->post('tempat_pasang_voucher'),
				'upgrade_kacafilm'			=> $this->input->post('upgrade_kacafilm'),
				'bill_to_type_2'			=> $billtotype2,
				'bill_to_serial_2'			=> $billtoserial2,
			);

			$where = array(
				'serial' => $serial
			);

			$this->listvoucher->updatedata($where,$data,'vos_voucher');
			redirect(base_url().'hondavoucher/listvoucher');
		}
	}

	function listvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();

			$fieldsearch				= f_v_i_e("approval_status",$this->input->post('fieldsearch'));
			$stringvalue1				= f_v_i_e("",$this->input->post('stringvalue1'));
			$stringvalue2				= f_v_i_e("",$this->input->post('stringvalue2'));
			$orderdatefrom				= f_v_i_e(date("Y-m-d", strtotime("".date("Y-m-d")." -7 days")),$this->input->post('orderdatefrom'));
			$orderdateto				= f_v_i_e(date("Y-m-d"),$this->input->post('orderdateto'));

			/**
			$jumlah_data				= $this->listvoucher->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			$this->load->library('pagination');
			$config['base_url']			= base_url().'hondavoucher/listvoucher/';
			$config['total_rows']		= $jumlah_data;
			$config['per_page']			= 15;
			$from						= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']	= "<ul class='pagination'>";
			$config['full_tag_close']	= "</ul>";
			$config['num_tag_open']		= '<li>';
			$config['num_tag_close']	= '</li>';
			$config['cur_tag_open']		= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']	= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']	= "<li>";
			$config['next_tagl_close']	= "</li>";
			$config['prev_tag_open']	= "<li>";
			$config['prev_tagl_close']	= "</li>";
			$config['first_tag_open']	= "<li>";
			$config['first_tagl_close']	= "</li>";
			$config['last_tag_open']	= "<li>";
			$config['last_tagl_close']	= "</li>";

			$config['first_link']		= '< First Page ';
			$config['last_link']		= 'Last Page > ';
			$config['next_link']		= '> ';
			$config['prev_link']		= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']			= $jumlah_data;
			$data['voucher']			= $this->listvoucher->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			*/

			$data['postorderdatefrom']	= $orderdatefrom;
			$data['postorderdateto']	= $orderdateto;
			$data['voucher']			= $this->listvoucher->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			$data['dealervkool']		= $this->listquerytable->getuserarray('4','full_name');
			$data['carmodel']			= $this->listquerytable->getcarmodelarray();
			$data['cartype']			= $this->listquerytable->getcartypearray();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "hondavoucher/listvoucher.php";
			$this->load->view('layout/template',$data);
		}
	}

	function showresultsearchvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$fieldsearch				= $_POST['fieldsearch'];
			$stringvalue1				= $_POST['stringvalue1'];
			$stringvalue2				= $_POST['stringvalue2'];
			$orderdatefrom				= $_POST['orderdatefrom'];
			$orderdateto				= $_POST['orderdateto'];

			/**
			$jumlah_data				= $this->listvoucher->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			$this->load->library('pagination');
			$config['base_url']			= base_url().'hondavoucher/listvoucher/';
			$config['total_rows']		= $jumlah_data;
			$config['per_page']			= 30;
			$from						= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']	= "<ul class='pagination'>";
			$config['full_tag_close']	= "</ul>";
			$config['num_tag_open']		= '<li>';
			$config['num_tag_close']	= '</li>';
			$config['cur_tag_open']		= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']	= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']	= "<li>";
			$config['next_tagl_close']	= "</li>";
			$config['prev_tag_open']	= "<li>";
			$config['prev_tagl_close']	= "</li>";
			$config['first_tag_open']	= "<li>";
			$config['first_tagl_close']	= "</li>";
			$config['last_tag_open']	= "<li>";
			$config['last_tagl_close']	= "</li>";

			$config['first_link']		= '< First Page ';
			$config['last_link']		= 'Last Page > ';
			$config['next_link']		= '> ';
			$config['prev_link']		= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']			= $jumlah_data;
			$data['resultquery']		= $this->listvoucher->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			*/

			$data['resultquery']		= $this->listvoucher->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'');
			$this->load->view('hondavoucher/showresultsearch',$data);
		}
	}

	function changestatusexpired(){
		$chassisserial		= $_POST['serial'];
		$voidchassis		= array (
								'status'		=> '2',
							);
		$wherechassis		= array ('serial'	=> $chassisserial);
		$this->listvoucher->updatedata($wherechassis,$voidchassis,'vos_master_chassis');
	}

	function detailwindowfilm(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$voucherserial			= $_POST['serial'];
			$data['voucherx']		= $this->listvoucher->getdetaillist($voucherserial);
			$this->load->view('hondavoucher/listvoucherdetail',$data);
		}
	}

	function getinformationchassis(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$keyword	= $this->uri->segment(3);
			$data		= $this->listquerytable->getchassis($keyword);
			echo json_encode($data);
		}
	}

	function getinformationdealer(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$dealerserial	= $this->input->post('serial');
			$data 			= $this->listquerytable->getmaindealer($dealerserial);
			echo json_encode($data);
		}
	}

	function getinformationnpwp(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$dealerlk		= $this->input->post('serial');
			$data			= $this->listquerytable->npwpdealerlk($dealerlk);
			echo json_encode($data);
		}
	}

	function getwpdetail(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['wpvalue']	= $this->input->post('wp');
			$this->load->view('layout/wpdetail',$data);
		}
	}

	function detailvoucher($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			//$voucherserial			= $_GET['serial'];
			$data['voucher']		= $this->listvoucher->showdetailvoucher($id);
			$data['voucherdetail']	= $this->listvoucher->getdetaillist($id);
			$data['dealervkool']	= $this->listquerytable->getuserarray('4','full_name');
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "hondavoucher/detailvoucher.php";
			$this->load->view('layout/template',$data);
		}
	}

	function approvalvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial					= $this->input->post('serial');
			$chassisnox				= $this->input->post('chassisnox');
			$vouchernox				= $this->input->post('vouchernox');
			$carmodelx				= $this->input->post('carmodelx');
			$carcolorx				= $this->input->post('carcolorx');
			$upgradekacafilmx		= $this->input->post('upgradekacafilmx');
			$installationaddressx	= $this->input->post('installationaddressx');
			$orderdatex				= $this->input->post('orderdatex');
			$dealerluarkotaserialx	= $this->input->post('dealerluarkotaserialx');
			$dealerserialx			= $this->input->post('dealerserialx');
			$data 					= array (
												'approval_status'		=> $this->input->post('approval_statusx'),
												'approval_date'			=> date("Y-m-d"),
												'approval_date_system'	=> date("Y-m-d H:i:s"),
												'approval_by'			=> $this->session->userdata('serial'),
											);
			$this->listvoucher->approvedvoucher($data,$serial);
			$this->session->set_flashdata('notif','<div class="alert alert-success" role="alert">Approval Success <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button></div>');

			$this->email->from('vos.honda@scs-vkool.com', 'VOUCHER ONLINE SYSTEM');
			####### MENAMPILKAN LIST EMAIL DEALER HONDA #######
			$emaildl 		= "";
			$resdealer		= $this->listquerytable->getemailuser('7','dealer_serial',$dealerserialx);
			for($dl=0;$dl<count($resdealer);$dl++) {
				$emaildl	.= $resdealer[$dl]->email."," ;
			}
			###################################################
			####### MENAMPILKAN LIST EMAIL DEALER VKOOL #######
			$emaildlk 		= "";
			$resdealerlk	= $this->listquerytable->getemailuser('4','serial',$dealerluarkotaserialx);
			for($dlk=0;$dlk<count($resdealerlk);$dlk++) {
				$emaildlk	.= $resdealerlk[$dlk]->email."," ;
			}
			###################################################
			//'counter@scs-vkool.com',
			//print_r($resdealerlk);
			$toemailadd		= substr($emaildl,0,-1).",".substr($emaildlk,0,-1);
			$this->email->to($toemailadd);
			$this->email->cc('scs.counter@yahoo.com');
			$this->email->subject('[PEMESANAN] Kaca Film Mobil Honda '.$carmodelx.' ( '.$chassisnox.' )');
			$bodyinformasi	= "Berikut ini adalah informasi mengenai Pemasangan Kaca Film V-KOOL :<br /><br />";
			$bodyinformasi	.= "No. Voucher						: <b>".$vouchernox."</b><br />";
			$bodyinformasi	.= "No. Rangka Kendaraan 			: <b>".$chassisnox."</b><br />";
			$bodyinformasi	.= "Model Mobil Honda				: <b>".$carmodelx."</b><br />";
			$bodyinformasi	.= "Warna Mobil Honda				: <b>".$carcolorx."</b><br />";
			$bodyinformasi	.= "Tanggal Pengajuan Pemasangan	: <b>".format_date($orderdatex)."</b><br />";
			$bodyinformasi	.= "Tempat Pemasangan				: <b>".strtoupper($installationaddressx)."</b><br />";
			$bodyinformasi	.= "Upgrade	?						: <b>".yes_no($upgradekacafilmx)."</b><br /><br />";
			$bodyinformasi	.= "Kaca Film Yang Dipasang			: <b><br />";

			$resdetail		= $this->listvoucher->getdetaillist($serial);
			for ($jv=0;$jv<count($resdetail);$jv++) {
				$bodyinformasi	.= window_position($resdetail[$jv]->window_position)." ".window_position_detail($resdetail[$jv]->window_position,$resdetail[$jv]->window_position_detail)." : <i>".$resdetail[$jv]->inventory_name."</i><br />";
			}

			$bodyinformasi	.= "</b><br />";
			$bodyinformasi	.= "Demikianlah informasi pemasangan kaca film VKOOL tersebut.<br /><br />Atas perhatian dan kerjasama nya, kami ucapkan terima kasih.<br /><br /><br />";
			$bodyinformasi	.= "Salam,<br /><br /><br />Voucher Online System<br /><br /><br />";
			$bodyinformasi	.= "-------------------------------------------------------------------------------------<br />";
			$bodyinformasi	.= "This Is An Automatically Generated Email, Please Do Not Reply.<br />";
			$bodyinformasi	.= "-------------------------------------------------------------------------------------";
			$this->email->message($bodyinformasi);
			if(!$this->email->send()){
				$this->email->print_debugger();
			}
			redirect(base_url().'hondavoucher/listvoucher');
		}
	}
}

