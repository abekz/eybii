<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Huperoptik extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listhuperoptik');
		$this->load->model('listvoucher');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$this->huper	= $this->load->database('huperoptik', TRUE);
		$this->vkp		= $this->load->database('vkoolpusat', TRUE);
		$session		= $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function showresultsearchvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$fieldsearch				= $_POST['fieldsearch'];
			$stringvalue1				= $_POST['stringvalue1'];
			$stringvalue2				= $_POST['stringvalue2'];
			$orderdatefrom				= $_POST['orderdatefrom'];
			$orderdateto				= $_POST['orderdateto'];

			/**
			$jumlah_data				= $this->listhuperoptik->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			$this->load->library('pagination');
			$config['base_url']			= base_url().'upgradehuper/listhuperoptik/';
			$config['total_rows']		= $jumlah_data;
			$config['per_page']			= 15;
			$from						= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']	= "<ul class='pagination'>";
			$config['full_tag_close']	= "</ul>";
			$config['num_tag_open']		= '<li>';
			$config['num_tag_close']	= '</li>';
			$config['cur_tag_open']		= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']	= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']	= "<li>";
			$config['next_tagl_close']	= "</li>";
			$config['prev_tag_open']	= "<li>";
			$config['prev_tagl_close']	= "</li>";
			$config['first_tag_open']	= "<li>";
			$config['first_tagl_close']	= "</li>";
			$config['last_tag_open']	= "<li>";
			$config['last_tagl_close']	= "</li>";

			$config['first_link']		= '< First Page ';
			$config['last_link']		= 'Last Page > ';
			$config['next_link']		= '> ';
			$config['prev_link']		= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']			= $jumlah_data;
			$data['resultquery']		= $this->listhuperoptik->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			*/

			$data['resultquery']		= $this->listhuperoptik->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			$this->load->view('upgradehuper/showresultsearch',$data);
		}
	}

	function listhuperoptik(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$fieldsearch				= f_v_i_e("approval_status",$this->input->post('fieldsearch'));
			$stringvalue1				= f_v_i_e("2",$this->input->post('stringvalue1'));
			$stringvalue2				= f_v_i_e("",$this->input->post('stringvalue2'));
			$orderdatefrom				= f_v_i_e(date("Y-m-d", strtotime("".date("Y-m-d")." -7 days")),$this->input->post('orderdatefrom'));
			$orderdateto				= f_v_i_e(date("Y-m-d"),$this->input->post('orderdateto'));

			/**
			$jumlah_data				= $this->listhuperoptik->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			$this->load->library('pagination');
			$config['base_url']			= base_url().'upgradehuper/listhuperoptik/';
			$config['total_rows']		= $jumlah_data;
			$config['per_page']			= 15;
			$from						= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']	= "<ul class='pagination'>";
			$config['full_tag_close']	= "</ul>";
			$config['num_tag_open']		= '<li>';
			$config['num_tag_close']	= '</li>';
			$config['cur_tag_open']		= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']	= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']	= "<li>";
			$config['next_tagl_close']	= "</li>";
			$config['prev_tag_open']	= "<li>";
			$config['prev_tagl_close']	= "</li>";
			$config['first_tag_open']	= "<li>";
			$config['first_tagl_close']	= "</li>";
			$config['last_tag_open']	= "<li>";
			$config['last_tagl_close']	= "</li>";

			$config['first_link']		= '< First Page ';
			$config['last_link']		= 'Last Page > ';
			$config['next_link']		= '> ';
			$config['prev_link']		= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']			= $jumlah_data;
			$data['voucher']			= $this->listhuperoptik->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			*/

			$data['voucher']			= $this->listhuperoptik->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto);
			$data['dealervkool']		= $this->listquerytable->getuserarray('4','full_name');
			$data['carmodel']			= $this->listquerytable->getcarmodelarray();
			$data['cartype']			= $this->listquerytable->getcartypearray();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "upgradehuper/listhuperoptik.php";
			$this->load->view('layout/template',$data);
		}
	}

	function detailhuperoptik($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']			= $this->listhuperoptik->showdetailvoucher($id);
			$data['voucherdetail']		= $this->listhuperoptik->getdetaillist($id);
			$data['dealervkool']		= $this->listquerytable->getuserarray('4','full_name');
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "upgradehuper/detailhuperoptik.php";
			$this->load->view('layout/template',$data);
		}
	}

	function inserthuperoptik(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serialusers				= get_serial('addcustomer');
			$serialsobaru				= get_serial('addsalesordernocar');
			$serialsibaru				= get_serial('addsalesinvoicenocar');
			$prefixusers				= $this->listquerytable->getnextprefixno("CUSH-".date("y")."/","users","user_id");
			if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
				$prefixso				= $this->listquerytable->getnextprefixno("SOCH-".date("y")."/","sales","sales_order_no_car");
			} else {
				$prefixluarkota			= $this->listquerytable->getfieldfromtable("vos_users","prefix_no","serial",$this->input->post('dealer_luarkota_serial'));
				$prefixlk				= "SOCHL".$prefixluarkota."-".date("y")."/";
				$prefixso				= $this->listquerytable->getnextprefixno($prefixlk,"sales","sales_order_no_car");
			}
			$prefixspk					= str_replace("SOC", "SPK", $prefixso);
			$prefixsi					= str_replace("SOC", "SCS", $prefixso);
			$upgradefilm 				= $this->input->post('upgrade_kacafilm');
			######################################### START INFO ::: GANTI STATUS NO GARANSI ########################################
			if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
				$prefixwarranty			= "NV".format_date($this->input->post('tanggal_order_voucher'),"y").format_date($this->input->post('tanggal_order_voucher'),"m") ;
				$warrantyno				= $this->listquerytable->getwarrantyno($prefixwarranty);
				$voidwarranty			= array (
											'status'				=> '2',
											'last_updated_by'		=> $this->session->userdata('serial'),
											'last_updated_date'		=> date("Y-m-d H:i:s"),
										);
				$wherewarranty			= array ('warranty_card'	=> $warrantyno);
				$taxno					= $this->listquerytable->gettaxno();
				$voidtaxno				= array (
											'status'				=> '2',
											'sales_order_no_car'	=> $prefixso,
											'order_date'			=> $orderdate,
											'last_updated_by'		=> $this->session->userdata('serial'),
											'last_updated_date'		=> date("Y-m-d H:i:s"),
										);
				$wheretaxno				= array ('tax_no'			=> $taxno);
				$this->listvoucher->updatedata($wherewarranty,$voidwarranty,'warranty_card');
				$this->listvoucher->updatedata($wheretaxno,$voidtaxno,'sales_tax');
			}
			########################################## END INFO ::: GANTI STATUS NO GARANSI #########################################
			############################################ START :: UPDATE DATA HUPEROPTIK ############################################
			$datavoucherhuper			= array(
											'status_pasang_voucher'		=> $this->input->post('status_pasang_voucher'),
											'tanggal_pasang_voucher'	=> $this->input->post('tanggal_pasang_voucher'),
											'sales_order_no_car'		=> $prefixso,
											'sales_invoice_no_car'		=> $prefixsi,
										);
			$wherevoucherhuper			= array('serial' => $this->input->post('serial'));
			$this->listhuperoptik->updatedata($wherevoucherhuper,$datavoucherhuper,'vos_voucher');
			########################################## END INFO ::: UPDATE DATA HUPEROPTIK ##########################################
			################################################# START :: INSERT USERS #################################################
			$datausers					= array (
											'serial'					=> $serialusers,
											'created_by'				=> $this->session->userdata('serial'),
											'user_type'					=> '2',
											'status'					=> '1',
											'user_id'					=> $prefixusers,
											'full_name'					=> $this->input->post('nama_pemilik'),
											'address'					=> $this->input->post('alamat_pemilik'),
											'cell_phone'				=> $this->input->post('no_handphone'),
											'home_phone'				=> $this->input->post('no_telepon'),
										);
			$this->listvoucher->insertvoucher('users',$datausers);
			################################################## END :: INSERT USERS ##################################################
			############################################### START :: INSERT SO DETAIL ###############################################
			$invname 					= "";
			for($d=0;$d<$this->input->post('num_loop_0');$d++){
				$serialdetail			= get_serial('adddetailondavoucher');
				$datax[$d]				= array (
											'serial'					=> $serialdetail,
											'created_date'				=> date("Y-m-d H:i:s"),
											'created_by'				=> $this->session->userdata('serial'),
											'sales_serial'				=> $serialsobaru,
											'inventory_category'		=> '1',
											'item_group'				=> '1',
											'inventory_serial'			=> $this->input->post('inventory_serial_'.$d),
											'window_position' 			=> $this->input->post('window_position_'.$d),
											'window_position_detail' 	=> $this->input->post('window_position_detail_'.$d),
											'width'						=> NULL,
											'length_'					=> NULL,
											'qty'						=> '1',
											'price'						=> NULL,
											'discount'					=> NULL,
											'discount_type'				=> NULL,
											'total'						=> NULL,
											'hpp'						=> NULL,
											'price_list'				=> NULL,
											'status'					=> '1',
											'last_updated_by'			=> NULL,
											'last_updated_date'			=> NULL,
											'print_garansi'				=> '1',
										);
				$invname 	.= $this->listquerytable->getinventoryname($datax[$d]['inventory_serial']).",";
				$datavkp[$d]			= array (
											'serial'					=> $serialtablegaransi,
											'created_date'				=> date("Y-m-d H:i:s"),
											'garansi_code'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
											'car_brand'					=> 'HONDA',
											'car_type'					=> $this->input->post('txt_car_model'),
											'car_no_rangka'				=> strtoupper($this->input->post('chassis_no')),
											'car_no_mesin'				=> get_null_if_empty($this->input->post('machine_no')),
											'car_warna'					=> strtoupper($this->input->post('car_color')),
											'car_tahun'					=> f_v_i_e(date("Y"),$this->input->post('car_year')),
											'car_no_polisi'				=> strtoupper($this->input->post('police_no')),
											'kaca_film_brand'			=> 'V-KOOL',
											'kaca_film_tipe'			=> $kacafilmtipe,
											'kaca_film_posisi'			=> window_position($this->input->post('window_position_'.$d)),
											'poin_customer'				=> $this->input->post('poin_customer'),
											'poin_sales'				=> $this->input->post('poin_sales'),
											'master_roll'				=> $this->input->post('master_roll'),
											'note'						=> 'PAKET HONDA',
											'customer_nama'				=> strtoupper($this->input->post('nama_pemilik')),
											'customer_id'				=> $prefixusers,
											'customer_alamat'			=> strtoupper($this->input->post('alamat_pemilik')),
											'customer_kota'				=> f_v_i_e("JAKARTA",strtoupper($this->input->post('city'))),
											'customer_kodepos'			=> get_null_if_empty($this->input->post('zip')),
											'customer_email'			=> get_null_if_empty($this->input->post('email')),
											'customer_hp'				=> get_null_if_empty($this->input->post('no_handphone')),
											'sales_nama'				=> get_null_if_empty($this->input->post('sales_nama')),
											'sales_id'					=> get_null_if_empty($this->input->post('sales_id')),
											'sales_alamat'				=> get_null_if_empty($this->input->post('sales_alamat')),
											'sales_kota'				=> get_null_if_empty($this->input->post('sales_kota')),
											'sales_kodepos'				=> get_null_if_empty($this->input->post('sales_kodepos')),
											'sales_email'				=> get_null_if_empty($this->input->post('sales_email')),
											'sales_hp'					=> get_null_if_empty($this->input->post('sales_hp')),
											'invoice'					=> f_v_i_e($prefixso,$this->input->post('so_no')),
											'showroom_nama'				=> get_null_if_empty($this->input->post('txt_showroom_serial')),
											'showroom_alamat'			=> get_null_if_empty($this->input->post('showroom_alamat')),
											'showroom_kota'				=> get_null_if_empty($this->input->post('showroom_kota')),
											'showroom_kodepos'			=> get_null_if_empty($this->input->post('showroom_kodepos')),
											'showroom_telp'				=> get_null_if_empty($this->input->post('showroom_telp')),
											'showroom_pic'				=> get_null_if_empty($this->input->post('showroom_pic')),
											'tgl_pasang'				=> $pairingdate,
											'tgl_expired'				=> $duedatetek,
											'teknisi'					=> get_null_if_empty($this->input->post('teknisi')),
											'no_garansi_scs'			=> get_null_if_empty($this->input->post('no_garansi_scs')),
											'status'					=> 'DELETED OR CANCELLED',
											'tipe_garansi'				=> 'AUTOMOTIVE',
											'posisi_detail'				=> window_position_detail($this->input->post('window_position_'.$d),$this->input->post('window_position_detail_'.$d)),
										);
			}
			$this->listvoucher->insertvoucherdetail('sales_detail',$datax);
			############################################### END :: INSERT SO DETAIL ###############################################
			############################################### START :: INSERT SO HEADER ###############################################
			$windowfilmdesc 				= substr($invname, 0, -1);
			$totday							= date("t");
			$duedate						= date("Y-m-d", strtotime("".$this->input->post('tanggal_order_voucher')." +".$totday." days"));
			if($this->input->post('pajak_company_serial') == "02.417.173.8-048.000"){
				if(!(strpos($windowfilmdesc,'RX')===false)) {
					$installationcategory1 	= "958e7a6b0c045480dbc67f63059d761b";
				} else {
					$installationcategory1 	= "f9ef3d29aebe37f053c45a7464597350";
				}
				$dealerluarkotaserial		= NULL ;
				if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6"){
					$totalbonus				= "205000";
				} else {
					if(!(strpos($windowfilmdesc,'RX')===false)) {
						$totalbonus			= "130000";
					} else {
						$totalbonus			= "155000";
					}
				}
				$locationtype 				= "1";
			} else if($this->input->post('pajak_company_serial') == "2"){
				$installationcategory1 		= "58f8818d89fafed83578e672331142a2";
				$dealerluarkotaserial 		= $this->input->post('dealer_luarkota_serial');
				$totalbonus 				= "336000";
				$locationtype 				= "2";
			} else {
				$installationcategory1 		= "47aa83eb925785efeed5ffd970e5b49a";
				$dealerluarkotaserial 		= $this->input->post('dealer_luarkota_serial');
				$totalbonus 				= "343636";
				$locationtype 				= "2";
			}
			$datasobaru						= array (
												'serial'					=> $serialsobaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_order_no_car'		=> $prefixso,
												'spk_no'					=> $prefixspk,
												'warranty_no'				=> get_null_if_empty($warrantyno),
												'sales_type'				=> '1',
												'status'					=> '1',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'tax_no'					=> get_null_if_empty($taxno),
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'UPGRADE PAKET HUPEROPTIK',
												'order_date'				=> format_date($this->input->post('tanggal_order_voucher'),"Y-m-d"),
												'installation_date'			=> format_date($this->input->post('tanggal_pasang_voucher'),"Y-m-d"),
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'total_bonus'				=> $totalbonus,
												'due_date'					=> $duedate,
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'bill_to_type_1'			=> '4',
												'bill_to_serial_1'			=> 'a8a5ff95854851fc9a0927b34fd9de35',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
											);
			$this->listvoucher->insertvoucher('sales',$datasobaru);
			################################################ END :: INSERT SO HEADER ################################################
			############################################### START :: INSERT SI DETAIL ###############################################
			for($dsi=0;$dsi<$this->input->post('num_loop_0');$dsi++){
				$serialdetailsi				= get_serial('adddetailsihuperoptik');
				$datasi[$dsi]				= array (
												'serial'					=> $serialdetailsi,
												'created_date'				=> date("Y-m-d H:i:s"),
												'created_by'				=> $this->session->userdata('serial'),
												'sales_serial'				=> $serialsibaru,
												'inventory_category'		=> '1',
												'item_group'				=> '1',
												'inventory_serial'			=> $this->input->post('inventory_serial_'.$dsi),
												'window_position' 			=> $this->input->post('window_position_'.$dsi),
												'window_position_detail' 	=> $this->input->post('window_position_detail_'.$dsi),
												'width'						=> NULL,
												'length_'					=> NULL,
												'qty'						=> '1',
												'price'						=> '0',
												'discount'					=> NULL,
												'discount_type'				=> NULL,
												'total'						=> '0',
												'hpp'						=> NULL,
												'price_list'				=> '0',
												'status'					=> '1',
												'last_updated_by'			=> NULL,
												'last_updated_date'			=> NULL,
												'print_garansi'				=> '1',
											);
			}
			$this->listvoucher->insertvoucherdetail('sales_detail',$datasi);
			################################################ END :: INSERT SI DETAIL ################################################
			############################################### START :: INSERT SI HEADER ###############################################
			$bill_to_type_1					= "4" ; 
			$bill_to_serial_1				= "a8a5ff95854851fc9a0927b34fd9de35" ; 
			$used_price_type				= "2" ; 
			$nett_price_serial				= "1d99320e9239393b4a59ef6d2ce03303" ; 
			$pay_commission_to_type			= NULL ; 
			$pay_commission_to_serial		= NULL ; 
			$commission						= "0" ; 
			$commission_type				= "2" ; 
			$total_commission				= "0" ; 
			$discount						= "0" ; 
			$discount_type					= "1" ; 
			$freight						= "0" ; 
			$ppn							= "10" ; 
			$down_payment					= "0" ; 
			$total_price_list				= "0" ; 
			$dpp_material					= "0" ; 
			$sub_total						= "0" ; 
			$amount_1						= "0" ; 
			$balance						= "0" ; 
			$total							= "0" ; 
			$total_price_nett				= "0" ; 
			$total_before_pph				= "0" ; 
			$total_hpp						= "0" ; 
			$other							= "0" ; 
			$other_2						= "0" ; 
			$other_desc						= NULL ; 
			$other_desc_2					= NULL ; 
			$ppn_other						= "0" ; 
			$datasibaru						= array (
												'serial'					=> $serialsibaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_invoice_no_car'		=> $prefixsi,
												'sales_order_no'			=> $serialsobaru,
												'warranty_no'				=> get_null_if_empty($warrantyno),
												'sales_type'				=> '2',
												'status'					=> '2',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'tax_no'					=> get_null_if_empty($taxno),
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'UPGRADE PAKET HUPEROPTIK',
												'order_date'				=> format_date($this->input->post('tanggal_order_voucher'),"Y-m-d"),
												'installation_date'			=> format_date($this->input->post('tanggal_pasang_voucher'),"Y-m-d"),
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'total_bonus'				=> $totalbonus,
												'due_date'					=> $duedate,
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'installation_category_1'	=> '47aa83eb925785efeed5ffd970e5b49a',
												'bill_to_type_1'			=> $bill_to_type_1 ,
												'bill_to_serial_1'			=> $bill_to_serial_1 ,
												'used_price_type'			=> $used_price_type ,
												'nett_price_serial'			=> $nett_price_serial ,
												'pay_commission_to_type'	=> $pay_commission_to_type ,
												'pay_commission_to_serial'	=> $pay_commission_to_serial ,
												'commission'				=> $commission ,
												'commission_type'			=> $commission_type ,
												'total_commission'			=> $total_commission ,
												'discount'					=> $discount ,
												'discount_type'				=> $discount_type ,
												'freight'					=> $freight ,
												'ppn'						=> $ppn ,
												'down_payment'				=> $down_payment ,
												'total_price_list'			=> $total_price_list ,
												'dpp_material'				=> $dpp_material ,
												'sub_total'					=> $sub_total ,
												'amount_1'					=> $amount_1 ,
												'balance'					=> $balance ,
												'total'						=> $total ,
												'total_price_nett'			=> $total_price_nett ,
												'total_before_pph'			=> $total_price_nett ,
												'total_hpp'					=> $total_hpp ,
												'other'						=> $other ,
												'other_2'					=> $other_2 ,
												'other_desc'				=> $other_desc ,
												'other_desc_2'				=> $other_desc_2 ,
												'ppn_other'					=> $ppn_other ,
												'jasa_pemasangan'			=> '200000',
												'pph_value'					=> '4000',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
												'bill_to_type_2'			=> $this->input->post('bill_to_type_2') ,
												'bill_to_serial_2'			=> $this->input->post('bill_to_serial_2') ,
											);
			$this->listvoucher->insertvoucher('sales',$datasibaru);
			################################################ END :: INSERT SI HEADER ################################################
			############################################ START :: INSERT PURCHASE HEADER ############################################
			$serialpurchase					= get_serial('addpurchase');
			$prefixpurchase					= $this->listquerytable->getnextprefixno("PINH-".date("y")."/","purchase","purchase_invoice_no");
			$purchaseprice					= $this->listquerytable->getpurchaseprice($this->input->post('tanggal_terbit_voucher'),'',$this->input->post('dealer_luarkota_serial'),$this->input->post('car_model_serial'));
			$pricebahan 					= f_v_i_e("0",$purchaseprice[0]->price_bahan);
			$pricejasa 						= f_v_i_e("0",$purchaseprice[0]->price_jasa);
			$price 							= f_v_i_e("0",$purchaseprice[0]->price);
			$rebate 						= f_v_i_e("0",$purchaseprice[0]->rebate);
			/**
			for($pp=0;$pp<count($purchaseprice);$pp++) {
				$pricebahan	= $purchaseprice[$pp]->price_bahan ;
				$pricejasa	= $purchaseprice[$pp]->price_jasa ;
				$price 		= $purchaseprice[$pp]->price ;
				$rebate		= $purchaseprice[$pp]->rebate ;
			}
			*/
			$datapurchasebaru				= array (
												'serial'					=> $serialpurchase,
												'created_by'				=> $this->session->userdata('serial'),
												'purchase_type'				=> '3',
												'purchase_invoice_no'		=> $prefixpurchase,
												'date'						=> format_date($this->input->post('tanggal_pasang_voucher'),"Y-m-d"),
												'supplier_type'				=> 'K',
												'supplier_serial'			=> $this->input->post('dealer_luarkota_serial'),
												'supplier_invoice_no'		=> $this->input->post('chassis_no'),
												'exchange_rate_currency'	=> '1',
												'exchange_rate_kurs'		=> '9000',
												'bill_to_type'				=> 'K',
												'bill_to_serial'			=> $this->input->post('dealer_luarkota_serial'),
												'note'						=> $this->input->post('txt_car_model_serial')." ( ".$this->input->post('chassis_no')." )",
												'sub_total'					=> $price,
												'discount'					=> '0',
												'discount_type'				=> '1',
												'freight'					=> '0',
												'ppn'						=> '0',
												'total'						=> $price,
												'down_payment'				=> '0',
												'balance'					=> $price,
												'total_rebate_us'			=> '0',
												'total_rebate_idr'			=> $rebate,
												'status'					=> '1',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'payment_type'				=> '1',
												'sales_invoice_no'			=> $serialsibaru,
											);
			$this->listvoucher->insertvoucher('purchase',$datapurchasebaru);
			############################################# END :: INSERT PURCHASE HEADER #############################################
			############################################ START :: INSERT PURCHASE DETAIL ############################################
			for($dpi=0;$dpi<1;$dpi++){
				$serialdetailpurchase		= get_serial('adddetailpurchase');
				$datapi[$dpi]				= array (
												'serial'					=> $serialdetailpurchase,
												'created_date'				=> date("Y-m-d H:i:s"),
												'created_by'				=> $this->session->userdata('serial'),
												'purchase_serial'			=> $serialpurchase,
												'inventory_category'		=> '1',
												'item_group'				=> '1',
												'inventory_serial'			=> 'c949e16e7231f4718ab4e819606ec2de',
												'width'						=> '0',
												'length_'					=> '0',
												'qty'						=> '1',
												'price'						=> $price,
												'discount'					=> '0',
												'discount_type'				=> '2',
												'total'						=> '0',
												'rebate_usd'				=> '0',
												'rebate_idr'				=> $rebate,
												'status'					=> '1',
												'last_updated_by'			=> NULL,
												'last_updated_date'			=> NULL,
											);
			}
			$this->listvoucher->insertvoucherdetail('purchase_detail',$datapi);
			############################################# END :: INSERT PURCHASE DETAIL #############################################
			########################################## START INFO : SEND EMAIL NOTIFICATION #########################################
			$this->email->from('vos.honda@scs-vkool.com', 'VOUCHER ONLINE SYSTEM');
			####### MENAMPILKAN LIST EMAIL DEALER HONDA #######
			$emaildl 		= "";
			$resdealer		= $this->listquerytable->getemailuser('7','dealer_serial',$this->input->post('showroom_serial'));
			for($dl=0;$dl<count($resdealer);$dl++) {
				$emaildl	.= $resdealer[$dl]->email."," ;
			}
			###################################################
			####### MENAMPILKAN LIST EMAIL DEALER VKOOL #######
			$emaildlk 		= "";
			$resdealerlk	= $this->listquerytable->getemailuser('4','serial',$this->input->post('dealer_luarkota_serial'));
			for($dlk=0;$dlk<count($resdealerlk);$dlk++) {
				$emaildlk	.= $resdealerlk[$dlk]->email."," ;
			}
			###################################################
			//'counter@scs-vkool.com',
			//print_r($resdealerlk);
			$toemailadd		= substr($emaildl,0,-1).",".substr($emaildlk,0,-1);
			$this->email->to($toemailadd);
			$this->email->cc('scs.counter@yahoo.com');
			$this->email->subject('[PEMASANGAN - UPGRADE HUPEROPTIK] Kaca Film Mobil Honda '.$this->input->post('txt_car_model_serial').' ( '.$this->input->post('chassis_no').' )');
			$bodyinformasi	= "Berikut ini adalah informasi mengenai Pemasangan Kaca Film V-KOOL :<br /><br />";
			$bodyinformasi	.= "No. Voucher						: <b>".$this->input->post('voucher_no')."</b><br />";
			$bodyinformasi	.= "No. Rangka Kendaraan 			: <b>".$this->input->post('chassis_no')."</b><br />";
			$bodyinformasi	.= "Model Mobil Honda				: <b>".$this->input->post('txt_car_model_serial')."</b><br />";
			$bodyinformasi	.= "Warna Mobil Honda				: <b>".$this->input->post('car_color')."</b><br />";
			$bodyinformasi	.= "Tanggal Pengajuan Pemasangan	: <b>".format_date($this->input->post('tanggal_order_voucher'))."</b><br />";
			$bodyinformasi	.= "Upgrade	?						: <b>".yes_no($this->input->post('upgrade_kacafilm'))."</b><br /><br />";
			$bodyinformasi	.= "Kaca Film Yang Dipasang			: <b><br />";
			$resdetail		= $this->listhuperoptik->getdetaillist($this->input->post('serial'));
			for ($jv=0;$jv<count($resdetail);$jv++) {
				$bodyinformasi	.= window_position($resdetail[$jv]->window_position)." ".window_position_detail($resdetail[$jv]->window_position,$resdetail[$jv]->window_position_detail)." : <i>".$resdetail[$jv]->inventory_name."</i><br />";
			}
			$bodyinformasi	.= "</b><br />";
			$bodyinformasi	.= "Ingin menginformasikan bahwa mobil tersebut diatas akan dilakukan pemasangan kaca film VKOOL pada : <br />";
			$bodyinformasi	.= "Tanggal Pemasangan				: <b>".format_date(f_v_i_e(date("Y-m-d"),$this->input->post('tanggal_pasang_voucher')))."</b><br />";
			$bodyinformasi	.= "Tempat Pemasangan				: <b>".strtoupper($this->input->post('tempat_pasang_voucher'))."</b><br /><br />";
			$bodyinformasi	.= "Atas perhatian dan kerjasama nya, kami ucapkan terima kasih.<br /><br /><br />";
			$bodyinformasi	.= "----------------------------------------------------------------------------------------------------------------------<br />";
			$bodyinformasi	.= "<b>NB : APABILA DALAM JANGKA WAKTU 2 HARI SETELAH TANGGAL PEMASANGAN,<br />KACAFILM V-KOOL BELUM TERPASANG PADA UNIT MOBIL</b><br />";
			$bodyinformasi	.= "<b>DIHARAPKAN SEGERA DIBUAT MEMO BATAL</b><br />";
			$bodyinformasi	.= "----------------------------------------------------------------------------------------------------------------------<br /><br />";
			$bodyinformasi	.= "Salam,<br /><br /><br />Voucher Online System<br /><br /><br />";
			$bodyinformasi	.= "-------------------------------------------------------------------------------------<br />";
			$bodyinformasi	.= "This Is An Automatically Generated Email, Please Do Not Reply.<br />";
			$bodyinformasi	.= "-------------------------------------------------------------------------------------";
			$this->email->message($bodyinformasi);
			if(!$this->email->send()){
				$this->email->print_debugger();
			}
			########################################### END INFO : SEND EMAIL NOTIFICATION ##########################################
			redirect(base_url().'huperoptik/listhuperoptik');
		}
	}
}



