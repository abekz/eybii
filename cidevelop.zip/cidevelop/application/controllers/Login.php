<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->helper('form');
		$this->load->library('form_validation');
		$this->load->library('session');
		$this->load->model('loginuser');
	}

	public function index()
	{
		if($this->session->userdata('login') == true){
			redirect(base_url().'home');
		} else {
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "pemasangan kaca film vkool";
			$data['view_isi']			= "login";
			$data['message_display']	= "Please Login";
			$this->load->view('login.php',$data);
	    }
	}

	public function ceklogin() {
		$uname	= $this->input->get("uname");
		$passwd	= $this->input->get("passwd");
		$cek	= $this->loginuser->cekloginuser($uname,$passwd);
		$row	= $cek->row(); 

		if(count($row) == 1){ 
			$login				= TRUE;
			$serial				= $row->serial ;
			$dealer_serial		= $row->dealer_serial ;
			$main_dealer_serial	= $row->main_dealer_serial ;
			$level				= $row->level ;
			$user_id			= $row->user_id ;
			$full_name			= $row->full_name ;
			$password			= $row->password ;

			$this->session->set_userdata(array(
				'login'   				=> TRUE,
				'serial'				=> $serial,
				'dealer_serial'			=> $dealer_serial,
				'main_dealer_serial'	=> $main_dealer_serial,
				'level'					=> $level,
				'user_id'				=> $user_id,
				'full_name'				=> $full_name,
				'password'				=> $password,
			));

			redirect(base_url().'home');
			/*
			$data['title'] = "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle'] = "Membuat Website Sederhana";
			$data['description'] = "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi'] = "viewhome";
			header('location:'.base_url().'home');
			*/
		} else {
			$data['title'] = "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle'] = "Membuat Website Sederhana";
			$data['description'] = "pemasangan kaca film vkool";
			$data['view_isi'] = "login";
			$data['message_display'] = "Invalid Username or Password!";
			$this->load->view('login.php',$data);
		}
	}

	public function logout() {
		// Removing session data
		$sess_array = array(
			'username'				=> '',
			'user_serial'			=> '',
			'main_dealer_serial'	=> '',
			'user_access'			=> '',
			'user_id'				=> '',
			'user_name'				=> '',
			'password'				=> '',
		);
		$this->session->unset_userdata('logged_in', $sess_array);
		$this->session->sess_destroy();
		header('location:'.base_url());
	}
}
