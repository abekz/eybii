<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Masterdata extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvoucher');
		$this->load->model('listmasterdata');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$session = $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	######################################################## VOS CAR BRAND ########################################################
	function listcarbrand(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$data['carbrand']			= $this->listmasterdata->showlistcarbrand();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "masterdata/listcarbrand.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertcarbrand(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial 				= get_serial('addcarbrand');
			$data 					= array (
												'serial'		=> $serial,
												'created_by'	=> $this->session->userdata('serial'),
												'car_brand'		=> $this->input->post('car_brand'),
												'status'		=> '1',
											);
			$this->listvoucher->insertvoucher('vos_car_brand',$data);
			redirect(base_url().'masterdata/listcarbrand');
		}
	}

	function addcarbrand(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/addcarbrand.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatecarbrand(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial					= $this->input->post('serial');
			$data = array(
				'car_brand'			=> $this->input->post('car_brand'),
				'status'			=> $this->input->post('status'),
				'last_updated_by'	=> $this->session->userdata('serial'),
				'last_updated_date'	=> date("Y-m-d H:i:s"),
			);

			$where = array(
				'serial'	=> $serial
			);

			$this->listvoucher->updatedata($where,$data,'vos_car_brand');
			redirect(base_url().'masterdata/listcarbrand');
		}
	}

	function detailcarbrand($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']		= $this->listmasterdata->showdetailcarbrand($id);
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/detailcarbrand.php";
			$this->load->view('layout/template',$data);
		}
	}
	###############################################################################################################################

	######################################################## VOS CAR MODEL ########################################################
	function listcarmodel(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$data['carmodel']			= $this->listmasterdata->showlistcarmodel();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "masterdata/listcarmodel.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertcarmodel(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial 				= get_serial('addcarmodel');
			$data 					= array (
												'serial'			=> $serial,
												'created_by'		=> $this->session->userdata('serial'),
												'car_brand_serial'	=> $this->input->post('car_brand_serial'),
												'car_model'			=> $this->input->post('car_model'),
												'car_code'			=> $this->input->post('car_code'),
												'car_year'			=> $this->input->post('car_year'),
												'status'			=> $this->input->post('status'),
											);
			$this->listvoucher->insertvoucher('vos_car_model',$data);
			redirect(base_url().'masterdata/listcarmodel');
		}
	}

	function addcarmodel(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['carbrand']		= $this->listquerytable->getcarbrandarray();
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/addcarmodel.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatecarmodel(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial					= $this->input->post('serial');
			$data = array(
				'car_brand_serial'	=> $this->input->post('car_brand_serial'),
				'car_model'			=> $this->input->post('car_model'),
				'car_code'			=> $this->input->post('car_code'),
				'car_year'			=> $this->input->post('car_year'),
				'status'			=> $this->input->post('status'),
				'last_updated_by'	=> $this->session->userdata('serial'),
				'last_updated_date'	=> date("Y-m-d H:i:s"),
			);

			$where = array(
				'serial'	=> $serial
			);

			$this->listvoucher->updatedata($where,$data,'vos_car_model');
			redirect(base_url().'masterdata/listcarmodel');
		}
	}

	function detailcarmodel($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']		= $this->listmasterdata->showdetailcarmodel($id);
			$data['carbrand']		= $this->listquerytable->getcarbrandarray();
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/detailcarmodel.php";
			$this->load->view('layout/template',$data);
		}
	}
	###############################################################################################################################

	######################################################## VOS CAR TYPE ########################################################
	function listcartype(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$data['cartype']			= $this->listmasterdata->showlistcartype();
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "masterdata/listcartype.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertcartype(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial 				= get_serial('addcartype');
			$data 					= array (
												'serial'		=> $serial,
												'created_by'	=> $this->session->userdata('serial'),
												'car_type'		=> $this->input->post('car_type'),
												'status'		=> '1',
											);
			$this->listvoucher->insertvoucher('vos_car_type',$data);
			redirect(base_url().'masterdata/listcartype');
		}
	}

	function addcartype(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/addcartype.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updatecartype(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial					= $this->input->post('serial');
			$data = array(
				'car_type'			=> $this->input->post('car_type'),
				'status'			=> $this->input->post('status'),
				'last_updated_by'	=> $this->session->userdata('serial'),
				'last_updated_date'	=> date("Y-m-d H:i:s"),
			);

			$where = array(
				'serial'	=> $serial
			);

			$this->listvoucher->updatedata($where,$data,'vos_car_type');
			redirect(base_url().'masterdata/listcartype');
		}
	}

	function detailcartype($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']		= $this->listmasterdata->showdetailcartype($id);
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/detailcartype.php";
			$this->load->view('layout/template',$data);
		}
	}
	###############################################################################################################################

	########################################################## VOS USERS ##########################################################
	function listusers(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$usertype				= $this->uri->segment('3');
			$data['users']			= $this->listmasterdata->showlistusers($usertype);
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/listusers.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertusers(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial 				= get_serial('addusers');
			$data 					= array (
												'serial'				=> $serial,
												'created_by'			=> $this->session->userdata('serial'),
												'user_id'				=> get_null_if_empty($this->input->post('user_id')),
												'full_name'				=> get_null_if_empty($this->input->post('full_name')),
												'password'				=> get_null_if_empty($this->input->post('password')),
												'main_dealer_serial'	=> get_null_if_empty($this->input->post('main_dealer_serial')),
												'dealer_serial'			=> get_null_if_empty($this->input->post('dealer_serial')),
												'company_serial'		=> get_null_if_empty($this->input->post('company_serial')),
												'address'				=> get_null_if_empty($this->input->post('address')),
												'city'					=> get_null_if_empty($this->input->post('city')),
												'state'					=> get_null_if_empty($this->input->post('state')),
												'zip'					=> get_null_if_empty($this->input->post('zip')),
												'country'				=> get_null_if_empty($this->input->post('country')),
												'office_phone'			=> get_null_if_empty($this->input->post('office_phone')),
												'office_phone_2'		=> get_null_if_empty($this->input->post('office_phone_2')),
												'fax_number'			=> get_null_if_empty($this->input->post('fax_number')),
												'fax_number_2'			=> get_null_if_empty($this->input->post('fax_number_2')),
												'email'					=> get_null_if_empty($this->input->post('email')),
												'contact_person'		=> get_null_if_empty($this->input->post('contact_person')),
												'level'					=> get_null_if_empty($this->input->post('level')),
												'division'				=> get_null_if_empty($this->input->post('division')),
												'user_type'				=> f_v_i_e($this->uri->segment('3'),$this->input->post('user_type')),
												'status'				=> f_v_i_e("1",$this->input->post('status')),
												'branch_company'		=> '10',
											);
			$this->listvoucher->insertvoucher('vos_users',$data);
			redirect(base_url().'masterdata/listusers/'.$this->input->post('user_type'));
		}
	}

	function addusers(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			if($this->uri->segment('3') == "7"){
				$prefixuserid		= "STFH/";
			} else if ($this->uri->segment('3') == "3"){
				$prefixuserid		= "MDLH/";
			} else if ($this->uri->segment('3') == "4"){
				$prefixuserid		= "SHWH/";
			} else if ($this->uri->segment('3') == "X"){
				$prefixuserid		= "DLRH/";
			}
			$data['prefixno']		= $this->listquerytable->getnextprefixno($prefixuserid,'vos_users','user_id');
			$data['companyserial']	= $this->listquerytable->getuserarray('4','full_name');
			$data['maindealer']		= $this->listquerytable->getuserarray('3','full_name');
			$data['dealer']			= $this->listquerytable->getuserarray('X','full_name');
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/addusers.php";
			$this->load->view('layout/template',$data);
		}
	}

	function updateusers(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$serial		= $this->input->post('serial');
			$data 		= array (
									'user_id'				=> get_null_if_empty($this->input->post('user_id')),
									'full_name'				=> get_null_if_empty($this->input->post('full_name')),
									'password'				=> get_null_if_empty($this->input->post('password')),
									'main_dealer_serial'	=> get_null_if_empty($this->input->post('main_dealer_serial')),
									'dealer_serial'			=> get_null_if_empty($this->input->post('dealer_serial')),
									'company_serial'		=> get_null_if_empty($this->input->post('company_serial')),
									'address'				=> get_null_if_empty($this->input->post('address')),
									'city'					=> get_null_if_empty($this->input->post('city')),
									'state'					=> get_null_if_empty($this->input->post('state')),
									'zip'					=> get_null_if_empty($this->input->post('zip')),
									'country'				=> get_null_if_empty($this->input->post('country')),
									'office_phone'			=> get_null_if_empty($this->input->post('office_phone')),
									'office_phone_2'		=> get_null_if_empty($this->input->post('office_phone_2')),
									'fax_number'			=> get_null_if_empty($this->input->post('fax_number')),
									'fax_number_2'			=> get_null_if_empty($this->input->post('fax_number_2')),
									'email'					=> get_null_if_empty($this->input->post('email')),
									'contact_person'		=> get_null_if_empty($this->input->post('contact_person')),
									'level'					=> get_null_if_empty($this->input->post('level')),
									'division'				=> get_null_if_empty($this->input->post('division')),
									'status'				=> f_v_i_e("1",$this->input->post('status')),
									'last_updated_by'		=> $this->session->userdata('serial'),
									'last_updated_date'		=> date("Y-m-d H:i:s"),
								);
			$where		= array ('serial'	=> $serial);
			$this->listvoucher->updatedata($where,$data,'vos_users');
			redirect(base_url().'masterdata/listusers/'.$this->input->post('user_type'));
		}
	}

	function detailusers(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$id						= $this->uri->segment('4');
			$data['voucher']		= $this->listmasterdata->showdetailusers($id);
			$data['companyserial']	= $this->listquerytable->getuserarray('4','full_name');
			$data['maindealer']		= $this->listquerytable->getuserarray('3','full_name');
			$data['dealer']			= $this->listquerytable->getuserarray('X','full_name');
			$data['title']			= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']		= "Membuat Website Sederhana";
			$data['description']	= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']		= "masterdata/detailusers.php";
			$this->load->view('layout/template',$data);
		}
	}
	###############################################################################################################################
}
