<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Notfound extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title'] = "Error 404";
			$data['subtitle'] = "Page Not Found";
			$data['description'] = "Page Not Found";
			$data['view_isi'] = "error404";
			$this->load->view('layout/template',$data);
		}
	}
}
