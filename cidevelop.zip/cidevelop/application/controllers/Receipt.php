<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Receipt extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvoucher');
		$this->load->model('listchassis');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$session = $this->session->userdata('login'); 
	}

	public function index()
	{
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']				= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']			= "Membuat Website Sederhana";
			$data['description']		= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']			= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}
}
