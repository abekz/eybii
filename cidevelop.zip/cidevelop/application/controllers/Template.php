<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Template extends CI_Controller {

	public function index()
	{
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title'] = "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle'] = "Membuat Website Sederhana";
			$data['description'] = "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi'] = "layout/showtemplate";
			$this->load->view('layout/template',$data);
		}
	}

	function adodbx(){
		$this->adodb->debug = 0;
		$data	= $this->adodb->GetAll("SELECT bank_name FROM bank");
		print_r($data);
		//$this->load->view(‘welcome_message’);
	}
}

