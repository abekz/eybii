<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Updatevoucher extends CI_Controller {

	function __construct(){
		parent::__construct();
		$this->load->model('listvkoolpusat');
		$this->load->model('listvoucher');
		$this->load->model('listquerytable');
		$this->load->helper(array('url'));
		$this->vkp 	= $this->load->database('vkoolpusat', TRUE);
		$session 	= $this->session->userdata('login'); 
	}

	public function index(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['title']					= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']				= "Membuat Website Sederhana";
			$data['description']			= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']				= "viewhome";
			$this->load->view('layout/template',$data);
		}
	}

	function listvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();

			$fieldsearch					= f_v_i_e("approval_status",$this->input->post('fieldsearch'));
			$stringvalue1					= f_v_i_e("2",$this->input->post('stringvalue1'));
			$stringvalue2					= f_v_i_e("",$this->input->post('stringvalue2'));
			//$orderdatefrom					= f_v_i_e(date("Y-m-d", strtotime("".date("Y-m-d")." -1 days")),$this->input->post('orderdatefrom'));
			$orderdatefrom					= f_v_i_e(date("Y-m-d"),$this->input->post('orderdatefrom'));
			$orderdateto					= f_v_i_e(date("Y-m-d"),$this->input->post('orderdateto'));

			/**
			$jumlah_data					= $this->listvoucher->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			$this->load->library('pagination');
			$config['base_url']				= base_url().'updatevoucher/listvoucher/';
			$config['total_rows']			= $jumlah_data;
			$config['per_page']				= 15;
			$from							= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']		= "<ul class='pagination'>";
			$config['full_tag_close']		= "</ul>";
			$config['num_tag_open']			= '<li>';
			$config['num_tag_close']		= '</li>';
			$config['cur_tag_open']			= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']		= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']		= "<li>";
			$config['next_tagl_close']		= "</li>";
			$config['prev_tag_open']		= "<li>";
			$config['prev_tagl_close']		= "</li>";
			$config['first_tag_open']		= "<li>";
			$config['first_tagl_close']		= "</li>";
			$config['last_tag_open']		= "<li>";
			$config['last_tagl_close']		= "</li>";

			$config['first_link']			= '< First Page ';
			$config['last_link']			= 'Last Page > ';
			$config['next_link']			= '> ';
			$config['prev_link']			= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']				= $jumlah_data;
			$data['voucher']				= $this->listvoucher->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			*/

			$data['postorderdatefrom']		= $orderdatefrom;
			$data['postorderdateto']		= $orderdateto;
			$data['voucher']				= $this->listvoucher->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			$data['dealervkool']			= $this->listquerytable->getuserarray('4','full_name');
			$data['carmodel']				= $this->listquerytable->getcarmodelarray();
			$data['cartype']				= $this->listquerytable->getcartypearray();
			$data['title']					= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']				= "Membuat Website Sederhana";
			$data['description']			= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']				= "updatevoucher/listvoucher.php";
			$this->load->view('layout/template',$data);
		}
	}

	function showresultsearchvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$this->load->database();
			$fieldsearch					= $_POST['fieldsearch'];
			$stringvalue1					= $_POST['stringvalue1'];
			$stringvalue2					= $_POST['stringvalue2'];
			$orderdatefrom					= $_POST['orderdatefrom'];
			$orderdateto					= $_POST['orderdateto'];

			/**
			$jumlah_data					= $this->listvoucher->jumlah_data($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			$this->load->library('pagination');
			$config['base_url']				= base_url().'updatevoucher/listvoucher/';
			$config['total_rows']			= $jumlah_data;
			$config['per_page']				= 30;
			$from							= $this->uri->segment(3);

			//Tambahan untuk styling
			$config['full_tag_open']		= "<ul class='pagination'>";
			$config['full_tag_close']		= "</ul>";
			$config['num_tag_open']			= '<li>';
			$config['num_tag_close']		= '</li>';
			$config['cur_tag_open']			= "<li class='disabled'><li class='active'><a href='#'>";
			$config['cur_tag_close']		= "<span class='sr-only'></span></a></li>";
			$config['next_tag_open']		= "<li>";
			$config['next_tagl_close']		= "</li>";
			$config['prev_tag_open']		= "<li>";
			$config['prev_tagl_close']		= "</li>";
			$config['first_tag_open']		= "<li>";
			$config['first_tagl_close']		= "</li>";
			$config['last_tag_open']		= "<li>";
			$config['last_tagl_close']		= "</li>";

			$config['first_link']			= '< First Page ';
			$config['last_link']			= 'Last Page > ';
			$config['next_link']			= '> ';
			$config['prev_link']			= '< ';

			$this->pagination->initialize($config);
			$data['totaldata']				= $jumlah_data;
			$data['resultquery']			= $this->listvoucher->showlistvoucher($config['per_page'],$from,$fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			*/

			$data['resultquery']			= $this->listvoucher->showlistvoucher($fieldsearch,$stringvalue1,$stringvalue2,$orderdatefrom,$orderdateto,'2');
			$this->load->view('updatevoucher/showresultsearch',$data);
		}
	}

	function detailvoucher($id){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			$data['voucher']				= $this->listvoucher->showdetailvoucher($id);
			$data['voucherdetail']			= $this->listvoucher->getdetaillist($id);
			$data['dealervkool']			= $this->listquerytable->getuserarray('4','full_name');
			$data['title']					= "..:: VOUCHER ONLINE SYSTEM ::..";
			$data['subtitle']				= "Membuat Website Sederhana";
			$data['description']			= "belajar itu harus dilakukan setiap hari. tanpa belajar maka tidak akan ada masa depan untuk diri mu dan orang lain.";
			$data['view_isi']				= "updatevoucher/detailvoucher.php";
			$this->load->view('layout/template',$data);
		}
	}

	function insertvoucher(){
		if($this->session->userdata('login') == FALSE){
			redirect(base_url().'login');
		} else {
			if($this->input->post('sales_order_no_car') == "" || $this->input->post('sales_order_no_car') == "null" || $this->input->post('sales_order_no_car') == NULL){
				$serialsobaru				= get_serial('addsalesordernocar');
			} else {
				$serialsobaru				= $this->input->post('sales_order_no_car') ;
			}
			if($this->input->post('sales_invoice_no_car') == "" || $this->input->post('sales_invoice_no_car') == "null" || $this->input->post('sales_invoice_no_car') == NULL){
				$serialsibaru				= get_serial('addsalesinvoicenocar');
			} else {
				$serialsibaru				= $this->input->post('sales_invoice_no_car') ;
			}
			if($this->input->post('customer_serial') == "" || $this->input->post('customer_serial') == "null" || $this->input->post('customer_serial') == NULL){
				$serialusers				= get_serial('addcustomer');
			} else {
				$serialusers				= $this->input->post('customer_serial') ;
			}
			$prefixusers					= $this->listquerytable->getnextprefixno("CUSH-".date("y")."/","users","user_id");
			######################################### START INFO ::: DELETE DETAIL SO DAN SI ########################################
			if($serialsobaru){
				$wheredetailso				= array ('sales_serial'			=> $serialsobaru);
				$this->listvoucher->deletedata($wheredetailso,'sales_detail');
			}
			if($serialsibaru){
				$wheredetailsi				= array ('sales_serial'			=> $serialsibaru);
				$this->listvoucher->deletedata($wheredetailsi,'sales_detail');
			}
			########################################## END INFO ::: DELETE DETAIL SO DAN SI #########################################
			######################################### START INFO ::: GANTI STATUS NO GARANSI ########################################
			if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
				if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
					$prefixwarranty			= "NV".format_date($this->input->post('tanggal_order_voucher'),"y").format_date($this->input->post('tanggal_order_voucher'),"m") ;
					$warrantyno				= $this->listquerytable->getwarrantyno($prefixwarranty);
					$voidwarranty			= array (
												'status'				=> '2',
												'last_updated_by'		=> $this->session->userdata('serial'),
												'last_updated_date'		=> date("Y-m-d H:i:s"),
											);
					$wherewarranty			= array ('warranty_card'	=> $warrantyno);
					$this->listvoucher->updatedata($wherewarranty,$voidwarranty,'warranty_card');
				}
			}
			########################################## END INFO ::: GANTI STATUS NO GARANSI #########################################
			############################################## START :: UPDATE DATA VOUCHER #############################################
			if($this->session->userdata('level') == "4"){
				if($this->input->post('tanggal_berlaku_warranty')){
					$tanggalberlakuwarranty = $this->input->post('tanggal_berlaku_warranty');
					$statuspasangvoucher 	= f_v_i_e("1",$this->input->post('status_pasang_voucher'));
				} else {
					$tanggalberlakuwarranty = $this->input->post('tanggal_berlaku_warranty');
					$statuspasangvoucher 	= f_v_i_e("2",$this->input->post('status_pasang_voucher'));
				}
			} else {
				$statuspasangvoucher 		= f_v_i_e("2",$this->input->post('status_pasang_voucher'));
			}
			$datavoucher					= array(
												'alamat_pemilik'			=> get_null_if_empty($this->input->post('alamat_pemilik')),
												'no_telepon'				=> get_null_if_empty($this->input->post('no_telepon')),
												'no_handphone'				=> get_null_if_empty($this->input->post('no_handphone')),
												'status_pasang_voucher'		=> get_null_if_empty($statuspasangvoucher),
												'tempat_pasang_voucher'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'tanggal_berlaku_warranty'	=> f_v_i_e($this->input->post('tanggal_pasang_voucher'),$this->input->post('tanggal_berlaku_warranty')),
												'tanggal_pasang_voucher'	=> f_v_i_e(date("Y-m-d"),f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher'))),
												'upload_garansi_vkool'		=> f_v_i_e("1",$this->input->post('upload_garansi_vkool')),
												'spk_has_updated'			=> f_v_i_e("1",$this->input->post('spk_has_updated')),
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'sales_order_no_car'		=> $serialsobaru,
												'sales_invoice_no_car'		=> $serialsibaru,
												'proses_voucher'			=> '1',
												'last_updated_by'			=> $this->session->userdata('serial'),
												'last_updated_date'			=> date("Y-m-d H:i:s"),
											);
			$wherevoucher 					= array('serial' => $this->input->post('serial'));
			$this->listvoucher->updatedata($wherevoucher,$datavoucher,'vos_voucher');
			############################################### END :: UPDATE DATA VOUCHER ##############################################
			################################################# START :: INSERT USERS #################################################
			if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
				$datausers					= array (
												'serial'					=> $serialusers,
												'created_by'				=> $this->session->userdata('serial'),
												'user_type'					=> '2',
												'status'					=> '1',
												'user_id'					=> $prefixusers,
												'full_name'					=> $this->input->post('nama_pemilik'),
												'address'					=> $this->input->post('alamat_pemilik'),
												'cell_phone'				=> $this->input->post('no_handphone'),
												'home_phone'				=> $this->input->post('no_telepon'),
											);
				$this->listvoucher->insertvoucher('users',$datausers);
			}
			################################################## END :: INSERT USERS ##################################################
			######################################### START :: UPDATE WARRANTY NO di SO & SI ########################################
			if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
				if($this->input->post('warranty_no')){
					$sowarranty				= array (
												'update_warranty_date'		=> $this->input->post('tanggal_order_voucher'),
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
											);
					$wheresowarranty		= array ('serial'				=> $serialsobaru);
					$this->listvoucher->updatedata($wheresowarranty,$sowarranty,'sales');

					$siwarranty				= array (
												'update_warranty_date'		=> $this->input->post('tanggal_order_voucher'),
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
											);
					$wheresiwarranty		= array ('serial'				=> $serialsibaru);
					$this->listvoucher->updatedata($wheresiwarranty,$siwarranty,'sales');
				}
			}
			########################################## END :: UPDATE WARRANTY NO di SO & SI #########################################
			############################################### START :: INSERT SO DETAIL ###############################################
			if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
				$prefixso					= $this->listquerytable->getnextprefixno("SODH-".date("y")."/","sales","sales_order_no_car");
				$prefixspk					= str_replace("SOD", "SPK", f_v_i_e($prefixso,$this->input->post('so_no')));
				$prefixsi					= str_replace("SOD", "SCD", f_v_i_e($prefixso,$this->input->post('so_no')));
			} else {
				$prefixluarkota				= $this->listquerytable->getfieldfromtable("vos_users","prefix_no","serial",$this->input->post('dealer_luarkota_serial'),"");
				$prefixlk					= "SOCHL".$prefixluarkota."-".date("y")."/";
				$prefixso					= $this->listquerytable->getnextprefixno($prefixlk,"sales","sales_order_no_car");
				$prefixspk					= str_replace("SOC", "SPK", f_v_i_e($prefixso,$this->input->post('so_no')));
				$prefixsi					= str_replace("SOC", "SCS", f_v_i_e($prefixso,$this->input->post('so_no')));
			}
			$totday							= date("t");
			/*
			if($this->input->post('sales_order_no_car')){
				$orderdate 					= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$installationdate			= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$duedate					= date("Y-m-d", strtotime("".$this->input->post('tanggal_terbit_voucher')." +".$totday." days"));
				$duedatetek					= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdate				= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
			} else {
				$orderdate 					= format_date($this->input->post('tanggal_order_voucher'),"Y-m-d");
				$installationdate			= format_date($this->input->post('tanggal_pasang_voucher'),"Y-m-d");
				$duedate					= date("Y-m-d", strtotime("".$this->input->post('tanggal_order_voucher')." +".$totday." days"));
				$duedatetek					= date("Y-m-d", strtotime("".$this->input->post('tanggal_order_voucher')." +".$totday." days"));
			}
			*/
			$pairingdate					= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
			$duedatevkp						= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
			$pairingdatevkp					= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
			$invname 						= "";
			for($d=0;$d<$this->input->post('num_loop_0');$d++){
				$serialdetail				= get_serial('adddetailhondavoucher');
				$serialtablegaransi			= get_serial('adddetailvkooldb');
				$kacafilmtipex				= $this->listquerytable->getfieldfromtable("inventory","inventory_name","serial",$this->input->post('inventory_serial_'.$d),"");
				if($kacafilmtipex == "V-KOOL BLACK LABEL (X5)"){
					$kacafilmtipe			= "V-KOOL X05";
				} else if($kacafilmtipex == "V-KOOL 15"){
					$kacafilmtipe			= "V-KOOL X15";
				} else if($kacafilmtipex == "V-KOOL GPS"){
					$kacafilmtipe			= "V-KOOL J60E";
				} else {
					$kacafilmtipe			= $kacafilmtipex ;
				}
				$datax[$d]					= array (
												'serial'					=> $serialdetail,
												'created_date'				=> date("Y-m-d H:i:s"),
												'created_by'				=> $this->session->userdata('serial'),
												'sales_serial'				=> $serialsobaru,
												'inventory_category'		=> '1',
												'item_group'				=> '1',
												'inventory_serial'			=> $this->input->post('inventory_serial_'.$d),
												'window_position' 			=> $this->input->post('window_position_'.$d),
												'window_position_detail' 	=> $this->input->post('window_position_detail_'.$d),
												'width'						=> NULL,
												'length_'					=> NULL,
												'qty'						=> '1',
												'price'						=> NULL,
												'discount'					=> NULL,
												'discount_type'				=> NULL,
												'total'						=> NULL,
												'hpp'						=> NULL,
												'price_list'				=> NULL,
												'status'					=> '1',
												'last_updated_by'			=> NULL,
												'last_updated_date'			=> NULL,
												'print_garansi'				=> '1',
											);
				$invname 					.= $this->listquerytable->getinventoryname($datax[$d]['inventory_serial']).",";
				$datavkp[$d]				= array (
												'serial'					=> $serialtablegaransi,
												'created_date'				=> date("Y-m-d H:i:s"),
												'garansi_code'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'car_brand'					=> 'HONDA',
												'car_type'					=> $this->input->post('txt_car_model'),
												'car_no_rangka'				=> strtoupper($this->input->post('chassis_no')),
												'car_no_mesin'				=> get_null_if_empty($this->input->post('machine_no')),
												'car_warna'					=> strtoupper($this->input->post('car_color')),
												'car_tahun'					=> f_v_i_e(date("Y"),$this->input->post('car_year')),
												'car_no_polisi'				=> strtoupper($this->input->post('police_no')),
												'kaca_film_brand'			=> 'V-KOOL',
												'kaca_film_tipe'			=> $kacafilmtipe,
												'kaca_film_posisi'			=> window_position($this->input->post('window_position_'.$d)),
												'poin_customer'				=> $this->input->post('poin_customer'),
												'poin_sales'				=> $this->input->post('poin_sales'),
												'master_roll'				=> $this->input->post('master_roll'),
												'note'						=> 'PAKET HONDA',
												'customer_nama'				=> strtoupper($this->input->post('nama_pemilik')),
												'customer_id'				=> $prefixusers,
												'customer_alamat'			=> strtoupper($this->input->post('alamat_pemilik')),
												'customer_kota'				=> f_v_i_e("JAKARTA",strtoupper($this->input->post('city'))),
												'customer_kodepos'			=> get_null_if_empty($this->input->post('zip')),
												'customer_email'			=> get_null_if_empty($this->input->post('email')),
												'customer_hp'				=> get_null_if_empty($this->input->post('no_handphone')),
												'sales_nama'				=> get_null_if_empty($this->input->post('sales_nama')),
												'sales_id'					=> get_null_if_empty($this->input->post('sales_id')),
												'sales_alamat'				=> get_null_if_empty($this->input->post('sales_alamat')),
												'sales_kota'				=> get_null_if_empty($this->input->post('sales_kota')),
												'sales_kodepos'				=> get_null_if_empty($this->input->post('sales_kodepos')),
												'sales_email'				=> get_null_if_empty($this->input->post('sales_email')),
												'sales_hp'					=> get_null_if_empty($this->input->post('sales_hp')),
												'invoice'					=> f_v_i_e($prefixso,$this->input->post('so_no')),
												'showroom_nama'				=> get_null_if_empty($this->input->post('txt_showroom_serial')),
												'showroom_alamat'			=> get_null_if_empty($this->input->post('showroom_alamat')),
												'showroom_kota'				=> get_null_if_empty($this->input->post('showroom_kota')),
												'showroom_kodepos'			=> get_null_if_empty($this->input->post('showroom_kodepos')),
												'showroom_telp'				=> get_null_if_empty($this->input->post('showroom_telp')),
												'showroom_pic'				=> get_null_if_empty($this->input->post('showroom_pic')),
												'tgl_pasang'				=> $pairingdatevkp,
												'tgl_expired'				=> $duedatevkp,
												'teknisi'					=> get_null_if_empty($this->input->post('teknisi')),
												'no_garansi_scs'			=> get_null_if_empty($this->input->post('no_garansi_scs')),
												'status'					=> 'ACTIVE AND SHOW',
												'tipe_garansi'				=> 'AUTOMOTIVE',
												'posisi_detail'				=> window_position_detail($this->input->post('window_position_'.$d),$this->input->post('window_position_detail_'.$d)),
												'prefix_depo'				=> prefixdepopemasangan($this->input->post('prefix_depo_pemasangan')),
											);
			}
			$this->listvoucher->insertvoucherdetail('sales_detail',$datax);
			if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
				$this->listvkoolpusat->insertvoucherdetail('tabel_garansi',$datavkp);
			}
			############################################### END :: INSERT SO DETAIL ###############################################
			############################################## START :: INSERT SO HEADER ##############################################
			$windowfilmdesc 				= substr($invname, 0, -1);
			if($this->input->post('pajak_company_serial') == "02.417.173.8-048.000"){
				if(!(strpos($windowfilmdesc,'RX')===false)) {
					$installationcategory1 	= "958e7a6b0c045480dbc67f63059d761b";
				} else {
					$installationcategory1 	= "f9ef3d29aebe37f053c45a7464597350";
				}
				$dealerluarkotaserial		= NULL ;
				if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a" || $this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6"){
					$totalbonus				= "205000";
				} else {
					if(!(strpos($windowfilmdesc,'RX')===false)) {
						$totalbonus			= "130000";
					} else {
						$totalbonus			= "155000";
					}
				}
				$locationtype 				= "1";
			} else if($this->input->post('pajak_company_serial') == "2"){
				$installationcategory1 		= "58f8818d89fafed83578e672331142a2";
				$dealerluarkotaserial 		= $this->input->post('dealer_luarkota_serial');
				$totalbonus 				= "336000";
				$locationtype 				= "2";
			} else {
				$installationcategory1 		= "47aa83eb925785efeed5ffd970e5b49a";
				$dealerluarkotaserial 		= $this->input->post('dealer_luarkota_serial');
				$totalbonus 				= "343636";
				$locationtype 				= "2";
			}
			if($this->session->userdata('serial') == "88454f287b522e4e544a15cb128b5e1f" || $this->session->userdata('serial') == "7660ece408abdd12865d6643a92b515f" || $this->session->userdata('serial') == "d2e0deec743014a2d711c25f9c690e3a" || $this->session->userdata('serial') == "95fab6beca69be1626dfa21efa1f594f" || $this->session->userdata('serial') == "dddedb7906c2f85efa79563ee030f676" || $this->session->userdata('serial') == "036eb96c9a143d6f35d3c256b8e998d8"){
				$updatecounterby			= $this->session->userdata('serial');
				$updatecounterdate			= date("Y-m-d H:i:s");
			} else {
				$updatecounterby			= NULL;
				$updatecounterdate			= NULL;
			}
			if($this->input->post('sales_order_no_car') == "" || $this->input->post('sales_order_no_car') == "null" || $this->input->post('sales_order_no_car') == NULL){
				$orderdatex					= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$installationdatex			= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$duedatex					= date("Y-m-d", strtotime("".$this->input->post('tanggal_terbit_voucher')." +".$totday." days"));
				$duedatetekx				= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdatex				= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
				$datasobaru					= array (
												'serial'					=> $serialsobaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_order_no_car'		=> f_v_i_e($prefixso,$this->input->post('so_no')),
												'spk_no'					=> $prefixspk,
												'sales_type'				=> '1',
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'status'					=> '1',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'PAKET VOUCHER',
												'order_date'				=> $orderdatex,
												'installation_date'			=> $installationdatex,
												'due_date'					=> $duedatex,
												'pairing_date'				=> $pairingdatex,
												'total_bonus'				=> $totalbonus,
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'last_updated_by_counter'	=> get_null_if_empty($updatecounterby),
												'last_updated_date_counter'	=> get_null_if_empty($updatecounterdate),
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'bill_to_type_1'			=> '4',
												'bill_to_serial_1'			=> f_v_i_e('5ba04e80f70754ec3eceae61a29e8268',$this->input->post('bill_to_serial_1')),
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
											);
				$this->listvoucher->insertvoucher('sales',$datasobaru);
				if($this->input->post('pajak_company_serial') == "02.417.173.8-048.000"){
					$datasotracking			= array (
												'serial'					=> $serialsobaru,
												'created_by'				=> $this->session->userdata('serial'),
												'created_date'				=> date("Y-m-d H:i:s"),
												'sales_serial'				=> $serialsobaru,
												'waktu_update_counter'		=> date("Y-m-d H:i:s"),
												'waktu_dibuat_oleh'			=> $this->input->post('approval_date'),
												'waktu_approval_data'		=> $this->input->post('approval_date'),
											);
					$this->listvoucher->insertvoucher('sales_tracking',$datasotracking);
				}
			} else {
				$orderdatex					= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$installationdatex			= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$duedatex					= date("Y-m-d", strtotime("".$this->input->post('tanggal_terbit_voucher')." +".$totday." days"));
				$duedatetekx				= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdatex				= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));
				$dataupdateso				= array (
												'last_updated_by'			=> $this->session->userdata('serial'),
												'sales_order_no_car'		=> f_v_i_e($prefixso,$this->input->post('so_no')),
												'spk_no'					=> $prefixspk,
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'sales_type'				=> '1',
												'status'					=> '1',
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'PAKET VOUCHER',

												'order_date'				=> $orderdatex,
												'installation_date'			=> $installationdatex,
												'due_date'					=> $duedatex,
												'pairing_date'				=> $pairingdatex,

												'total_bonus'				=> $totalbonus,
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'last_updated_by_counter'	=> get_null_if_empty($updatecounterby),
												'last_updated_date_counter'	=> get_null_if_empty($updatecounterdate),
												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'bill_to_type_1'			=> '4',
												'bill_to_serial_1'			=> f_v_i_e('5ba04e80f70754ec3eceae61a29e8268',$this->input->post('bill_to_serial_1')),
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
											);
				$wheresoupdate				= array ('serial'				=> $serialsobaru);
				$this->listvoucher->updatedata($wheresoupdate,$dataupdateso,'sales');
				if($this->input->post('pajak_company_serial') == "02.417.173.8-048.000"){
					if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
						$datasotracking		= array ('waktu_update_counter'	=> date("Y-m-d H:i:s"),);
						$wheresotracking	= array ('serial'				=> $serialsobaru);
						$this->listvoucher->updatedata($wheresotracking,$datasotracking,'sales_tracking');
					}
					if($this->input->post('status_pasang_voucher') == "2"){
						$datasotracking		= array ('status_pasang'		=> '2',);
						$wheresotracking	= array ('serial'				=> $serialsobaru);
						$this->listvoucher->updatedata($wheresotracking,$datasotracking,'sales_tracking');
					}
				}
			}
			################################################ END :: INSERT SO HEADER ################################################
			############################################### START :: INSERT SI DETAIL ###############################################
			for($dsi=0;$dsi<$this->input->post('num_loop_0');$dsi++){
				$serialsidetail				= get_serial('adddetailhondavoucher');
				if($dsi == "0"){
					if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524" || $this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
						$inventory_serial 	= f_v_i_e("c949e16e7231f4718ab4e819606ec2de",$this->input->post('inventory_serial_'.$dsi));
					} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633" || $this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392" || $this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6" || $this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8" || $this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7" || $this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a"){
						$inventoryserial 	= f_v_i_e("d55324f54719c06b83ddb73bb2e22931",$this->input->post('inventory_serial_'.$dsi));
					} else {
						$inventoryserial 	= f_v_i_e("a972a4c217c47249527404d002b4259a",$this->input->post('inventory_serial_'.$dsi));
					}
					if($this->input->post('window_position_detail_'.$dsi) == "1"){
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "1916755" ;
							$total		= "1916755" ;
							$price_list	= "1916755" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "1916755" ;
							$total		= "1916755" ;
							$price_list	= "1916755" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1842446" ;
							$total		= "1842446" ;
							$price_list	= "1842446" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "1811839" ;
							$total		= "1811839" ;
							$price_list	= "1811839" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "1908465" ;
							$total		= "1908465" ;
							$price_list	= "1908465" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
							$price		= "2088550" ;
							$total		= "2088550" ;
							$price_list	= "2088550" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "2059577" ;
							$total		= "2059577" ;
							$price_list	= "2059577" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1804473" ;
							$total		= "1804473" ;
							$price_list	= "1804473" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "2026022" ;
							$total		= "2026022" ;
							$price_list	= "2026022" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "2026022" ;
							$total		= "2026022" ;
							$price_list	= "2026022" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1842446" ;
							$total		= "1842446" ;
							$price_list	= "1842446" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "1852264" ;
							$total		= "1852264" ;
							$price_list	= "1852264" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "2231505" ;
							$total		= "2231505" ;
							$price_list	= "2231505" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "2215168" ;
							$total		= "2215168" ;
							$price_list	= "2215168" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "2421184" ;
							$total		= "2421184" ;
							$price_list	= "2421184" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "2158778" ;
							$total		= "2158778" ;
							$price_list	= "2158778" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "2096883" ;
							$total		= "2096883" ;
							$price_list	= "2096883" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "2115107" ;
							$total		= "2115107" ;
							$price_list	= "2115107" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "2050781" ;
							$total		= "2050781" ;
							$price_list	= "2050781" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "2200969" ;
							$total		= "2200969" ;
							$price_list	= "2200969" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "2403800" ;
							$total		= "2403800" ;
							$price_list	= "2403800" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "2430000" ;
							$total		= "2430000" ;
							$price_list	= "2430000" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "2644894" ;
							$total		= "2644894" ;
							$price_list	= "2644894" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "2377465" ;
							$total		= "2377465" ;
							$price_list	= "2377465" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "2332394" ;
							$total		= "2332394" ;
							$price_list	= "2332394" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "2335165" ;
							$total		= "2335165" ;
							$price_list	= "2335165" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "2327352" ;
							$total		= "2327352" ;
							$price_list	= "2327352" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "1680480" ;
							$total		= "1680480" ;
							$price_list	= "1680480" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "1609938" ;
							$total		= "1609938" ;
							$price_list	= "1609938" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "1443303" ;
							$total		= "1443303" ;
							$price_list	= "1443303" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "1592677" ;
							$total		= "1592677" ;
							$price_list	= "1592677" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "1536517" ;
							$total		= "1536517" ;
							$price_list	= "1536517" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "1643920" ;
							$total		= "1643920" ;
							$price_list	= "1643920" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "1772790" ;
							$total		= "1772790" ;
							$price_list	= "1772790" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "1680480" ;
							$total		= "1680480" ;
							$price_list	= "1680480" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "1592677" ;
							$total		= "1592677" ;
							$price_list	= "1592677" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "2286315" ;
							$total		= "2286315" ;
							$price_list	= "2286315" ;
						}
					}
				} else if($dsi == "1"){
					if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524" || $this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
						$inventoryserial	= f_v_i_e("ee4c12ff2fa69dac1fd060902f3e8495",$this->input->post('inventory_serial_'.$dsi)) ;
					} else {
						$inventoryserial	= f_v_i_e("e0a5fb955e9ceee0bdca4d41958c24c9",$this->input->post('inventory_serial_'.$dsi)) ;
					}
					if($this->input->post('window_position_detail_'.$dsi) == "1"){
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "1723754" ;
							$total		= "1723754" ;
							$price_list	= "1723754" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "1723754" ;
							$total		= "1723754" ;
							$price_list	= "1723754" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1737695" ;
							$total		= "1737695" ;
							$price_list	= "1737695" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "1058668" ;
							$total		= "1058668" ;
							$price_list	= "1058668" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "1504233" ;
							$total		= "1504233" ;
							$price_list	= "1504233" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
							$price		= "1762478" ;
							$total		= "1762478" ;
							$price_list	= "1762478" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "1718011" ;
							$total		= "1718011" ;
							$price_list	= "1718011" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1472196" ;
							$total		= "1472196" ;
							$price_list	= "1472196" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "2235757" ;
							$total		= "2235757" ;
							$price_list	= "2235757" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "2235757" ;
							$total		= "2235757" ;
							$price_list	= "2235757" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1737695" ;
							$total		= "1737695" ;
							$price_list	= "1737695" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "1512740" ;
							$total		= "1512740" ;
							$price_list	= "1512740" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "1140173" ;
							$total		= "1140173" ;
							$price_list	= "1140173" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "1975396" ;
							$total		= "1975396" ;
							$price_list	= "1975396" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "2704000" ;
							$total		= "2704000" ;
							$price_list	= "2704000" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "2035206" ;
							$total		= "2035206" ;
							$price_list	= "2035206" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "1753123" ;
							$total		= "1753123" ;
							$price_list	= "1753123" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "1670886" ;
							$total		= "1670886" ;
							$price_list	= "1670886" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "1750000" ;
							$total		= "1750000" ;
							$price_list	= "1750000" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "1547215" ;
							$total		= "1547215" ;
							$price_list	= "1547215" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "1278385" ;
							$total		= "1278385" ;
							$price_list	= "1278385" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "2104898" ;
							$total		= "2104898" ;
							$price_list	= "2104898" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "2819716" ;
							$total		= "2819716" ;
							$price_list	= "2819716" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "2163380" ;
							$total		= "2163380" ;
							$price_list	= "2163380" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "1904225" ;
							$total		= "1904225" ;
							$price_list	= "1904225" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "1928571" ;
							$total		= "1928571" ;
							$price_list	= "1928571" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "1810162" ;
							$total		= "1810162" ;
							$price_list	= "1810162" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "1286557" ;
							$total		= "1286557" ;
							$price_list	= "1286557" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "1412422" ;
							$total		= "1412422" ;
							$price_list	= "1412422" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "1228211" ;
							$total		= "1228211" ;
							$price_list	= "1228211" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "1658792" ;
							$total		= "1658792" ;
							$price_list	= "1658792" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "1330090" ;
							$total		= "1330090" ;
							$price_list	= "1330090" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "1416650" ;
							$total		= "1416650" ;
							$price_list	= "1416650" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "2006190" ;
							$total		= "2006190" ;
							$price_list	= "2006190" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "1286557" ;
							$total		= "1286557" ;
							$price_list	= "1286557" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "1658792" ;
							$total		= "1658792" ;
							$price_list	= "1658792" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "1647414" ;
							$total		= "1647414" ;
							$price_list	= "1647414" ;
						}
					}
				} else if($dsi == "2"){
					if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90" || $this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0" || $this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f" || $this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146" || $this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e" || $this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524"){
						$inventoryserial	= f_v_i_e("ee4c12ff2fa69dac1fd060902f3e8495",$this->input->post('inventory_serial_'.$dsi)) ;
					} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb" || $this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848"){
						$inventoryserial	= f_v_i_e("ee4c12ff2fa69dac1fd060902f3e8495",$this->input->post('inventory_serial_'.$dsi)) ;
					} else {
						$inventoryserial	= f_v_i_e("0f19ae1e7e383e39cdde0bda6c44d527",$this->input->post('inventory_serial_'.$dsi)) ;
					}
					if($this->input->post('window_position_detail_'.$dsi) == "1"){
						if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
							$price		= "859491" ;
							$total		= "859491" ;
							$price_list	= "859491" ;
						} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
							$price		= "859491" ;
							$total		= "859491" ;
							$price_list	= "859491" ;
						} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
							$price		= "1019859" ;
							$total		= "1019859" ;
							$price_list	= "1019859" ;
						} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
							$price		= "879493" ;
							$total		= "879493" ;
							$price_list	= "879493" ;
						} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
							$price		= "787302" ;
							$total		= "787302" ;
							$price_list	= "787302" ;
						} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV ##
							$price		= "648972" ;
							$total		= "648972" ;
							$price_list	= "648972" ;
						} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
							$price		= "872412" ;
							$total		= "872412" ;
							$price_list	= "872412" ;
						} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71" || $this->input->post('car_model_serial') == "92813ca5b2fa1de5c1e6d54f3688162b"){ ## ALL NEW CIVIC ##
							$price		= "1023331" ;
							$total		= "1023331" ;
							$price_list	= "1023331" ;
						} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") {
							$price		= "788221" ;
							$total		= "788221" ;
							$price_list	= "788221" ;
						} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") {
							$price		= "788221" ;
							$total		= "788221" ;
							$price_list	= "788221" ;
						} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") {
							$price		= "1019859" ;
							$total		= "1019859" ;
							$price_list	= "1019859" ;
						} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") {
							$price		= "684996" ;
							$total		= "684996" ;
							$price_list	= "684996" ;
						} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CR-Z 2015
							$price		= "778322" ;
							$total		= "778322" ;
							$price_list	= "778322" ;
						} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015
							$price		= "709436" ;
							$total		= "709436" ;
							$price_list	= "709436" ;
						} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015
							$price		= "724816" ;
							$total		= "724816" ;
							$price_list	= "724816" ;
						} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015
							$price		= "906016" ;
							$total		= "906016" ;
							$price_list	= "906016" ;
						} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015
							$price		= "799994" ;
							$total		= "799994" ;
							$price_list	= "799994" ;
						} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015
							$price		= "914007" ;
							$total		= "914007" ;
							$price_list	= "914007" ;
						} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BR-V 2016
							$price		= "749219" ;
							$total		= "749219" ;
							$price_list	= "749219" ;
						} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HR-V 2016
							$price		= "751816" ;
							$total		= "751816" ;
							$price_list	= "751816" ;
						} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CR-Z 2016
							$price		= "917815" ;
							$total		= "917815" ;
							$price_list	= "917815" ;
						} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016
							$price		= "865102" ;
							$total		= "865102" ;
							$price_list	= "865102" ;
						} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016
							$price		= "885390" ;
							$total		= "885390" ;
							$price_list	= "885390" ;
						} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016
							$price		= "1059155" ;
							$total		= "1059155" ;
							$price_list	= "1059155" ;
						} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016
							$price		= "963381" ;
							$total		= "963381" ;
							$price_list	= "963381" ;
						} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CR-V 2016
							$price		= "736264" ;
							$total		= "736264" ;
							$price_list	= "736264" ;
						} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016
							$price		= "1062486" ;
							$total		= "1062486" ;
							$price_list	= "1062486" ;
						} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017
							$price		= "832963" ;
							$total		= "832963" ;
							$price_list	= "832963" ;
						} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017
							$price		= "577640" ;
							$total		= "577640" ;
							$price_list	= "577640" ;
						} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017
							$price		= "568486" ;
							$total		= "568486" ;
							$price_list	= "568486" ;
						} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017
							$price		= "668531" ;
							$total		= "668531" ;
							$price_list	= "668531" ;
						} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017
							$price		= "743393" ;
							$total		= "743393" ;
							$price_list	= "743393" ;
						} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017
							$price		= "889430" ;
							$total		= "889430" ;
							$price_list	= "889430" ;
						} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017
							$price		= "691020" ;
							$total		= "691020" ;
							$price_list	= "691020" ;
						} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017
							$price		= "832963" ;
							$total		= "832963" ;
							$price_list	= "832963" ;
						} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017
							$price		= "668531" ;
							$total		= "668531" ;
							$price_list	= "668531" ;
						} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R
							$price		= "966271" ;
							$total		= "966271" ;
							$price_list	= "966271" ;
						}
					}
				}
				$datadsidetail[$dsi]		= array	(
														'serial'					=> $serialsidetail,
														'created_date'				=> date("Y-m-d H:i:s"),
														'created_by'				=> $this->session->userdata('serial'),
														'sales_serial'				=> $serialsibaru,
														'inventory_category'		=> '1',
														'item_group'				=> '1',
														'inventory_serial'			=> f_v_i_e($this->input->post('inventory_serial_'.$dsi),$inventoryserial),
														'window_position' 			=> $this->input->post('window_position_'.$dsi),
														'window_position_detail' 	=> $this->input->post('window_position_detail_'.$dsi),
														'qty'						=> '1',
														'status'					=> '1',
														'print_garansi'				=> '1',
														'price'						=> $price,
														'total'						=> $total,
														'price_list'				=> $price_list,
													);
			}
			$this->listvoucher->insertvoucherdetail('sales_detail',$datadsidetail);
			################################################ END :: INSERT SI DETAIL ################################################
			############################################### START :: INSERT SI HEADER ###############################################
			if($this->input->post('sales_invoice_no_car') == "" || $this->input->post('sales_invoice_no_car') == "null" || $this->input->post('sales_invoice_no_car') == NULL){
				$bill_to_type_1				= "4";
				$bill_to_serial_1			= f_v_i_e("5ba04e80f70754ec3eceae61a29e8268",$this->input->post('bill_to_serial_1'));
				$used_price_type			= "2";
				$nett_price_serial			= "dde0d8cd479ca622855d4a5aca47172c";
				$pay_commission_to_type		= NULL;
				$pay_commission_to_serial	= NULL;
				$commission					= "0";
				$commission_type			= "2";
				$total_commission			= "0";
				$discount					= "0";
				$discount_type				= "1";
				$freight					= "0";
				$ppn						= "0";
				$down_payment				= "0";
				$total_price_list			= "0";
				$total_hpp					= "0";
				$other						= "150000";
				$other_2					= "150000";
				$other_desc					= "SUBSIDI HPM";
				$other_desc_2				= "SUBSIDI PROMOSI";
				$ppn_other					= "10";
				if($_POST['car_model_serial'] == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
					$sub_total				= "4500000";
					$dpp_material			= "4300000";
					$amount_1				= "4675000";
					$balance				= "4675000";
					$total					= "4675000";
					$total_price_nett		= "4675000";
				} else if($_POST['car_model_serial'] == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##
					$dpp_material			= "4300000";
					$sub_total				= "4500000";
					$amount_1				= "4675000";
					$balance				= "4675000";
					$total					= "4675000";
					$total_price_nett		= "4675000";
				} else if($_POST['car_model_serial'] == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##
					$amount_1				= "3850000";
					$dpp_material			= "3550000";
					$sub_total				= "3750000";
					$balance				= "3850000";
					$total					= "3850000";
					$total_price_nett		= "3850000";
				} else if($_POST['car_model_serial'] == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##
					$dpp_material			= "4400000";
					$sub_total				= "4600000";
					$amount_1				= "4785000";
					$balance				= "4785000";
					$total					= "4785000";
					$total_price_nett		= "4785000";
				} else if($_POST['car_model_serial'] == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##
					$dpp_material			= "4000000";
					$sub_total				= "4200000";
					$amount_1				= "4345000";
					$balance				= "4345000";
					$total					= "4345000";
					$total_price_nett		= "4345000";
				} else if($_POST['car_model_serial'] == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##
					$dpp_material			= "4300000";
					$sub_total				= "4500000";
					$amount_1				= "4620000";
					$balance				= "4620000";
					$total					= "4620000";
					$total_price_nett		= "4200000";
				} else if($_POST['car_model_serial'] == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##
					$dpp_material			= "4450000";
					$sub_total				= "4650000";
					$amount_1				= "4840000";
					$balance				= "4840000";
					$total					= "4840000";
					$total_price_nett		= "4840000";
				} else if($_POST['car_model_serial'] == "2c30d759c6f390344de6e5f7d681cb71"){ ## ALL NEW CIVIC ##
					$dpp_material			= "4100000";
					$sub_total				= "4300000";
					$amount_1				= "4455000";
					$balance				= "4455000";
					$total					= "4455000";
					$total_price_nett		= "4455000";
				} else if($_POST['car_model_serial'] == "64448c77b37debe50be9cf810f92dc4a") { ## ODYSSEY 2010 ##
					$amount_1				= "5280000";
					$dpp_material			= "4850000";
					$sub_total				= "5050000";
					$balance				= "5280000";
					$total					= "5280000";
					$total_price_nett		= "5280000";
				} else if($_POST['car_model_serial'] == "3496aa3e3762f62043aa8692c6c9bef6") { ## ODYSSEY 2014 ##
					$amount_1				= "5280000";
					$dpp_material			= "4850000";
					$sub_total				= "5050000";
					$balance				= "5280000";
					$total					= "5280000";
					$total_price_nett		= "5280000";
				} else if($_POST['car_model_serial'] == "be9014f91589840220549316954ec138") { ## HRV 2015 ##
					$amount_1				= "4050000";
					$dpp_material			= "3925000";
					$sub_total				= "4125000";
					$balance				= "4125000";
					$total					= "4125000";
					$total_price_nett		= "3750000";
				} else if($_POST['car_model_serial'] == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015 ##
					$amount_1				= "4840000";
					$dpp_material			= "4500000";
					$sub_total				= "4700000";
					$balance				= "4700000";
					$total					= "4700000";
					$total_price_nett		= "4400000";
				} else if($_POST['car_model_serial'] == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015 ##
					$amount_1				= "4785000";
					$dpp_material			= "4450000";
					$sub_total				= "4650000";
					$balance				= "4785000";
					$total					= "4785000";
					$total_price_nett		= "4350000";
				} else if($_POST['car_model_serial'] == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015 ##
					$amount_1				= "5280000";
					$dpp_material			= "4900000";
					$sub_total				= "5100000";
					$balance				= "5280000";
					$total					= "5280000";
					$total_price_nett		= "4800000";
				} else if($_POST['car_model_serial'] == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015 ##
					$amount_1				= "6105000";
					$dpp_material			= "5650000";
					$sub_total				= "5850000";
					$balance				= "6105000";
					$total					= "6105000";
					$total_price_nett		= "5550000";
				} else if($_POST['car_model_serial'] == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015 ##
					$amount_1				= "5060000";
					$dpp_material			= "4700000";
					$sub_total				= "4900000";
					$balance				= "5060000";
					$total					= "5060000";
					$total_price_nett		= "4600000";
				} else if($_POST['car_model_serial'] == "36acdd702c319f4b632d49d33ccd2977") { ## CRZ 2015 ##
					$amount_1				= "4235000";
					$dpp_material			= "3950000";
					$sub_total				= "4150000";
					$balance				= "4235000";
					$total					= "4235000";
					$total_price_nett		= "3850000";
				} else if($_POST['car_model_serial'] == "512076efc637f9704b05257fb17cabd7") { ## NEW ACCORD 2011 ##
					$dpp_material			= "4400000";
					$sub_total				= "4600000";
					$amount_1				= "4785000";
					$balance				= "4785000";
					$total					= "4785000";
					$total_price_nett		= "4785000";
				} else if($_POST['car_model_serial'] == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HRV 2016 ##
					$dpp_material			= "4300000";
					$sub_total				= "4500000";
					$amount_1				= "4620000";
					$balance				= "4620000";
					$total					= "4620000";
					$total_price_nett		= "4200000";
				} else if($_POST['car_model_serial'] == "19379113f9e4f562ba60ecfe5223538d") { ## BRV 2016 ##
					$dpp_material			= "4350000";
					$sub_total				= "4550000";
					$amount_1				= "4675000";
					$balance				= "4675000";
					$total					= "4675000";
					$total_price_nett		= "4250000";
				} else if($_POST['car_model_serial'] == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016 ##
					$dpp_material			= "5000000";
					$sub_total				= "5200000";
					$amount_1				= "5390000";
					$balance				= "5390000";
					$total					= "5390000";
					$total_price_nett		= "4900000";
				} else if($_POST['car_model_serial'] == "4c0420adb0b9a152c748d1ebfb097118") { ## CRV 2016 ##
					$dpp_material			= "4800000";
					$sub_total				= "5000000";
					$amount_1				= "5170000";
					$balance				= "5170000";
					$total					= "5170000";
					$total_price_nett		= "4700000";
				} else if($_POST['car_model_serial'] == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016 ##
					$dpp_material			= "5000000";
					$sub_total				= "5200000";
					$amount_1				= "5390000";
					$balance				= "5390000";
					$total					= "5390000";
					$total_price_nett		= "4900000";
				} else if($_POST['car_model_serial'] == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016 ##
					$dpp_material			= "5400000";
					$sub_total				= "5600000";
					$amount_1				= "5830000";
					$balance				= "5830000";
					$total					= "5830000";
					$total_price_nett		= "5830000";
				} else if($_POST['car_model_serial'] == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016 ##
					$dpp_material			= "6150000";
					$sub_total				= "6350000";
					$amount_1				= "6655000";
					$balance				= "6655000";
					$total					= "6655000";
					$total_price_nett		= "6050000";
				} else if($_POST['car_model_serial'] == "f465040cb37375ed513263b596613bb7") { ## FREED 2016 ##
					$dpp_material			= "5200000";
					$sub_total				= "5400000";
					$amount_1				= "5610000";
					$balance				= "5610000";
					$total					= "5610000";
					$total_price_nett		= "5100000";
				} else if($_POST['car_model_serial'] == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CRZ 2016 ##
					$dpp_material			= "4400000";
					$sub_total				= "4600000";
					$amount_1				= "4730000";
					$balance				= "4730000";
					$total					= "4730000";
					$total_price_nett		= "4300000";
				} else if($_POST['car_model_serial'] == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017 ##
					$dpp_material			= "3600000";
					$sub_total				= "3800000";
					$amount_1				= "3850000";
					$balance				= "3850000";
					$total					= "3850000";
					$total_price_nett		= "3850000";
				} else if($_POST['car_model_serial'] == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017 ##
					$dpp_material			= "3400000";
					$sub_total				= "3600000";
					$amount_1				= "3630000";
					$balance				= "3630000";
					$total					= "3630000";
					$total_price_nett		= "3630000";
				} else if($_POST['car_model_serial'] == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017 ##
					$dpp_material			= "3040000";
					$sub_total				= "3240000";
					$amount_1				= "3234000";
					$balance				= "3234000";
					$total					= "3234000";
					$total_price_nett		= "3234000";
				} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017 ##
					$dpp_material			= "3720000";
					$sub_total				= "3920000";
					$amount_1				= "4312000";
					$balance				= "4312000";
					$total					= "4312000";
					$total_price_nett		= "4312000";
				}
				if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
					$sistatus				= "2";
				} else {
					$sistatus				= "1";
				}

				$orderdatexsi				= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$installationdatexsi		= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$duedatexsi					= date("Y-m-d", strtotime("".$this->input->post('tanggal_terbit_voucher')." +".$totday." days"));
				$duedatetekxsi				= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdatexsi				= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));

				$datasibaru					= array (
												'serial'					=> $serialsibaru,
												'created_by'				=> $this->session->userdata('serial'),
												'sales_invoice_no_car'		=> $prefixsi,
												'sales_order_no'			=> $serialsobaru,
												'sales_type'				=> '2',
												'status'					=> $sistatus,
												'spk_has_returned'			=> '2',
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '0',
												'paid_status_amount_2'		=> '0',
												'paid_status_amount_3'		=> '0',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'PAKET HONDA',
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'total_bonus'				=> $totalbonus,

												'order_date'				=> $orderdatexsi,
												'installation_date'			=> $installationdatexsi,
												'due_date'					=> $duedatexsi,
												'pairing_date'				=> $pairingdatexsi,

												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'installation_category_1'	=> '47aa83eb925785efeed5ffd970e5b49a',
												'bill_to_type_1'			=> $bill_to_type_1 ,
												'bill_to_serial_1'			=> f_v_i_e($bill_to_serial_1,$this->input->post('bill_to_serial_1')) ,
												'used_price_type'			=> $used_price_type ,
												'nett_price_serial'			=> $nett_price_serial ,
												'pay_commission_to_type'	=> $pay_commission_to_type ,
												'pay_commission_to_serial'	=> $pay_commission_to_serial ,
												'commission'				=> $commission ,
												'commission_type'			=> $commission_type ,
												'total_commission'			=> $total_commission ,
												'discount'					=> $discount ,
												'discount_type'				=> $discount_type ,
												'freight'					=> $freight ,
												'ppn'						=> $ppn ,
												'down_payment'				=> $down_payment ,
												'total_price_list'			=> $total_price_list ,
												'dpp_material'				=> $dpp_material ,
												'sub_total'					=> $sub_total ,
												'amount_1'					=> $amount_1 ,
												'balance'					=> $balance ,
												'total'						=> $total ,
												'total_price_nett'			=> $total_price_nett ,
												'total_before_pph'			=> $total_price_nett ,
												'total_hpp'					=> $total_hpp ,
												'other'						=> $other ,
												'other_2'					=> $other_2 ,
												'other_desc'				=> $other_desc ,
												'other_desc_2'				=> $other_desc_2 ,
												'ppn_other'					=> $ppn_other ,
												'jasa_pemasangan'			=> '200000',
												'pph_value'					=> '4000',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
												'bill_to_type_2'			=> $this->input->post('bill_to_type_2') ,
												'bill_to_serial_2'			=> $this->input->post('bill_to_serial_2') ,
											);
				$this->listvoucher->insertvoucher('sales',$datasibaru);
			} else {
				$bill_to_type_1				= "4" ; 
				$bill_to_serial_1			= f_v_i_e("5ba04e80f70754ec3eceae61a29e8268",$this->input->post('bill_to_serial_1'));
				$used_price_type			= "2" ; 
				$nett_price_serial			= "1d99320e9239393b4a59ef6d2ce03303" ; 
				$pay_commission_to_type		= NULL ; 
				$pay_commission_to_serial	= NULL ; 
				$commission					= "0" ; 
				$commission_type			= "2" ; 
				$total_commission			= "0" ; 
				$discount					= "0" ; 
				$discount_type				= "1" ; 
				$freight					= "0" ; 
				$ppn						= "10" ; 
				$down_payment				= "0" ; 
				$total_price_list			= "0" ; 
				$total_hpp					= "0" ; 
				$other						= "0" ; 
				$other_2					= "0" ; 
				$other_desc					= NULL ; 
				$other_desc_2				= NULL ; 
				$ppn_other					= "0" ; 
				if($this->input->post('car_model_serial') == "2513a0181c19e864530ec9aa3525afd6"){ ## FREED ##
					$dpp_material			= "4300000" ; 
					$sub_total				= "4500000" ; 
					$amount_1				= "4675000" ; 
					$balance				= "4675000" ; 
					$total					= "4675000" ; 
					$total_price_nett		= "4675000" ; 
					$total_before_pph		= "4671000" ; 
				} else if($this->input->post('car_model_serial') == "4faa585b31b62e118b321a21e99f7b2b"){ ## NEW FREED ##		
					$dpp_material			= "4300000" ; 
					$sub_total				= "4500000" ; 
					$amount_1				= "4675000" ; 
					$balance				= "4675000" ; 
					$total					= "4675000" ; 
					$total_price_nett		= "4675000" ; 
					$total_before_pph		= "4671000" ; 
				} else if($this->input->post('car_model_serial') == "2374f1d259cb07358e7e948656684252"){ ## CRZ ##		
					$amount_1				= "3850000" ; 
					$dpp_material			= "3550000" ; 
					$sub_total				= "3750000" ; 
					$balance				= "3850000" ; 
					$total					= "3850000" ; 
					$total_price_nett		= "3850000" ; 
					$total_before_pph		= "3810000" ; 
				} else if($this->input->post('car_model_serial') == "7cb2afdb2750a37b6022104b0bb1cd2f"){ ## ALL NEW ACCORD ##		
					$dpp_material			= "4400000" ; 
					$sub_total				= "4600000" ; 
					$amount_1				= "4785000" ; 
					$balance				= "4785000" ; 
					$total					= "4785000" ; 
					$total_price_nett		= "4785000" ; 
					$total_before_pph		= "4781000" ; 
				} else if($this->input->post('car_model_serial') == "d58d24d321a88608b433b491c2126555"){ ## NEW CRV ##		
					$dpp_material			= "4000000" ; 
					$sub_total				= "4200000" ; 
					$amount_1				= "4345000" ; 
					$balance				= "4345000" ; 
					$total					= "4345000" ; 
					$total_price_nett		= "4345000" ; 
					$total_before_pph		= "4341000" ; 
				} else if($this->input->post('car_model_serial') == "ac6221ffecfc04501aea9450a8383516"){ ## NEW CRV 2015 ##		
					$dpp_material			= "4300000" ; 
					$sub_total				= "4500000" ; 
					$amount_1				= "4620000" ; 
					$balance				= "4620000" ; 
					$total					= "4620000" ; 
					$total_price_nett		= "4200000" ; 
					$total_before_pph		= "4196000" ; 
				} else if($this->input->post('car_model_serial') == "8085ab9732c1ff0a453563ed994ee72c"){ ## NEW CITY 2008 ##		
					$dpp_material			= "4450000" ; 
					$sub_total				= "4650000" ; 
					$amount_1				= "4840000" ; 
					$balance				= "4840000" ; 
					$total					= "4840000" ; 
					$total_price_nett		= "4840000" ; 
					$total_before_pph		= "4836000" ; 
				} else if($this->input->post('car_model_serial') == "2c30d759c6f390344de6e5f7d681cb71"){ ## ALL NEW CIVIC ##		
					$dpp_material			= "4100000" ; 
					$sub_total				= "4300000" ; 
					$amount_1				= "4455000" ; 
					$balance				= "4455000" ; 
					$total					= "4455000" ; 
					$total_price_nett		= "4455000" ; 
					$total_before_pph		= "4451000" ; 
				} else if($this->input->post('car_model_serial') == "64448c77b37debe50be9cf810f92dc4a") { ## ODYSSEY 2010 ##		
					$amount_1				= "5280000" ; 
					$dpp_material			= "4850000" ; 
					$sub_total				= "5050000" ; 
					$balance				= "5280000" ; 
					$total					= "5280000" ; 
					$total_price_nett		= "5280000" ; 
					$total_before_pph		= "5276000" ; 
				} else if($this->input->post('car_model_serial') == "3496aa3e3762f62043aa8692c6c9bef6") { ## ODYSSEY 2014 ##		
					$amount_1				= "5280000" ; 
					$dpp_material			= "4850000" ; 
					$sub_total				= "5050000" ; 
					$balance				= "5280000" ; 
					$total					= "5280000" ; 
					$total_price_nett		= "5280000" ; 
					$total_before_pph		= "5276000" ; 
				} else if($this->input->post('car_model_serial') == "be9014f91589840220549316954ec138") { ## HRV 2015 ##		
					$amount_1				= "4050000" ; 
					$dpp_material			= "3925000" ; 
					$sub_total				= "4125000" ; 
					$balance				= "4125000" ; 
					$total					= "4125000" ; 
					$total_price_nett		= "3750000" ; 
					$total_before_pph		= "3746000" ; 
				} else if($this->input->post('car_model_serial') == "73af27980c224514faee4407df7829e5") { ## CIVIC 2015 ##		
					$amount_1				= "4840000" ; 
					$dpp_material			= "4500000" ; 
					$sub_total				= "4700000" ; 
					$balance				= "4700000" ; 
					$total					= "4700000" ; 
					$total_price_nett		= "4400000" ; 
					$total_before_pph		= "4396000" ; 
				} else if($this->input->post('car_model_serial') == "cd095aa2748d397a944683a65e0165fd") { ## CITY 2015 ##		
					$amount_1				= "4785000" ; 
					$dpp_material			= "4450000" ; 
					$sub_total				= "4650000" ; 
					$balance				= "4785000" ; 
					$total					= "4785000" ; 
					$total_price_nett		= "4350000" ; 
					$total_before_pph		= "4346000" ; 
				} else if($this->input->post('car_model_serial') == "b15c3694d1847393db57e2d1d92c52d8") { ## ACCORD 2015 ##		
					$amount_1				= "5280000" ; 
					$dpp_material			= "4900000" ; 
					$sub_total				= "5100000" ; 
					$balance				= "5280000" ; 
					$total					= "5280000" ; 
					$total_price_nett		= "4800000" ; 
					$total_before_pph		= "4796000" ; 
				} else if($this->input->post('car_model_serial') == "6bc1583756e7c9cf4f9066b9d8142df6") { ## ODYSSEY 2015 ##		
					$amount_1				= "6105000" ; 
					$dpp_material			= "5650000" ; 
					$sub_total				= "5850000" ; 
					$balance				= "6105000" ; 
					$total					= "6105000" ; 
					$total_price_nett		= "5550000" ; 
					$total_before_pph		= "5546000" ; 
				} else if($this->input->post('car_model_serial') == "afb897a0dff1606b157031ab9bf3d97b") { ## FREED 2015 ##		
					$amount_1				= "5060000" ; 
					$dpp_material			= "4700000" ; 
					$sub_total				= "4900000" ; 
					$balance				= "5060000" ; 
					$total					= "5060000" ; 
					$total_price_nett		= "4600000" ; 
					$total_before_pph		= "4596000" ; 
				} else if($this->input->post('car_model_serial') == "36acdd702c319f4b632d49d33ccd2977") { ## CRZ 2015 ##		
					$amount_1				= "4235000" ; 
					$dpp_material			= "3950000" ; 
					$sub_total				= "4150000" ; 
					$balance				= "4235000" ; 
					$total					= "4235000" ; 
					$total_price_nett		= "3850000" ; 
					$total_before_pph		= "3846000" ; 
				} else if($this->input->post('car_model_serial') == "512076efc637f9704b05257fb17cabd7") { ## NEW ACCORD 2011 ##		
					$dpp_material			= "4400000" ; 
					$sub_total				= "4600000" ; 
					$amount_1				= "4785000" ; 
					$balance				= "4785000" ; 
					$total					= "4785000" ; 
					$total_price_nett		= "4785000" ; 
					$total_before_pph		= "4781000" ; 
				} else if($this->input->post('car_model_serial') == "2ec3b4d07c31eb2889ac5b867ac85445") { ## HRV 2016 ##		
					$dpp_material			= "4300000" ; 
					$sub_total				= "4500000" ; 
					$amount_1				= "4950000" ; 
					$balance				= "4950000" ; 
					$total					= "4950000" ; 
					$total_price_nett		= "4950000" ; 
					$total_before_pph		= "4946000" ; 
				} else if($this->input->post('car_model_serial') == "19379113f9e4f562ba60ecfe5223538d") { ## BRV 2016 ##		
					$dpp_material			= "4350000" ; 
					$sub_total				= "4550000" ; 
					$amount_1				= "5005000" ; 
					$balance				= "5005000" ; 
					$total					= "5005000" ; 
					$total_price_nett		= "5005000" ; 
					$total_before_pph		= "5001000" ; 
				} else if($this->input->post('car_model_serial') == "d61f7a6d937179268882bf7ac16802c5") { ## CIVIC 2016 ##		
					$dpp_material			= "5000000" ; 
					$sub_total				= "5200000" ; 
					$amount_1				= "5390000" ; 
					$balance				= "5390000" ; 
					$total					= "5390000" ; 
					$total_price_nett		= "4900000" ; 
					$total_before_pph		= "4896000" ; 
				} else if($this->input->post('car_model_serial') == "4c0420adb0b9a152c748d1ebfb097118") { ## CRV 2016 ##		
					$dpp_material			= "4800000" ; 
					$sub_total				= "5000000" ; 
					$amount_1				= "5500000" ; 
					$balance				= "5500000" ; 
					$total					= "5500000" ; 
					$total_price_nett		= "5500000" ; 
					$total_before_pph		= "5496000" ; 
				} else if($this->input->post('car_model_serial') == "d1dd412080a10d7fb04e673c2c0ea8e6") { ## CITY 2016 ##		
					$dpp_material			= "5000000" ; 
					$sub_total				= "5200000" ; 
					$amount_1				= "5720000" ; 
					$balance				= "5720000" ; 
					$total					= "5720000" ; 
					$total_price_nett		= "5720000" ; 
					$total_before_pph		= "5716000" ; 
				} else if($this->input->post('car_model_serial') == "33c9afd83423e28f33fef7e61306a392") { ## ACCORD 2016 ##		
					$dpp_material			= "5400000" ; 
					$sub_total				= "5600000" ; 
					$amount_1				= "6160000" ; 
					$balance				= "6160000" ; 
					$total					= "6160000" ; 
					$total_price_nett		= "6160000" ; 
					$total_before_pph		= "6156000" ; 
				} else if($this->input->post('car_model_serial') == "c842879f91049101ccbefe77e8e84633") { ## ODYSSEY 2016 ##		
					$dpp_material			= "6150000" ; 
					$sub_total				= "6350000" ; 
					$amount_1				= "6655000" ; 
					$balance				= "6655000" ; 
					$total					= "6655000" ; 
					$total_price_nett		= "6655000" ; 
					$total_before_pph		= "6651000" ; 
				} else if($this->input->post('car_model_serial') == "f465040cb37375ed513263b596613bb7") { ## FREED 2016 ##		
					$dpp_material			= "5200000" ; 
					$sub_total				= "5400000" ; 
					$amount_1				= "5610000" ; 
					$balance				= "5610000" ; 
					$total					= "5610000" ; 
					$total_price_nett		= "5610000" ; 
					$total_before_pph		= "5606000" ; 
				} else if($this->input->post('car_model_serial') == "4a3fa378b0936c05afbcbba7bcaaa31a") { ## CRZ 2016 ##		
					$dpp_material			= "4400000" ; 
					$sub_total				= "4600000" ; 
					$amount_1				= "4730000" ; 
					$balance				= "4730000" ; 
					$total					= "4730000" ; 
					$total_price_nett		= "4730000" ; 
					$total_before_pph		= "4726000" ; 
				} else if($this->input->post('car_model_serial') == "06f27a2e4d62f3137c5a2d98f2786848") { ## CIVIC HB 2017 ##		
					$dpp_material			= "3600000" ; 
					$sub_total				= "3800000" ; 
					$amount_1				= "4180000" ; 
					$balance				= "4180000" ; 
					$total					= "4180000" ; 
					$total_price_nett		= "4180000" ; 
					$total_before_pph		= "4176000" ; 
				} else if($this->input->post('car_model_serial') == "de44aae908edb7e70cd8fd225d8161eb") { ## NEW CRV 2017 ##		
					$dpp_material			= "3400000" ; 
					$sub_total				= "3600000" ; 
					$amount_1				= "3960000" ; 
					$balance				= "3960000" ; 
					$total					= "3960000" ; 
					$total_price_nett		= "3960000" ; 
					$total_before_pph		= "3956000" ; 
				} else if($this->input->post('car_model_serial') == "d9c0f7fc37a7c33cb775ef3f4be30e90") { ## HR-V 2017 ##		
					$dpp_material			= "3040000" ; 
					$sub_total				= "3240000" ; 
					$amount_1				= "3564000" ; 
					$balance				= "3564000" ; 
					$total					= "3564000" ; 
					$total_price_nett		= "3564000" ; 
					$total_before_pph		= "3560000" ; 
				} else if($this->input->post('car_model_serial') == "c08c7cbacc096e745d5edba38d894ae0") { ## BR-V 2017 ##		
					$dpp_material			= "3720000" ; 
					$sub_total				= "3920000" ; 
					$amount_1				= "4312000" ; 
					$balance				= "4312000" ; 
					$total					= "4312000" ; 
					$total_price_nett		= "4312000" ; 
					$total_before_pph		= "4308000" ; 
				} else if($this->input->post('car_model_serial') == "fe95213ce271d68d60b9ac0d81311e1f") { ## CITY 2017 ##		
					$dpp_material			= "3410000" ; 
					$sub_total				= "3610000" ; 
					$amount_1				= "3971000" ; 
					$balance				= "3971000" ; 
					$total					= "3971000" ; 
					$total_price_nett		= "3971000" ; 
					$total_before_pph		= "3967000" ; 
				} else if($this->input->post('car_model_serial') == "9591b67552ff12cf76a935c0804d8146") { ## ACCORD 2017 ##		
					$dpp_material			= "3750000" ; 
					$sub_total				= "3950000" ; 
					$amount_1				= "4345000" ; 
					$balance				= "4345000" ; 
					$total					= "4345000" ; 
					$total_price_nett		= "4345000" ; 
					$total_before_pph		= "4341000" ; 
				} else if($this->input->post('car_model_serial') == "1bd182d26c7c3ab74c5f16a64c81a07e") { ## ODYSSEY 2017 ##		
					$dpp_material			= "4270000" ; 
					$sub_total				= "4470000" ; 
					$amount_1				= "4917000" ; 
					$balance				= "4917000" ; 
					$total					= "4917000" ; 
					$total_price_nett		= "4917000" ; 
					$total_before_pph		= "4913000" ; 
				} else if($this->input->post('car_model_serial') == "5b96dd033093169c9309d05d2b187524") { ## CIVIC 2017 ##		
					$dpp_material			= "3700000" ; 
					$sub_total				= "3800000" ; 
					$amount_1				= "4180000" ; 
					$balance				= "4180000" ; 
					$total					= "4180000" ; 
					$total_price_nett		= "4180000" ; 
					$total_before_pph		= "4176000" ; 
				} else if($this->input->post('car_model_serial') == "9655268513248ad9ed538a8c4a21fbf5") { ## BR-V PR 2017 ##		
					$dpp_material			= "3720000" ; 
					$sub_total				= "3920000" ; 
					$amount_1				= "4312000" ; 
					$balance				= "4312000" ; 
					$total					= "4312000" ; 
					$total_price_nett		= "4312000" ; 
					$total_before_pph		= "4308000" ; 
				} else if($this->input->post('car_model_serial') == "d99281fe52e1380e0ebe266cfc2adacc") { ## CIVIC TYPE R ##		
					$dpp_material			= "4700000" ; 
					$sub_total				= "4900000" ; 
					$amount_1				= "5390000" ; 
					$balance				= "5390000" ; 
					$total					= "5390000" ; 
					$total_price_nett		= "5390000" ; 
					$total_before_pph		= "5386000" ; 
				}
				if($this->session->userdata('level') == "1" || $this->input->post('dealer_luarkota_serial') == "0b3d3a2a222532eee73961d90f73600a" || $this->input->post('dealer_luarkota_serial') == "cd1facf3440908e8938a4b8595dc0a24" || $this->input->post('dealer_luarkota_serial') == "459795c92aff4ec88a48704989ee2b2e" || $this->input->post('dealer_luarkota_serial') == "4c5466186b321ce3de9b6f95b8b3821f" ||  $this->input->post('dealer_luarkota_serial') == "58e549957faf6e7dac067a7ee675603f") {
					if($this->input->post('sistatus') == "1"){
						$sistatus			= "1";
					} else {
						$sistatus			= "2";
					}
				} else {
					$sistatus				= "1";
				}

				$orderdatexsi				= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$installationdatexsi		= format_date($this->input->post('tanggal_terbit_voucher'),"Y-m-d");
				$duedatexsi					= date("Y-m-d", strtotime("".$this->input->post('tanggal_terbit_voucher')." +".$totday." days"));
				$duedatetekxsi				= date("Y-m-d", strtotime("".$this->input->post('tanggal_pasang_voucher')." +".$totday." days"));
				$pairingdatexsi				= f_v_i_e(date("Y-m-d"),format_date(f_v_i_e($this->input->post('tanggal_pasang_voucherx'),$this->input->post('tanggal_pasang_voucher')),"Y-m-d"));

				$dataupdatesi				= array (
												'last_updated_by'			=> $this->session->userdata('serial'),
												'sales_invoice_no_car'		=> f_v_i_e($prefixsi,$this->input->post('si_no')),
												'sales_order_no'			=> $serialsobaru,
												'sales_type'				=> '2',
												'status'					=> $sistatus,
												'warranty_no'				=> f_v_i_e($warrantyno,$this->input->post('warranty_no')),
												'spk_has_returned'			=> '2',
												'is_holiday'				=> '2',
												'is_real_tax'				=> '1',
												'commission_type'			=> '1',
												'total_commission'			=> '1',
												'commission_paid_status'	=> '2',
												'branch_company'			=> '10',
												'sudah_dijurnal'			=> '2',
												'installation_type'			=> '01',
												'paid_status_amount_1'		=> '2',
												'paid_status_amount_2'		=> '1',
												'paid_status_amount_3'		=> '1',
												'amount_2'					=> '0',
												'amount_3'					=> '0',
												'discount2'					=> '0',
												'discount2_type'			=> '1',
												'ppn_other'					=> '0',
												'so_has_print'				=> '3',
												'bisa_print'				=> '2',
												'other'						=> '0',
												'other_3'					=> '0',
												'customer_type'				=> '2',
												'customer_serial'			=> $serialusers,
												'window_film_desc'			=> $windowfilmdesc,
												'note'						=> 'PAKET VOUCHER',
												'installation_address'		=> get_null_if_empty($this->input->post('tempat_pasang_voucher')),
												'prefix_depo'				=> get_null_if_empty($this->input->post('prefix_depo_pemasangan')),
												'total_bonus'				=> $totalbonus,

												'order_date'				=> $orderdatexsi,
												'installation_date'			=> $installationdatexsi,
												'due_date'					=> $duedatexsi,
												'pairing_date'				=> $pairingdatexsi,

												'car_type_serial'			=> $this->input->post('car_model_serial'),
												'car_color'					=> $this->input->post('car_color'),
												'car_year'					=> date("Y"),
												'chassis_no'				=> $this->input->post('chassis_no'),
												'order_from_type'			=> '4',
												'dealer_serial'				=> '6599286d6fdd228dc45df5546cf69d4f',
												'showroom_serial'			=> $this->input->post('showroom_serial'),
												'bill_to_type_1'			=> $bill_to_type_1 ,
												'bill_to_serial_1'			=> $bill_to_serial_1 ,
												'used_price_type'			=> $used_price_type ,
												'nett_price_serial'			=> $nett_price_serial ,
												'pay_commission_to_type'	=> $pay_commission_to_type ,
												'pay_commission_to_serial'	=> $pay_commission_to_serial ,
												'commission'				=> $commission ,
												'commission_type'			=> $commission_type ,
												'total_commission'			=> $total_commission ,
												'discount'					=> $discount ,
												'discount_type'				=> $discount_type ,
												'freight'					=> $freight ,
												'ppn'						=> $ppn ,
												'down_payment'				=> $down_payment ,
												'total_price_list'			=> $total_price_list ,
												'total_hpp'					=> $total_hpp ,
												'other'						=> $other ,
												'other_2'					=> $other_2 ,
												'other_desc'				=> $other_desc ,
												'other_desc_2'				=> $other_desc_2 ,
												'ppn_other'					=> $ppn_other ,
												'dpp_material'				=> $dpp_material ,
												'sub_total'					=> $sub_total ,
												'amount_1'					=> $amount_1 ,
												'balance'					=> $balance ,
												'total'						=> $total ,
												'total_price_nett'			=> $total_price_nett ,
												'total_before_pph'			=> $total_price_nett ,
												'jasa_pemasangan'			=> '200000',
												'pph_value'					=> '4000',
												'installation_category_1'	=> $installationcategory1,
												'dealer_luarkota_serial'	=> $dealerluarkotaserial,
												'location_type'				=> $locationtype,
												'bill_to_type_2'			=> $this->input->post('bill_to_type_2') ,
												'bill_to_serial_2'			=> $this->input->post('bill_to_serial_2') ,
											);
				$wheresiupdate				= array ('serial'				=> $serialsibaru);
				$this->listvoucher->updatedata($wheresiupdate,$dataupdatesi,'sales');
			}
			################################################ END :: INSERT SI HEADER ################################################
			############################################ START :: INSERT PURCHASE HEADER ############################################
			if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
				$purchaseprice					= $this->listquerytable->getpurchaseprice($this->input->post('tanggal_terbit_voucher'),'',$this->input->post('dealer_luarkota_serial'),$this->input->post('car_model_serial'));
				if($purchaseprice){
					$serialpurchase				= get_serial('addpurchase');
					$prefixpurchase				= $this->listquerytable->getnextprefixno("PINH-".date("y")."/","purchase","purchase_invoice_no");
					$pricebahan 				= f_v_i_e("0",$purchaseprice[0]->price_bahan);
					$pricejasa 					= f_v_i_e("0",$purchaseprice[0]->price_jasa);
					$price 						= f_v_i_e("0",$purchaseprice[0]->price);
					$rebate 					= f_v_i_e("0",$purchaseprice[0]->rebate);
					$datapurchasebaru			= array (
													'serial'					=> $serialpurchase,
													'created_by'				=> $this->session->userdata('serial'),
													'purchase_type'				=> '3',
													'purchase_invoice_no'		=> $prefixpurchase,
													'date'						=> format_date($this->input->post('tanggal_pasang_voucher'),"Y-m-d"),
													'supplier_type'				=> 'K',
													'supplier_serial'			=> $this->input->post('dealer_luarkota_serial'),
													'supplier_invoice_no'		=> $this->input->post('chassis_no'),
													'exchange_rate_currency'	=> '1',
													'exchange_rate_kurs'		=> '9000',
													'bill_to_type'				=> 'K',
													'bill_to_serial'			=> $this->input->post('dealer_luarkota_serial'),
													'note'						=> $this->input->post('txt_car_model_serial')." ( ".$this->input->post('chassis_no')." )",
													'sub_total'					=> $price,
													'discount'					=> '0',
													'discount_type'				=> '1',
													'freight'					=> '0',
													'ppn'						=> '0',
													'total'						=> $price,
													'down_payment'				=> '0',
													'balance'					=> $price,
													'total_rebate_us'			=> '0',
													'total_rebate_idr'			=> $rebate,
													'status'					=> '1',
													'branch_company'			=> '10',
													'sudah_dijurnal'			=> '2',
													'payment_type'				=> '1',
													'sales_invoice_no'			=> $serialsibaru,
												);
					$this->listvoucher->insertvoucher('purchase',$datapurchasebaru);
				}
			}
			############################################# END :: INSERT PURCHASE HEADER #############################################
			########################################## START INFO : SEND EMAIL NOTIFICATION #########################################
			if($this->input->post('upload_garansi_vkool') == "" || $this->input->post('upload_garansi_vkool') == NULL){
				$this->email->from('vos.honda@scs-vkool.com', 'VOUCHER ONLINE SYSTEM');
				####### MENAMPILKAN LIST EMAIL DEALER HONDA #######
				$emaildl 		= "";
				$resdealer		= $this->listquerytable->getemailuser('7','dealer_serial',$this->input->post('showroom_serial'));
				for($dl=0;$dl<count($resdealer);$dl++) {
					$emaildl	.= $resdealer[$dl]->email."," ;
				}
				###################################################
				####### MENAMPILKAN LIST EMAIL DEALER VKOOL #######
				$emaildlk 		= "";
				$resdealerlk	= $this->listquerytable->getemailuser('4','serial',$this->input->post('dealer_luarkota_serial'));
				for($dlk=0;$dlk<count($resdealerlk);$dlk++) {
					$emaildlk	.= $resdealerlk[$dlk]->email."," ;
				}
				###################################################
				//'counter@scs-vkool.com',
				//print_r($resdealerlk);
				$toemailadd		= substr($emaildl,0,-1).",".substr($emaildlk,0,-1);
				$this->email->to($toemailadd);
				$this->email->cc('scs.counter@yahoo.com');
				$this->email->subject('[PEMASANGAN] Kaca Film Mobil Honda '.$this->input->post('txt_car_model_serial').' ( '.$this->input->post('chassis_no').' )');
				$bodyinformasi	= "Berikut ini adalah informasi mengenai Pemasangan Kaca Film V-KOOL :<br /><br />";
				$bodyinformasi	.= "Dealer VKOOL					: <b>".strtoupper($this->input->post('txt_dealer_luarkota_serial'))."</b><br />";
				$bodyinformasi	.= "No. Voucher						: <b>".$this->input->post('voucher_no')."</b><br />";
				$bodyinformasi	.= "No. Rangka Kendaraan 			: <b>".$this->input->post('chassis_no')."</b><br />";
				$bodyinformasi	.= "Model Mobil Honda				: <b>".$this->input->post('txt_car_model_serial')."</b><br />";
				$bodyinformasi	.= "Warna Mobil Honda				: <b>".$this->input->post('car_color')."</b><br />";
				//$bodyinformasi	.= "Tanggal Pengajuan Pemasangan	: <b>".format_date($this->input->post('tanggal_order_voucher'))."</b><br />";
				$bodyinformasi	.= "Tanggal Pengajuan Pemasangan	: <b>".$this->input->post('tanggal_order_voucher')."</b><br />";
				$bodyinformasi	.= "Upgrade	?						: <b>".yes_no($this->input->post('upgrade_kacafilm'))."</b><br /><br />";
				$bodyinformasi	.= "Kaca Film Yang Dipasang			: <b><br />";
				$resdetail		= $this->listvoucher->getdetaillist($this->input->post('serial'));
				for ($jv=0;$jv<count($resdetail);$jv++) {
					$bodyinformasi	.= window_position($resdetail[$jv]->window_position)." ".window_position_detail($resdetail[$jv]->window_position,$resdetail[$jv]->window_position_detail)." : <i>".$resdetail[$jv]->inventory_name."</i><br />";
				}
				$bodyinformasi	.= "</b><br />";
				$bodyinformasi	.= "Ingin menginformasikan bahwa mobil tersebut diatas akan dilakukan pemasangan kaca film VKOOL pada : <br /><br />";
				$bodyinformasi	.= "Tanggal Pemasangan				: <b>".format_date(f_v_i_e(date("Y-m-d"),$this->input->post('tanggal_pasang_voucher')))."</b><br />";
				$bodyinformasi	.= "Tempat Pemasangan				: <b>".strtoupper($this->input->post('tempat_pasang_voucher'))."</b><br /><br />";
				$bodyinformasi	.= "Atas perhatian dan kerjasama nya, kami ucapkan terima kasih.<br /><br />";
				$bodyinformasi	.= "Untuk melacak pemasangan silahkan klik link ini : <a href=http://tracking.scs-vkool.com/home/a?cari=".$this->input->post('chassis_no')."'> LIVE TRACKING </a><br />Sementara hanya untuk pemasangan kaca film VKOOL di wilayah Jakarta<br /><br /><br />";
				$bodyinformasi	.= "--------------------------------------------------------------------------------------------------------------------------<br />";
				$bodyinformasi	.= "<b>NB : APABILA DALAM JANGKA WAKTU 2 HARI SETELAH TANGGAL PEMASANGAN,<br />KACAFILM V-KOOL BELUM TERPASANG PADA UNIT MOBIL</b><br />";
				$bodyinformasi	.= "<b>DIHARAPKAN SEGERA DIBUAT MEMO BATAL</b><br />";
				$bodyinformasi	.= "--------------------------------------------------------------------------------------------------------------------------<br /><br />";
				$bodyinformasi	.= "Salam,<br /><br /><br />Voucher Online System<br /><br /><br />";
				$bodyinformasi	.= "-------------------------------------------------------------------------------------<br />";
				$bodyinformasi	.= "This Is An Automatically Generated Email, Please Do Not Reply.<br />";
				$bodyinformasi	.= "-------------------------------------------------------------------------------------";
				$this->email->message($bodyinformasi);
				if(!$this->email->send()){
					$this->email->print_debugger();
				}
			}
			########################################### END INFO : SEND EMAIL NOTIFICATION ##########################################
			redirect(base_url().'updatevoucher/listvoucher');
		}
	}
}

