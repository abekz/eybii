<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Testxajax extends CI_Controller {

	public function index(){
		$template['xajax_js']	= $this->xajax->getJavascript(base_url());
		$template['content']	= '<div id="SomeElementId"></div>&lt;input type="button" value="test"  onclick="xajax_test_function(2);"&gt;';
		$this->load->view('layout/testxajax', $template);
	}

	function Testxajax() {
		parent::controller();
		$this->load->library('xajax');
		$this->xajax->registerFunction(array('test_function',&$this,'test_function'));
		$this->xajax->processRequest();
	}

	function test_function($number) {
		$objResponse = new xajaxResponse();
		$objResponse->Assign("SomeElementId","innerHTML", "Xajax is working. Lets add: ".($number+3));
		return $objResponse;
	}
}
