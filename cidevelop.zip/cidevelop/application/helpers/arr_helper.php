<?php
	function cancellation_memo_reference($reference){
		if ($reference == '1') {
			return strtoupper('INVENTORY');
		} else if ($reference == '2') {
			return strtoupper('COUNTER');
		} else if ($reference == '3') {
			return strtoupper('OPERATIONAL');
		} else if ($reference == '4') {
			return strtoupper('HONDA ONLINE');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function reason_chassis_double($reference){
		if ($reference == '1') {
			return strtoupper('BATAL PASANG');
		} else if ($reference == '2') {
			return strtoupper('SPK MASIH DI TEKNISI / DEALER');
		} else if ($reference == '3') {
			return strtoupper('BAHAN MASIH DI TEKNISI / DEALER');
		} else if ($reference == '4') {
			return strtoupper('JENIS PEMASANGAN BERBEDA');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_deleted_openstatus($reference){
		if ($reference == '1') {
			return strtoupper('ACTIVE AND SHOW');
		} else if ($reference == '2') {
			return strtoupper('ACTIVE BUT HIDE');
		} else if ($reference == '3') {
			return strtoupper('DELETED OR CANCELLED');
		} else if ($reference == '4') {
			return strtoupper('ON PROGRESS');
		} else if ($reference == '5') {
			return strtoupper('OPEN STATUS');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_deleted($reference){
		if ($reference == '1') {
			return strtoupper('ACTIVE AND SHOW');
		} else if ($reference == '2') {
			return strtoupper('ACTIVE BUT HIDE');
		} else if ($reference == '3') {
			return strtoupper('DELETED OR CANCELLED');
		} else if ($reference == '4') {
			return strtoupper('ON PROGRESS');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_warranty($reference){
		if ($reference == '1') {
			return strtoupper('BELUM DIGUNAKAN');
		} else if ($reference == '2') {
			return strtoupper('SUDAH DIGUNAKAN');
		} else if ($reference == '3') {
			return strtoupper('BATAL DIGUNAKAN');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_deleted3($reference){
		if ($reference == '1') {
			return strtoupper('COMPLETED');
		} else if ($reference == '2') {
			return strtoupper('PENDING');
		} else if ($reference == '3') {
			return strtoupper('CANCELLED');
		} else if ($reference == '5') {
			return strtoupper('CANCELLATION REQUIRES APPROVAL');
		} else if ($reference == '4') {
			return strtoupper('ON PROGRESS');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_approval2($reference){
		if ($reference == '1') {
			return strtoupper('PENDING');
		} else if ($reference == '2') {
			return strtoupper('APPROVED');
		} else if ($reference == '3') {
			return strtoupper('CANCELLED');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_pasang($reference){
		if ($reference == '1') {
			return strtoupper('BELUM TERPASANG');
		} else if ($reference == '2') {
			return strtoupper('SUDAH TERPASANG');
		} else if ($reference == '3') {
			return strtoupper('BATAL TERPASANG');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function window_position($reference){
		if ($reference == '1') {
			return strtoupper('FRONT');
		} else if ($reference == '2') {
			return strtoupper('SIDE');
		} else if ($reference == '3') {
			return strtoupper('REAR');
		} else if ($reference == '4') {
			return strtoupper('SUN ROOF');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function window_position_detail($position,$reference){
		if ($position == '1') {
			if($reference == '1'){
				return strtoupper('FULL');
			} else if($reference == '2'){
				return strtoupper('ALINGAN');
			} else {
				return strtoupper('LAIN-LAIN');
			} 
		} else if ($position == '2') {
			if($reference == '1'){
				return strtoupper('FULL');
			} else if($reference == '2'){
				return strtoupper('1 KACA');
			} else if($reference == '3'){
				return strtoupper('2 KACA DEPAN');
			} else if($reference == '4'){
				return strtoupper('2 KACA TENGAH');
			} else if($reference == '5'){
				return strtoupper('2 KACA BELAKANG');
			} else if($reference == '6'){
				return strtoupper('3 KACA');
			} else if($reference == '7'){
				return strtoupper('4 KACA');
			} else if($reference == '8'){
				return strtoupper('2 KACA MATI');
			} else if($reference == '9'){
				return strtoupper('1 KACA MATI');
			} else if($reference == '10'){
				return strtoupper('2 KACA');
			} else {
				return strtoupper('LAIN-LAIN');
			} 
		} else if ($position == '3') {
			if($reference == '1'){
				return strtoupper('FULL');
			} else {
				return strtoupper('LAIN-LAIN');
			} 
		} else if ($position == '4') {
			if($reference == '1'){
				return strtoupper('1 KACA DEPAN');
			} else if($reference == '2'){
				return strtoupper('1 KACA TENGAH');
			} else if($reference == '3'){
				return strtoupper('1 KACA BELAKANG');
			} else if($reference == '4'){
				return strtoupper('2 KACA');
			} else if($reference == '5'){
				return strtoupper('3 KACA');
			} else {
				return strtoupper('LAIN-LAIN');
			} 
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function user_type4($reference){
		if ($reference == 'X') {
			return strtoupper('DEALER');
		} else if ($reference == '3') {
			return strtoupper('MAIN DEALER');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function yes_no($reference){
		if ($reference == '1') {
			return strtoupper('YES');
		} else if ($reference == '2') {
			return strtoupper('NO');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function prefixdepopemasangan($reference){
		if ($reference == 'SOCT-') {
			return strtoupper('TENDEAN');
		} else if ($reference == 'SOCK-') {
			return strtoupper('KEPALA GADING');
		} else if ($reference == 'SOCS-') {
			return strtoupper('SAMANHUDI');
		} else if ($reference == 'SOCM-') {
			return strtoupper('MERUYA');
		} else if ($reference == 'SOCR-') {
			return strtoupper('SERPONG');
		} else if ($reference == 'SOCH-') {
			return strtoupper('SUNTER');
		} else if ($reference == 'SOCU-') {
			return strtoupper('CIBUBUR');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

	function status_voucher($reference){
		if ($reference == '1') {
			return strtoupper('ACTIVE');
		} else if ($reference == '2') {
			return strtoupper('EXPIRED');
		} else if ($reference == '3') {
			return strtoupper('ALREADY USE');
		} else if ($reference == '4') {
			return strtoupper('REACTIVATED');
		} else if ($reference == '5') {
			return strtoupper('DELETED OR CANCELLED');
		} else {
			return strtoupper('LAIN-LAIN');
		}
	}

