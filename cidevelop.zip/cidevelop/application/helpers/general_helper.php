<?php
#><script>
	function OpenConnection()
	{
		global $_DB_USED, $_DB_HOST, $_DB_USER_NAME, $_DB_USER_PASSWD, $_DB_NAME;
		$conn = NewADOConnection($_DB_USED);
#		$conn->debug = true;
		$conn->Connect($_DB_HOST,$_DB_USER_NAME,$_DB_USER_PASSWD,$_DB_NAME);
		return $conn;
	} 

	function OpenConnectionPusat()
	{
		global $_DB_USED_PUSAT, $_DB_HOST_PUSAT, $_DB_USER_NAME_PUSAT, $_DB_USER_PASSWD_PUSAT, $_DB_NAME_PUSAT;
		$conn = NewADOConnection($_DB_USED_PUSAT);
#		$conn->debug = true;
		$conn->Connect($_DB_HOST_PUSAT,$_DB_USER_NAME_PUSAT,$_DB_USER_PASSWD_PUSAT,$_DB_NAME_PUSAT);
		return $conn;
	} 

	function OpenConnectionVKOOL()
	{
		global $_DB_USED_VKOOL, $_DB_HOST_VKOOL, $_DB_USER_NAME_VKOOL, $_DB_USER_PASSWD_VKOOL, $_DB_NAME_VKOOL;
		$connvk = NewADOConnection($_DB_USED_VKOOL);
#		$connvk->debug = true;
		$connvk->Connect($_DB_HOST_VKOOL,$_DB_USER_NAME_VKOOL,$_DB_USER_PASSWD_VKOOL,$_DB_NAME_VKOOL);
		return $connvk;
	} 

	function OpenConnectionTax()
	{
		global $_DB_USED_TAX, $_DB_HOST_TAX, $_DB_USER_NAME_TAX, $_DB_USER_PASSWD_TAX, $_DB_NAME_TAX;
		$conn = NewADOConnection($_DB_USED_TAX);
#		$conn->debug = true;
		$conn->Connect($_DB_HOST_TAX,$_DB_USER_NAME_TAX,$_DB_USER_PASSWD_TAX,$_DB_NAME_TAX);
		return $conn;
	}

	function OpenConnectionFiktif()
	{
		global $_DB_USED_FIKTIF, $_DB_HOST_FIKTIF, $_DB_USER_NAME_FIKTIF, $_DB_USER_PASSWD_FIKTIF, $_DB_NAME_FIKTIF;
		$conn = NewADOConnection($_DB_USED_FIKTIF);
#		$conn->debug = true;
		$conn->Connect($_DB_HOST_FIKTIF,$_DB_USER_NAME_FIKTIF,$_DB_USER_PASSWD_FIKTIF,$_DB_NAME_FIKTIF);
		return $conn;
	}

	function get_next_prefix_no($prefix="", $table="", $field="", $isTax="",$isResetCount="",$isResetCountYear="")
	{
		$conn=($isTax?OpenConnectionTax():OpenConnection());
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name($table);
		$builder->set_value($field);
		if($isResetCount == "1"){
			$builder->set_rules("","","","$field ilike '%".substr($prefix,-7,4)."%' AND created_date >= '".$isResetCountYear."-01-01'");
		} else {
			if($field == "spk_no"){
				$builder->set_rules("","","","$field ilike '%".substr($prefix,-8,5)."%' AND created_date >= '2012-04-30'");
			} else {
				$builder->set_rules("","","","$field ilike '%".substr($prefix,-7,4)."%' AND created_date >= '2010-01-01'");
			}
		}
		/*
		if($table == "sales"){
			$builder->set_condition();
			$builder->set_rules("status","1");
		}
		*/
		$builder->set_order($field, DESC);
		$builder->set_limit("1");
		$sql 		= $builder->select_data();
		//echo $sql;
		$result 	= $conn->GetOne($sql);
		unset($conn);
		if($result) {
			$next_val	= substr($result, -7) + 1; # PENAMBAHAN PREFIK BERIKUTNYA DENGAN DITAMBAH ANGKA 1 #
		} else {
			$next_val	= "1";
		}
		$new_val		= $prefix.sprintf("%07d", $next_val); # $PREFIK ADALAH PREFIK DARI SETIAP FORM YANG DIGUNAKAN DAN NILAI %7D MERUPAKAN BANYAKNYA DIGIT YANG AKAN DIGUNAKAN #
		return $new_val;
	}

	function get_next_tax_no($prefix="010.017-17.")
	{
		$conn=OpenConnectionTax();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name("sales");
		$builder->set_value("tax_no");
		$builder->set_condition();
		$builder->set_rules("tax_no", $prefix,"ilike");
		$builder->set_rules("status", "1");
		$builder->set_order("tax_no", DESC);
		$builder->set_limit("1");
		$sql 		= $builder->select_data();
		$result 	= $conn->GetAll($sql);
		if($result)
		{
			$next_val	= substr($result[0]['tax_no'], -8) + 1;
		}
		else
		{
			$next_val	= "1";
		}
		$new_val		= $prefix.sprintf("%08d", $next_val);
		unset($conn);
		return $new_val;
	}
	
	function get_next_simple_tax_no($prefix="SCSF-09/")
	{
		return get_next_tax_no($prefix);
	}

	function get_all_type_str($field="", $arr_type="", $min="", $max="", $default="", $extra="")
	{
		global $_GET, $_POST;
		$extra = explode(",", $extra);
		$_GET[$field]		= f_v_i_e($default, $_GET[$field]);
		if ((($_GET[$field] < $min) || ($_GET[$field] > $max)) && !in_array($_GET[$field], $extra))# $_GET[$field] != $extra)
			$_GET[$field]	= $default;
		$_POST[$field]		= f_v_i_e($_GET[$field], $_POST[$field]);
		$_GET[$field]		= $_POST[$field];
		return $arr_type[$_GET[$field]];
	}
	
	## START INFORMATION ###
	## UNTUK MENGETAHUI TYPE YANG DIGUNAKAN OLEH TIAP-TIAP FORM ###	
	function get_user_type_str()
	{
		global $_USER_TYPE;
		$result	= get_all_type_str($field="user_type", $arr_type=$_USER_TYPE, $min="1", $max="9", $default="2", $extra="Y,Z,K");
		return $result;
	}
	
	function get_opening_ar_ap_type_str()
	{
		global $_OPENING_AR_AP;
		$result	= get_all_type_str($field="opening_type", $arr_type=$_OPENING_AR_AP, $min="1", $max="3", $default="2");
		return $result;
	}
	
	function get_purchase_type_str()
	{
		global $_PURCHASE_TYPE, $_STATUS_DELETED, $_STATUS_DELETED2;
		$result	= get_all_type_str($field="purchase_type", $arr_type=$_PURCHASE_TYPE, $min="1", $max="4", $default="1");
		if ($_GET["purchase_type"] == "1") $_STATUS_DELETED	= $_STATUS_DELETED2;
		return $result;
	}
	
	function get_sales_type_str()
	{
		global $_SALES_TYPE, $_STATUS_DELETED, $_STATUS_DELETED3;
		$result	= get_all_type_str($field="sales_type", $arr_type=$_SALES_TYPE, $min="1", $max="8", $default="1", $extra="A,B");
		if ($_GET["sales_type"] == "2" || $_GET["sales_type"] == "4" || $_GET["sales_type"] == "6" || $_GET["sales_type"] == "B") $_STATUS_DELETED	= $_STATUS_DELETED3;
		return $result;
	}
	
	function get_inventory_process_type_str()
	{
		global $_INVENTORY_PROCESS_TYPE;
		$result	= get_all_type_str($field="inventory_process_type", $arr_type=$_INVENTORY_PROCESS_TYPE, $min="1", $max="8", $default="1");
		return $result;
	}
	
	function get_billing_process_type_str()
	{
		global $_BILLING_PROCESS_TYPE;
		$result	= get_all_type_str($field="billing_process_type", $arr_type=$_BILLING_PROCESS_TYPE, $min="1", $max="3", $default="1");
		return $result;
	}
	
	function get_technician_process_type_str()
	{
		global $_TECHNICIAN_PROCESS_TYPE;
		$result	= get_all_type_str($field="technician_process_type", $arr_type=$_TECHNICIAN_PROCESS_TYPE, $min="1", $max="5", $default="1");
		return $result;
	}
	
	function get_cn_dn_type_str()
	{
		global $_CN_DN_TYPE;
		$result	= get_all_type_str($field="cn_dn_type", $arr_type=$_CN_DN_TYPE, $min="1", $max="2", $default="1");
		return $result;
	}
	
	function get_giro_process_type_str()
	{
		global $_GIRO_PROCESS_TYPE;
		$result	= get_all_type_str($field="giro_process_type", $arr_type=$_GIRO_PROCESS_TYPE, $min="1", $max="4", $default="1");
		return $result;
	}
	
	function get_hrd_process_type_str()
	{
		global $_HRD_PROCESS_TYPE;
		$result	= get_all_type_str($field="hrd_process_type", $arr_type=$_HRD_PROCESS_TYPE, $min="1", $max="4", $default="1");
		return $result;
	}
	
	function get_cash_flow_process_type_str()
	{
		global $_CASH_FLOW_PROCESS_TYPE;
		$result	= get_all_type_str($field="cash_flow_process_type", $arr_type=$_CASH_FLOW_PROCESS_TYPE, $min="01", $max="10", $default="01");
		return $result;
	}
	## END INFORMATION ###
	
	function get_item_group_array($item_cat="")
	{
		global $_WINDOW_FILM_GROUP, $_ACCESSORIES_GROUP;
		if ($item_cat == "1")
		{
			$item_group	= $_WINDOW_FILM_GROUP;
		}
		elseif ($item_cat == "2")
		{
			$item_group	= $_ACCESSORIES_GROUP;
		} 
		else 
		{
			$item_group	= "";
		}
		return $item_group;
	}
	
	function get_odd_even_tr($row_no="")
	{
		$color_out_odd		= "#F0F0F0";
		$color_over_odd		= "#CCFFCC";
		$color_click_odd	= "#CCDDFF";
		$color_out_even		= "#FFFFFF";
		$color_over_even	= "#CCFFCC";
		$color_click_even	= "#CCDDFF";
		if ($row_no%2==0) 
		{	# genap
			$str			= "even";
		} 
		else 
		{			# ganjil 
			$str			= "odd";
		}
		$color_out		= ${"color_out_$str"};
		$color_over		= ${"color_over_$str"};
		$color_click	= ${"color_click_$str"};
		$result			= "bgcolor='$color_out' style='cursor=hand;' onmouseover=\"setPointer(this, $row_no, 'over', '$color_out', '$color_over', '$color_click');\" onmouseout=\"setPointer(this, $row_no, 'out', '$color_out', '$color_over', '$color_click');\" onmousedown=\"setPointer(this, $row_no, 'click', '$color_out', '$color_over', '$color_click');\"";
		return $result;
	}

	function array_copy($source="", $destination="", $exceptions="", $force="") 
	{
		if ($source && $destination)
		foreach ($source as $key=>$val) 
		{
			if ((!in_array($key, $exceptions) && array_key_exists($key, $destination)) || $force) 
			{
				$destination[$key]	= $val;
			}
		}
		return $destination;
	}
	
	function array_merge_sum($source="", $destination="", $field_key="", $field_jml="") 
	{
		if (!$destination && $source) 
		{
			$destination	= array_copy($source, $destination, "", "1");
		} 
		elseif ($source) 
		{
			for($i=0;$i<count($source["$field_key"]);$i++) 
			{
				$is_found	= false;
				for($j=0;$j<count($destination["$field_key"]);$j++) 
				{
					if ($source["$field_key"][$i] == $destination["$field_key"][$j]) 
					{
						$is_found						= true;
						$destination["$field_jml"][$j]	+= $source["$field_jml"][$i];
					}
				}
				if (!$is_found) 
				{
					$destination["$field_key"][]		= $source["$field_key"][$i];
					$destination["$field_jml"][]		= $source["$field_jml"][$i];
				}
			}
		}
		return $destination;
	}
	
	function get_this_month_birthday()
	{
		$arr_staff	= get_users_array("","7","","","",date("m"));
		if ($arr_staff) 
		{
			$result 	= implode(", ", $arr_staff);
			$result		= "This Month Birthday : $result. Happy Birthday To You All.";
			$today_bday	= "";
			foreach ($arr_staff as $val) 
			{
				$hari	= date("N");
				$pos	= strpos($val, "<".date("d")." ".date("M")." ");
				if ($hari == "1" && $pos === false) 
				{
					$pos= strpos($val, "<".(date("d")-1)." ".date("M")." ");
				}
				if ($pos !== false) 
				{
					if ($today_bday) $today_bday .= ", ";
					$today_bday .= $val."";
				}
				#######################
				$pos2	= strpos($val, "<".date("d")."-".date("M")."-");
				if ($hari == "1" && $pos2 === false) 
				{
					$pos2= strpos($val, "<".(date("d")-1)."-".date("M")."-");
				}
				if ($pos2 !== false) 
				{
					if ($today_bday) $today_bday .= ", ";
					$today_bday .= $val."";
				}
			}
			return $result."====".$today_bday;
		} 
		else 
		{
			return "";
		}
	}

	function get_random_image_bday($msg="")
	{	
		global $_PATH;
		unset($files);
		if ($handle = opendir($_PATH."images/bday/")) 
		{
			while (false !== ($file = readdir($handle))) 
			{
				if ($file != "." && $file != ".." && is_file($_PATH."images/bday/".$file)) 
				{
					$files[] = "/images/bday/".$file;
				}
			}
			closedir($handle);
			$pos	= rand(0,count($files)-1);
		}
		$tmpstr	= "<center><img src=\"".$files[$pos]."\" alt=\"$msg\" title=\"$msg\"><br><font color='#FF0000'><strong>$msg</strong></font></center>";
		return $tmpstr;
	}

	function get_all_serial_in_rst($rst, $fieldname)
	{
		$tmp_all_serial = "";
		if ($rst)
		for ($i=0;$i<count($rst);$i++) 
		{
			if($rst[$i][$fieldname] != ""){
				if ($tmp_all_serial) $tmp_all_serial .= ", ";
				$tmp_all_serial .= "'".$rst[$i][$fieldname]."'";
			}
		}
		return $tmp_all_serial;
	}

	function get_all_coa_number_in_array($arr="", $branch="", $coa_str="") 
	{
		foreach ($arr as $key => $val) 
		{
			if ($branch) 
			{
				if ($key==$branch) 
				{
					if ($val) 
					{
						if ($coa_str) $coa_str	.= ", ";
						$coa_str	.= "'$val'";
					}
				}
			} 
			else 
			{
				if ($val) 
				{
					if ($coa_str) $coa_str	.= ", ";
					$coa_str	.= "'$val'";
				}
			}
		}
		return $coa_str;
	}
	
	function get_grouping_array($arr_fieldname, $indukserial, $rst) 
	{
		if ($rst) 
		{
			for ($i=0;$i<count($rst);$i++) 
			{ 	
				for ($j=0;$j<count($arr_fieldname);$j++) 
				{	
					$tmp_rst[$rst[$i][$indukserial]][$arr_fieldname[$j]][] 	= $rst[$i][$arr_fieldname[$j]];
				}
			}
			$rst = $tmp_rst;
		}
		return $rst;
	}

	function _array_alter (&$item1, $key, $prefix) 
	{
		$element = $prefix[_element_replace];
		$item1[$element] = $prefix[$item1[$element]];
	}
	/*
	function array_replace($array,$key,$value) 
	{
		$value[_element_replace]=$key;
		array_walk ($array,'_array_alter',$value);
		return $array;
	}
	*/
	function error_msg($conn)
	{
#		echo "<STRONG><FONT COLOR=RED>Error Executing Query</FONT></STRONG><BR>";
		echo "<STRONG><FONT COLOR=RED>Error Executing Query.<br>Error Description :".$conn->ErrorMsg()."</FONT></STRONG><BR>";
		die('');
	}
    
	function filter_empty($str_filter, $delimiter="&")
	{
        $tmp_str = "";
        $array_str = explode($delimiter, $str_filter);
        for ($i=0; $i < count($array_str); $i++) 
		{
            if (strpos($array_str[$i],"=") != (strlen($array_str[$i])-1)) 
			{
                if ($tmp_str != "") $tmp_str .= "&"; //Sebagai Delimeter yg baru
                $tmp_str .= $array_str[$i];
            }
        }
        return $tmp_str;
    }
	
	function sort_array($var)
	{
		if(count($var)>0)
		{
			sort($var);
		}
		return $var;
	}
	
	function strftime_date($term="", $format="Y-m-d", $no_space="") 
	{
		if ($format == "") $format	= "Y-m-d";
		if (!(strpos($term, "-") === false))	
			return date($format,strtotime($term));
		else
			return ($no_space?"":"");
	}

	function format_date($term="", $format="d-M-Y") 
	{ 
		global $_MONTH2,$_SERVER;
#		echo $_SERVER['HTTP_REFERER']."$format<br />";
		if (!(strpos($term, "-") === false))
		{
			$arr_tgl	= explode("-",$term);
			$arr_day	= explode(" ",$arr_tgl[2]);
			if ($arr_tgl[0] <= "1970" && $format=="d-M-Y") 
			{
				return $arr_day[0]."-".$_MONTH2[$arr_tgl[1]]."-".$arr_tgl[0];
			}
			elseif ($arr_tgl[0] <= "1970" && $format=="d M") 
			{
				return $arr_day[0]." ".$_MONTH2[$arr_tgl[1]];
			}
			else
			{
				return date($format,strtotime($term));
			}
		}
		else
		{
			return "&nbsp;";
		}
	}

	function format_datetime($term="", $format="d-M-Y H:i:s") 
	{ 
		global $_MONTH2,$_SERVER;
#		echo $_SERVER['HTTP_REFERER']."$format<br />";
		if (!(strpos($term, "-") === false))
		{
			$arr_tgl	= explode("-",$term);
			$arr_day	= explode(" ",$arr_tgl[2]);
			if ($arr_tgl[0] <= "1970" && $format=="d-M-Y H:i:s") 
			{
				return $arr_day[0]."-".$_MONTH2[$arr_tgl[1]]."-".$arr_tgl[0];
			}
			elseif ($arr_tgl[0] <= "1970" && $format=="d M H:i:s") 
			{
				return $arr_day[0]." ".$_MONTH2[$arr_tgl[1]];
			}
			else
			{
				return date($format,strtotime($term));
			}
		}
		else
		{
			return "&nbsp;";
		}
	}

	function f_v_i_e($var_source, $var_desc)	#fill vars if_empty
	{
		if(count($var_desc)>0 && is_array($var_desc)){ #jika $var_desc value adalah array maka yang digunakan adl $var_desc
			return $var_desc;
		} else if(trim($var_desc)=="" || $var_desc=="0") { #jika $var_desc value "" atau 0 maka yg digunakan adl $var_source
			return $var_source;
		} else {
			return $var_desc;
		}
	}

	function f_s_i_e($var_desc)	#fill with space (&nbsp;) if_empty
	{
		return f_v_i_e("&nbsp;", $var_desc);
	}
	
	function get_years_array($additional="10")	
	{
		global $_THN_BERDIRI;
		unset($arr_years);
		for($i=$_THN_BERDIRI;$i<=(date("Y")+$additional);$i++)
		{
			$arr_years[$i] = $i;
		}
		return $arr_years;
	}
	
	function replace_single_double_quote($tmpvalue="") 
	{
		$tmpvalue		= str_replace("'", "`", $tmpvalue);
		$tmpvalue		= str_replace("\"", "`", $tmpvalue);
		return $tmpvalue;
	}
	
	function check_user_right_by_page() 
	{
		global $_URL_LOGIN_PAGE;
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name("user_rights ur");
		$builder->set_left_join();
		$builder->set_table_name("pages p");
		$builder->set_join_on("ur.pages_serial", "p.serial");
		$builder->set_value("p.parameter");		
		$builder->set_condition();
		$builder->set_rules("ur.users_serial", $_SESSION['SESS_SERIAL']);
		$builder->set_rules("p.url", $_SERVER['SCRIPT_NAME']);
		$builder->set_rules("ur.allow", "1");		
		$sql 		= $builder->select_data();
		$results 	= $conn->GetAll($sql);	
		if ($results) 
		{
			$lolos 	= 0;
			foreach ($results as $result) 
			{
				$tmp_pars 	= explode('&',$result['parameter']);
				$tdk_lolos 	= 0;
				if ($tmp_pars)
				foreach ($tmp_pars as $tmp_par) 
				{
					$tmpval	= explode('=',$tmp_par);
#					print $tmpval[1].'####';
					if ($_GET[$tmpval[0]] != $tmpval[1]) 
					{
						if ($_SERVER['SCRIPT_NAME'] != '/login.html' && $_SERVER['SCRIPT_NAME'] != '/business/index.html') 
						{
							$tdk_lolos++;
						}				
					}				
				}
				if($tdk_lolos == 0)
				{
					$lolos++;
				}
			}
			if($lolos == 0)
			{
				die('Anda tidak diizinkan memasuki halaman ini !');
			}
		}
		else 
		{
			if ($_SERVER['SCRIPT_NAME'] != '/login.html' && $_SERVER['SCRIPT_NAME'] != '/business/index.html') 
			{
				die('Anda tidak diizinkan memasuki halaman ini !');
#			die($_SERVER['SCRIPT_NAME']);
			}
		}
	}
	
	function cek_sudah_absen()
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name("attendance_list");
		$builder->set_value("serial");		
		$builder->set_condition();
		$builder->set_rules("name", $_SESSION['SESS_SERIAL']);
		$builder->set_rules("date", date("Y-m-d"));
		$builder->set_rules("status", "1");		
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		if($results)
		{
			return true;
		}
		else
		{
			return false;		
		}
	}
	
	function total_minutes($hours)
	{		
		$tmpArr 		= explode(':',$hours);
		$minuteshours	= (int) $tmpArr[0]*60;
		$minutes		= (int) $tmpArr[1];
		$total_minutes	= $minuteshours + $minutes;
		return $total_minutes;
	}
	
	function format_to_hours($intMinutes)
	{
		$minutes			= $intMinutes / 60;
		$sisa_minutes		= $intMinutes % 60;
		$minutes			= explode('.',$minutes);
		return sprintf("%02d",$minutes[0]).':'.sprintf("%02d",$sisa_minutes);
	}
	
	function total_late_time($hours)
	{
		global $_JAM_MASUK;
		$total_late		= total_minutes($hours) - total_minutes($_JAM_MASUK);
		if($total_late > 0)
		{
			format_to_hours($total_late);		
/*			$late_minutes		= $total_late / 60;
			$sisa_total_late	= $total_late % 60;
			$late_minutes		= explode('.',$late_minutes);
			$total_				= sprintf("%02d",$late_minutes[0]).':'.sprintf("%02d",$sisa_total_late);
*/			
		}
		return $total_;		
	}
	
	function auto_absen_datang($user_serial="")
	{
		global $_PREFIX_ABSENSI, $_TABLE_ABSENSI, $_FIELD_ABSENSI;
		
		$user_serial=($user_serial?$user_serial:$_SESSION['SESS_SERIAL']);
		$arrival_time=date('H:i');
		$conn=OpenConnection();	
		$serial_attendance_list = get_serial("add_attendance_list");
		$new_prefix_no	= get_next_prefix_no($_PREFIX_ABSENSI, $_TABLE_ABSENSI, $_FIELD_ABSENSI);
		unset($builder);unset($sql);
		$builder 	= new sql_builder;
		$builder->set_table_name("attendance_list");
		$builder->set_value("serial",get_null_if_empty($serial_attendance_list));
		$builder->set_value("attendance_list_no ",get_null_if_empty($new_prefix_no));
		$builder->set_value("date","NOW()");					
		$builder->set_value("name",get_null_if_empty($user_serial));
		$builder->set_value("arrival_time",get_null_if_empty($arrival_time));	
		$builder->set_value("total_late_time",get_null_if_empty(total_late_time($arrival_time)));
		$sql = $builder->insert_data();	
		$conn->Execute($sql);
		return $arrival_time;
	}
	
	function get_coa_prefix_number($si_number="") 
	{
		global $_COA_PREFIX_INDEX;
		if($si_number) 
		{
			$arr_si	= split("-",$si_number);
			if ($arr_si)
			foreach($_COA_PREFIX_INDEX as $key => $val) 
			{
				if ($arr_si[0]==$key) return $val;
			}
		}
	}
	
	function cek_is_duplicate($field_value="", $table="", $field="", $update_serial="", $status="1", $status_operator="=")
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name($table);
		$builder->set_value($field);
		$builder->set_condition();
		if($table == "sales"){
			$builder->set_rules($field, $field_value);
		} else {
			$builder->set_rules($field, $field_value,"ilike");
		}
		$builder->set_rules("status", $status, $status_operator);
		$builder->set_rules("serial", $update_serial, "<>");
		$builder->set_order($field, DESC);
		$builder->set_limit("1");
		$sql 		= $builder->select_data();
		$result 	= $conn->GetOne($sql);
		unset($conn);
		if($result)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	
	function error_duplicate_msg($field="")
	{
		return "<font color=red><strong>Error : Duplicate $field</strong></font><br />";
	}
	
	function convert_minus_to_bracket($number)
	{
		if($number < 0) 
		{
			return "(".str_replace("-","",$number).")";
		} 
		else 
		{
			return $number;
		}
	}
	
	#################################################
	# Function untuk paging - di pakai di setiap VIEW #
	#################################################
	function get_default_record_per_page($num_record_per_page="", $num_result="")
	{
		global $_LIMIT_RECORD;

	   if (is_numeric($num_record_per_page)) 
	   {
			$num_record_per_page = $num_record_per_page;
	   } 
	   else
	   {
			$num_record_per_page ="";
	   }

	   if ($num_record_per_page=="")
	   {
			$num_record_per_page = $_LIMIT_RECORD;
	   }
	   else if ($num_record_per_page=="0")
	   {
			$num_record_per_page = $num_result;
	   } 
	   else
	   {
			$num_record_per_page = $num_record_per_page ;
	   }
	   return $num_record_per_page;
	}

	#############################################################
	# Memberi kurung pada negative number ex: (1000.00) = -1000 #
	#############################################################
	function get_number_format ($var)
	{
		$tmpvalue = number_format ($var,2);
		if ($tmpvalue[0]=="-") 
		{
			return $tmpvalue="(".substr($tmpvalue,1).")";
		}
		else
		{
			return $tmpvalue;
		}
	}
	
	function n_f($var, $decimals="0")
	{
		$tmpvalue = number_format ($var, $decimals);
		if ($decimals == "2") $tmpvalue = str_replace(".00", "", $tmpvalue);
		return $tmpvalue;
	}
	
	###---FUNCTION UNTUK TAMBAH KURANG SEMUA TABLE DETAIL ---### 
	function get_number_of_loop($tambah="",$kurang="",$num_loop_0="", $allow_zero="")
	{
		if ($tambah<>"")
		{
			$num_loop_0 = $num_loop_0 + 1;
		}
		if ($kurang<>"")
		{
			$num_loop_0 = $num_loop_0 - 1;
		}
		if ($num_loop_0=="" || $num_loop=="0")
		{
			if ($allow_zero)
				$num_loop_0 = 0;
			else
				$num_loop_0 = 1;
		}
		return $num_loop_0;
	}
	
	function get_max_loop($var_a="", $var_b="")
	{
		if ($var_a >= $var_b)
		{
			$tmp = $var_a;
		}
		if ($var_a<$var_b)
		{
			$tmp = $var_b;
		}
		if ($var_a=="" && $var_b=="")
		{
			$tmp = 1;
		}
		return $tmp;
	}

	function fill_vars_if_unset($var_source, $var_desc)
	{
		if(!isset($var_desc))
		{
			return $var_source;
		}
		else
		{
			return $var_desc;
		}
	}

	function fill_vars_if_not_empty($var_1, $var_2)
	{ 
		if(trim($var_2)<>"" && $var_2<>"0")
		{
			return $var_2;
		}
		else
		{
			return $var_1;
		}
	}
	
	function fill_vars_zero_if_empty($var)
	{
		if(trim($var)=="")
		{
			return 0;
		}
		else
		{
			return $var;
		}
	}
	
	function fill_vars_if_zero($var_source, $var_desc)
	{
		if(trim($vars_desc)=="0")
		{
			return $var_source;
		}
	}
	
    function get_null_if_empty($vars)
    {
        $vars2 = trim($vars);
		if (strlen($vars2) == 1 && ord($vars2) == 160)
		{
        	$vars2 = "";
		}
        if ((empty($vars2)) && ($vars2==""))
        {
            return NULL;
        }
		else
        {
            $vars2 = "".$vars2."";
            return $vars2;
        }
    }
	
    function fill_null_if_emtpy($vars)
    {
        if ($vars=="" && empty($vars))
        {
            $vars = "NULL";
        } 
        return $vars;
    }

	function default_date($var="")
	{
		if(empty($var)&& $var=="")
		{
			$var = date("Y-m-d");
		}
		return $var;
	}
	
	function get_serial($var)
	{
		// global $_BRANCH_COMPANY,$_BRANCH_COMPANY_SELECTED;
#		$var = md5(microtime().$var.rand(0,999999999).$_BRANCH_COMPANY[$_BRANCH_COMPANY_SELECTED]);
		$var = md5(microtime().$var.rand());
		return $var;
	}
	
	function IntervalDays($CheckIn,$CheckOut){
		$CheckInX	= explode("-", $CheckIn);
		$CheckOutX	= explode("-", $CheckOut);
		$date1		= mktime(0, 0, 0, $CheckInX[1],$CheckInX[2],$CheckInX[0]);
		$date2		= mktime(0, 0, 0, $CheckOutX[1],$CheckOutX[2],$CheckOutX[0]);
		$interval 	= ($date2 - $date1) / (3600*24);
		return $interval ;
	}

	function type_order($var)
	{
		if ($var== "")
		{
			$type_order = "desc";
		}
		elseif ($var == "asc")
		{
			$type_order = "desc";
		}
		elseif ($var == "desc")
		{
			$type_order = "asc";
		}
		return $type_order;
	}

	function del_commas($var)
	{
		$commas = str_replace(",","",$var);
		return $commas;
	}

	function xls_format ($buffer)
	{
		$buffer=strip_tags($buffer,"<table><b><i><u><td><tr><link>");
		$toreplace=strrev(substr($buffer,strpos($buffer,"<link"),1000));
		$toreplace=strrev(substr($toreplace,strpos($toreplace,">elbat/<")));
		$buffer=str_replace($toreplace," ",$buffer);
		$buff=strrev($buffer);
		$search=substr($buff,0,strpos($buff,"elbat<"));
		$search=strrev(substr($buff,0,strpos($buff,"elbat<")));
		$buffer=str_replace($search," ",$buffer);
		$buffer=str_replace("<tr","<tr style='border: solid 1px #cccccc;'",$buffer);
		return $buffer.">";
	}
	
	function xls_format_out ()
	{
		ob_end_flush();
	}
	
	function get_lastdate_of_the_month($month,$year)
	{
		$cmonth 	= $month + 1;
		$lastday 	= mktime (0,0,0,$cmonth,0,$year);
		return strftime ("%d", $lastday);
	}
	
	function get_karu_yes_no($sales_order_no_car="",$user_serial="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("kepala_regu");
		$builder->set_table_name("sales_technician");
		$builder->set_condition();
		$builder->set_rules("sales_serial", "$sales_order_no_car");
		$builder->set_rules("user_serial", "$user_serial");
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["kepala_regu"];
		return $array_;
	}

	function get_serial_from_table($tablename="",$searchfieldname="",$searchfieldvalue="") 
	{
		if($searchfieldvalue){
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("serial");
		$builder->set_table_name("$tablename");
		$builder->set_condition();
		$builder->set_rules("$searchfieldname", "$searchfieldvalue");
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["serial"];
		return $array_;
		} else {
		return "";
		}
	}

	function get_purchase_price_claim($windowfilmgroup="",$inventoryserial="") 
	{
		$conn		= OpenConnection();
		$builder	= new sql_builder;
		$builder->set_table_name("purchase_price");
		$builder->set_value("usd_price");
		$builder->set_value("idr_price");
		$builder->set_value("kurs");
		$builder->set_condition();
		$builder->set_rules("inventory_category", "1");
		$builder->set_rules("window_film_group", $windowfilmgroup);
		$builder->set_rules("inventory_serial", $inventoryserial);
		$builder->set_rules("valid_thru", "NULL", "is");
		$builder->set_rules("status", "1");
		$sql		= $builder->select_data();
		$results	= $conn->GetRow($sql);
		$array_		= f_v_i_e(($results["usd_price"]*$results["kurs"]),$results["idr_price"]);
		return $array_;
	}

	function get_purchaseprice_kurs_claim($fieldname="",$windowfilmgroup="",$inventoryserial="") 
	{
		$conn		= OpenConnection();
		$builder	= new sql_builder;
		$builder->set_table_name("purchase_price");
		$builder->set_value("$fieldname");
		$builder->set_condition();
		$builder->set_rules("inventory_category", "1");
		$builder->set_rules("window_film_group", $windowfilmgroup);
		$builder->set_rules("inventory_serial", $inventoryserial);
		$builder->set_rules("valid_thru", "NULL", "is");
		$builder->set_rules("status", "1");
		$sql		= $builder->select_data();
		$results	= $conn->GetRow($sql);
		$array_		= $results["$fieldname"];
		return $array_;
	}

	function get_serial_for_salesorder($spkclaim="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("sales_order_no");
		$builder->set_table_name("sales");
		$builder->set_condition();
		$builder->set_rules("serial", "$spkclaim");
		$builder->set_rules("sales_type", "('1','3','5','7')","IN");
		// $builder->set_rules("status", "('1','2')","IN");
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["sales_order_no"];
		return $array_;
	}

	function get_serial_for_salesinvoice($spkawal="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("serial");
		$builder->set_table_name("sales");
		$builder->set_condition();
		$builder->set_rules("sales_order_no", "$spkawal");
		$builder->set_rules("sales_type", "('2','4','6','8')","IN");
		// $builder->set_rules("status", "('1','2')","IN");
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["serial"];
		return $array_;
	}

	function get_serial_from_table3($tablename="",$searchfieldname="",$searchfieldvalue="",$allin="",$inquery="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("serial");
		$builder->set_table_name("$tablename");
		$builder->set_condition();
		$builder->set_rules("$searchfieldname", "$searchfieldvalue");
		if($allin){
			$builder->set_rules("user_type", "$inquery", "IN");
		}
		$builder->set_rules("status", "('1','2')", "IN");
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["serial"];
		return $array_;
	}

	function get_date_invreceiving_from_masterroll($master_roll_no="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("created_date");
		$builder->set_table_name("master_roll_no");

		$builder->set_condition();
		$builder->set_rules("status", "1");
		$builder->set_rules("master_roll_no", "$master_roll_no");

		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= format_date($results["created_date"],"Y-m-d");
		return $array_;
	}

	function get_date_invreceiving_from_masterrollx($master_roll_no="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("ip.date");
		$builder->set_table_name("inventory_process_detail as ipd");
		$builder->set_left_join();
		$builder->set_table_name("master_roll_no as mr");
		$builder->set_join_on("ipd.master_roll_serial","mr.serial");
		$builder->set_left_join();
		$builder->set_table_name("inventory_process as ip");
		$builder->set_join_on("ipd.inventory_process_serial","ip.serial");

		$builder->set_condition();
		$builder->set_rules("ip.inventory_process_type", "1");
		$builder->set_rules("ip.status", "1");
		$builder->set_rules("ipd.roll_type", "1");
		$builder->set_rules("mr.master_roll_no", "$master_roll_no");

		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["date"];
		return $array_;
	}

	function get_date_invtransfer_from_masterroll($master_roll_no="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("ip.date");
		$builder->set_table_name("inventory_process_detail as ipd");
		$builder->set_left_join();
		$builder->set_table_name("master_roll_no as mr");
		$builder->set_join_on("ipd.master_roll_serial","mr.serial");
		$builder->set_left_join();
		$builder->set_table_name("inventory_process as ip");
		$builder->set_join_on("ipd.inventory_process_serial","ip.serial");

		$builder->set_condition();
		$builder->set_rules("ip.inventory_process_type", "4");
		$builder->set_rules("ip.status", "1");
		$builder->set_rules("ipd.roll_type", "1");
		$builder->set_rules("mr.master_roll_no", "$master_roll_no");

		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["date"];
		return $array_;
	}

	function get_serial_from_table2($tablename="",$searchfieldname="",$searchfieldvalue="",$user_type="",$division="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("serial");
		$builder->set_table_name("$tablename");
		$builder->set_condition();
		$builder->set_rules("$searchfieldname", "$searchfieldvalue");
		if($user_type){
			if($user_type == "4"){
				$builder->set_rules("user_type", "('4','5')","IN");
				$builder->set_rules("status", "1");
			} else {
				$builder->set_rules("user_type", "$user_type");
				$builder->set_rules("status", "1");
			}
		}
		if($division){
			$builder->set_rules("division", "$division");
		}
		if($tablename == "car_type" || $tablename == "users"){
			$builder->set_rules("status", "1");
		}
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results["serial"];
		return $array_;
	}

	function get_field_from_table($tablename="",$fieldname="",$searchfieldname="",$searchfieldvalue="",$status="") 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_value("$fieldname");
		$builder->set_table_name("$tablename");
		$builder->set_condition();
		$builder->set_rules("$searchfieldname", "$searchfieldvalue");
		if($status){
			$builder->set_rules("status","1");
		}
		$sql 		= $builder->select_data();
		$results 	= $conn->GetRow($sql);
		$array_		= $results[$fieldname];
		return $array_;
	}

	function get_coa_val () 
	{
		$conn=OpenConnection();
 	 	unset($builder);
		$builder 	= new sql_builder;
		$builder->set_table_name(finance_chart_of_account);
		$builder->set_value("*");
		$builder->set_condition();
		$builder->set_rules("status", "1", "=");
		$builder->set_order("coa_number", ASC);
		$sql 		= $builder->select_data();
		$results 	= $conn->GetAll($sql);
		if($results)
		{
			foreach($results as $result)
			{
				$array_[$result["coa_number"]]		= $result["coa_desc"];
			}
		}
		return $array_;
	}
	function get_users_all($input0="",$cat="")
	{
		$conn=OpenConnection();
		unset($builder);
		$builder	= new sql_builder;
		$builder->set_table_name(users);
		$builder->set_value("*");
		$builder->set_condition();
		$builder->set_rules("status","1","=");
		if($input0)			$builder->set_rules("serial","%$input0%","ilike");
		if($cat)			$builder->set_rules("user_type","%$cat%","ilike");
		$sql		= $builder->select_data();
		$results	= $conn->GetAll($sql);
		if($results)
		{
			foreach($results as $result)
			{
				$array_[$result["serial"]]	= $result["full_name"];
			}
		}
		return $array_;
	}
	function get_sales_all($input0="",$cat="")
	{
		$conn=OpenConnection();
		unset($builder);
		$builder	= new sql_builder;
		$builder->set_table_name(sales);
		$builder->set_value("*");
		$builder->set_condition();
		$builder->set_rules("status","1","=");
		if($input0)			$builder->set_rules("serial","$input0","ilike");
		if($cat)			$builder->set_rules("sales_type","$cat","ilike");
		$sql		= $builder->select_data();
		$results	= $conn->GetAll($sql);
		if($results)
		{
			foreach($results as $result)
			{
				$array_[$result["serial"]]	= ($result["sales_invoice_no_building"]?$result["sales_invoice_no_building"]:($result["sales_invoice_no_materials"]?$result["sales_invoice_no_materials"]:$result["sales_invoice_no_car"]));
				$array_['jenis_pemasangan']	= ($result["sales_invoice_no_building"]?"2":($result["sales_invoice_no_materials"]?"3":"1"));
				$array_["total_commission"]	= $result["total_commission"];
			}
		}
		return $array_;
	}

	function get_purchase_all($input0="",$cat="",$input1="")
	{
		$conn=OpenConnection();
		unset($builder);
		$builder 		= new sql_builder;
		$builder->set_table_name("purchase as p");
		$builder->set_left_join();
		$builder->set_table_name("supplier_invoice_no as sin");
		$builder->set_join_on("p.supplier_invoice_no","sin.serial");
		$builder->set_left_join();
		$builder->set_table_name("users as u");
		$builder->set_join_on("p.supplier_serial","u.serial");
		if($input0)
		{
			$builder->set_left_join();
			$builder->set_table_name("purchase_detail as pd");
			$builder->set_join_on("pd.purchase_serial","p.serial");
			$builder->set_left_join();
			$builder->set_table_name("inventory as i");
			$builder->set_join_on("i.serial","pd.inventory_serial");
		}
		else
		{
			$builder->set_value("p.serial");
		}
		$builder->set_value("p.serial as purchase_serial");
		$builder->set_value("sin.supplier_invoice_no");
		$builder->set_value("p.purchase_invoice_no");
		$builder->set_value("p.purchase_type");
		$builder->set_value("p.date");
		$builder->set_value("p.supplier_type as bill_to_type");
		$builder->set_value("p.supplier_serial as bill_to_serial");
		$builder->set_value("u.full_name as bill_to_name");
		$builder->set_value("p.balance");
		$builder->set_condition();
		if($input0)
		{
			$builder->set_value("pd.serial");
			$builder->set_value("pd.rebate_idr");
			$builder->set_value("pd.item_group");
			$builder->set_value("pd.qty");
			$builder->set_value("pd.total");
			$builder->set_value("i.inventory_name");        
			$builder->set_condition();
			$builder->set_rules("pd.item_group","1");
			$builder->set_rules("pd.serial","$input0","ilike");
		}	
		$builder->set_rules("p.status","1");
		if($input1)			$builder->set_rules("p.serial","$input1","ilike");
		if($cat)			$builder->set_rules("p.purchase_type","$cat","ilike");
		$builder->set_order("date","asc");
		$builder->set_order("p.purchase_invoice_no","asc");

		$sql		= $builder->select_data();
		$results	= $conn->GetAll($sql);
	
		return $results;
	}
	
	function get_part_group_array($part_cat="")
	{
		global $_MAINBOARD_GROUP, $_MEMORY_GROUP, $_PROCESSOR_GROUP, $_HDD_GROUP, $_MONITOR_GROUP, $_USB_GROUP;
		if ($part_cat == "1")
		{
			$part_group	= $_MAINBOARD_GROUP;
		}
		else if ($part_cat == "2")
		{
			$part_group	= $_MEMORY_GROUP;
		} 
		else if($part_cat == "3")
		{
			$part_group	= $_PROCESSOR_GROUP;
		}
		else if($part_cat == "4")
		{
			$part_group = $_HDD_GROUP;
		}
		else if($part_cat == "5")
		{
			$part_group = $_MONITOR_GROUP;
		}
		else if($part_cat == "6")
		{
			$part_group = $_USB_GROUP;
		}
		return $part_group;
	}

	function encrypt($string, $key) {
		$result			 = '';
		for($i=0; $i<strlen($string); $i++) {
			$char		 = substr($string, $i, 1);
			$keychar	 = substr($key, ($i % strlen($key))-1, 1);
			$char		 = chr(ord($char)+ord($keychar));
			$result		.= $char;
		}
		return base64_encode($result);
	}

	function decrypt($string, $key) {
		$result			 = '';
		$string			 = base64_decode($string);
		for($i=0; $i<strlen($string); $i++) {
			$char		 = substr($string, $i, 1);
			$keychar	 = substr($key, ($i % strlen($key))-1, 1);
			$char		 = chr(ord($char)-ord($keychar));
			$result		.= $char;
		}
		return $result;
	}

	function getBrowser() {
		$u_agent	= $_SERVER['HTTP_USER_AGENT'];
		$bname		= 'Unknown';
		$platform	= 'Unknown';
		$version	= "";

		//First get the platform?
		if (preg_match('/linux/i', $u_agent)) {
			$platform = 'linux';
		} elseif (preg_match('/macintosh|mac os x/i', $u_agent)) {
			$platform = 'mac';
		} elseif (preg_match('/windows|win32/i', $u_agent)) {
			$platform = 'windows';
		}

		// Next get the name of the useragent yes seperately and for good reason
		if(preg_match('/MSIE/i',$u_agent) && !preg_match('/Opera/i',$u_agent)) {
			$bname		= 'Internet Explorer';
			$ub			= "MSIE";
		} elseif(preg_match('/Firefox/i',$u_agent)) {
			$bname		= 'Mozilla Firefox';
			$ub			= "Firefox";
		} elseif(preg_match('/Chrome/i',$u_agent)) {
			$bname		= 'Google Chrome';
			$ub			= "Chrome";
		} elseif(preg_match('/Safari/i',$u_agent)) {
			$bname		= 'Apple Safari';
			$ub			= "Safari";
		} elseif(preg_match('/Opera/i',$u_agent)) {
			$bname		= 'Opera';
			$ub			= "Opera";
		} elseif(preg_match('/Netscape/i',$u_agent)) {
			$bname		= 'Netscape';
			$ub			= "Netscape";
		}

		// finally get the correct version number
		$known		= array('Version', $ub, 'other');
		$pattern	= '#(?<browser>' . join('|', $known) .
		')[/ ]+(?<version>[0-9.|a-zA-Z.]*)#';
		if (!preg_match_all($pattern, $u_agent, $matches)) {
			// we have no matching number just continue
		}

		// see how many we have
		$i			= count($matches['browser']);
		if ($i != 1) {
			//we will have two since we are not using 'other' argument yet
			//see if version is before or after the name
			if (strripos($u_agent,"Version") < strripos($u_agent,$ub)){
				$version= $matches['version'][0];
			}
			else {
				$version= $matches['version'][1];
			}
		} else {
			$version= $matches['version'][0];
		}

		// check if we have a number
		if ($version==null || $version=="") {
			$version="?";
		}

		return array(
			'userAgent'	=> $u_agent,
			'name'		=> $bname,
			'version'	=> $version,
			'platform'	=> $platform,
			'pattern'	=> $pattern
		);
	}
?>
