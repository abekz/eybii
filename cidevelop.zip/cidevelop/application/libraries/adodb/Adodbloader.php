<?php 

if(!defined('BASEPATH')) exit('No direct script access allowed');

class Adodbloader{

     function Adodbloader(){
        if(!class_exists('ADONewConnection'))
        require_once(APPPATH.'libraries/adodb/adodb.inc.php');

        $obj =& get_instance();
        $this->_init_adodb_library($obj);
    }

    function _init_adodb_library(&$ci){
        $db_var     = false;
        $debug      = false;
        if(!isset($dsn)){
            //using the CI database configuration
            include(APPPATH.'config/database.php');
            $group  = 'default';
            $dsn    = 'postgres'.'://'.$db[$group]['username'].':'.$db[$group]['password'].'@'.$db[$group]['hostname'].'/'.$db[$group]['database'];
        }
        //creating the instance
        $ci->adodb  =& ADONewConnection($dsn);
        if($db_var){
            //set the CI database object to use adodb instance
            $ci->db =& $ci->adodb;
        }
        if($debug){
            $ci->adodb->debug = true;
        }
    }
}

?>